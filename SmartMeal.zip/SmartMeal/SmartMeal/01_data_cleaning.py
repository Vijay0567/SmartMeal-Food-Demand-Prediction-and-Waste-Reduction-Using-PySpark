
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, to_date, trim
import os

# ==========================================
# SMARTMEAL - DATA LOADING AND CLEANING
# ==========================================

# 1. Create Spark Session
spark = (
    SparkSession.builder
    .appName("SmartMeal")
    .master("local[*]")
    .getOrCreate()
)

spark.sparkContext.setLogLevel("ERROR")

print("\n========== SMARTMEAL ==========")

# 2. Load CSV Dataset
df = spark.read.csv(
    "food_demand.csv",
    header=True,
    inferSchema=True
)

# 3. Display Original Dataset
print("\n===== ORIGINAL DATASET =====")

df.show(10, truncate=False)

# 4. Display Schema
print("\n===== DATASET SCHEMA =====")

df.printSchema()

# 5. Count Original Records
original_count = df.count()

print("Original Records:", original_count)

# 6. Check Missing Values
print("\n===== MISSING VALUES BEFORE CLEANING =====")

for column_name in df.columns:

    missing = df.filter(
        col(column_name).isNull()
    ).count()

    print(column_name, ":", missing)

# 7. Convert Date Column
df = df.withColumn(
    "date",
    to_date(col("date"), "yyyy-MM-dd")
)

# 8. Remove Duplicate Records
df = df.dropDuplicates()

# 9. Clean Categorical Columns
df = df.withColumn(
    "menu_category",
    trim(col("menu_category"))
)

df = df.withColumn(
    "day_type",
    trim(col("day_type"))
)

# 10. Handle Missing Categorical Values
df = df.fillna({
    "menu_category": "Unknown",
    "day_type": "Unknown"
})

# 11. Handle Missing Numerical Values
numeric_columns = [
    "temperature",
    "previous_leftovers"
]

for column_name in numeric_columns:

    median_values = df.approxQuantile(
        column_name,
        [0.5],
        0.01
    )

    if median_values:
        df = df.fillna({
            column_name: median_values[0]
        })

# 12. Remove Invalid Records
df = df.filter(
    col("date").isNotNull()
    & col("meals_ordered").isNotNull()
    & (col("meals_ordered") >= 0)
)

# 13. Display Cleaned Dataset
print("\n===== CLEANED DATASET =====")

df.show(10, truncate=False)

cleaned_count = df.count()

print("\nOriginal Records:", original_count)
print("Cleaned Records:", cleaned_count)
print("Removed Records:", original_count - cleaned_count)

# 14. Check Missing Values After Cleaning
print("\n===== MISSING VALUES AFTER CLEANING =====")

for column_name in df.columns:

    missing = df.filter(
        col(column_name).isNull()
    ).count()

    print(column_name, ":", missing)

# 15. Save Cleaned Dataset
# Use Pandas only for CSV export to avoid
# the Windows Hadoop NativeIO writing issue.

print("\n===== SAVING CLEANED DATASET =====")

cleaned_pd = df.toPandas()

output_file = "cleaned_food_demand.csv"

cleaned_pd.to_csv(
    output_file,
    index=False
)

print("\nDATA CLEANING COMPLETED SUCCESSFULLY!")

print("Saved File:", os.path.abspath(output_file))
print("Total Saved Records:", len(cleaned_pd))

# 16. Stop Spark Session
spark.stop()

print("\nSMARTMEAL PROCESS FINISHED!")
