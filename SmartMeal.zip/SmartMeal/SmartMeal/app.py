
import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
import os
from html import escape

# =========================================================
# SMARTMEAL - PREMIUM FOOD DEMAND & WASTE DASHBOARD
# =========================================================

st.set_page_config(
    page_title="SmartMeal | Food Intelligence",
    page_icon="🍽️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# =========================================================
# 1. PREMIUM CSS DESIGN
# =========================================================

st.markdown("""
<style>

.stApp {
    background: #f5f7fb;
    color: #172d49;
}

[data-testid="stHeader"] {
    background: #f5f7fb;
}

[data-testid="stAppViewContainer"] {
    background: #f5f7fb;
}

.block-container {
    max-width: 1500px;
    padding-top: 2rem;
    padding-bottom: 3rem;
}

html, body, [class*="css"] {
    font-family: "Inter", "Segoe UI", sans-serif;
}

/* Sidebar */

section[data-testid="stSidebar"] {
    background: #101d33;
    border-right: 1px solid #263650;
}

section[data-testid="stSidebar"] * {
    color: #e8eef8 !important;
}

section[data-testid="stSidebar"] [data-baseweb="select"] > div {
    background: #1b2b45 !important;
    border: 1px solid #354967 !important;
    border-radius: 9px !important;
}

section[data-testid="stSidebar"] input {
    background: #1b2b45 !important;
    color: white !important;
}

section[data-testid="stSidebar"] hr {
    border-color: #354967;
}

/* Section headings */

.section-heading {
    font-size: 22px;
    font-weight: 750;
    color: #172d49;
    margin-top: 30px;
    margin-bottom: 5px;
}

.section-description {
    font-size: 13px;
    color: #718096;
    margin-bottom: 18px;
}

/* Charts */

[data-testid="stPlotlyChart"] {
    background: white;
    border: 1px solid #e8edf4;
    border-radius: 16px;
    padding: 10px;
    box-shadow: 0 5px 18px rgba(31,50,81,0.04);
}

/* Tables */

[data-testid="stDataFrame"] {
    border: 1px solid #e7edf5;
    border-radius: 13px;
    overflow: hidden;
}

/* Buttons */

.stDownloadButton button {
    background: #173d63 !important;
    color: white !important;
    border: none !important;
    border-radius: 9px !important;
    font-weight: 650 !important;
    padding: 10px 18px !important;
}

.stDownloadButton button:hover {
    background: #126b68 !important;
}

/* Expanders */

[data-testid="stExpander"] {
    background: white;
    border: 1px solid #e7edf5;
    border-radius: 12px;
}

</style>
""", unsafe_allow_html=True)


# =========================================================
# 2. LOAD PROJECT DATA
# =========================================================

@st.cache_data
def load_data():

    predictions = pd.read_csv(
        "model_predictions.csv",
        parse_dates=["date"]
    )

    importance = pd.read_csv(
        "feature_importance.csv"
    )

    return predictions, importance


required_files = [
    "model_predictions.csv",
    "feature_importance.csv"
]

for file in required_files:

    if not os.path.exists(file):
        st.error(
            f"{file} not found. "
            "Please run 03_model_training.py first."
        )
        st.stop()


try:

    df, importance_df = load_data()

except Exception as error:

    st.error(f"Unable to load datasets: {error}")
    st.stop()


# =========================================================
# 3. DATA PREPROCESSING
# =========================================================

df["date"] = pd.to_datetime(
    df["date"],
    errors="coerce"
)

numeric_columns = [
    "actual_demand",
    "predicted_demand",
    "meals_prepared",
    "actual_leftovers"
]

for column in numeric_columns:

    df[column] = pd.to_numeric(
        df[column],
        errors="coerce"
    )

df = df.dropna(
    subset=[
        "date",
        "actual_demand",
        "predicted_demand"
    ]
)

if df.empty:
    st.error("No valid prediction records found.")
    st.stop()

if "actual_leftovers" not in df.columns:
    st.error("actual_leftovers column is missing.")
    st.stop()

if "meals_prepared" not in df.columns:
    st.error("meals_prepared column is missing.")
    st.stop()

# =========================================================
# 4. SIDEBAR
# =========================================================

with st.sidebar:

    st.markdown(
        "<h2 style='color:white;'>🍽️ SmartMeal</h2>",
        unsafe_allow_html=True
    )

    st.markdown(
        """
        <p style="color:#aebed3;font-size:12px;">
        FOOD INTELLIGENCE PLATFORM
        </p>
        """,
        unsafe_allow_html=True
    )

    st.divider()

    st.markdown("### Dashboard Controls")

    st.caption("Customize your analytics view.")

    categories = (
        ["All Categories"]
        + sorted(
            df["menu_category"].dropna().unique().tolist()
        )
    )

    selected_category = st.selectbox(
        "Menu Category",
        categories
    )

    min_date = df["date"].min().date()
    max_date = df["date"].max().date()

    selected_dates = st.date_input(
        "Analysis Period",
        value=(min_date, max_date),
        min_value=min_date,
        max_value=max_date
    )

    st.divider()

    st.markdown("### Model Information")

    st.markdown("""
    **Algorithm**

    Random Forest Regression

    **Framework**

    PySpark MLlib

    **Training Period**

    2023–2024

    **Testing Period**

    2025

    **Input Features**

    16
    """)

    st.divider()

    st.caption("SMARTMEAL • ANALYTICS PLATFORM")


# =========================================================
# 5. APPLY FILTERS
# =========================================================

if not isinstance(selected_dates, (tuple, list)) or len(selected_dates) != 2:

    st.info("Please select both start and end dates.")
    st.stop()

start_date, end_date = selected_dates

if start_date > end_date:

    st.error("Start date cannot be after end date.")
    st.stop()

filtered_df = df[
    (df["date"].dt.date >= start_date)
    & (df["date"].dt.date <= end_date)
].copy()

if selected_category != "All Categories":

    filtered_df = filtered_df[
        filtered_df["menu_category"] == selected_category
    ]

if filtered_df.empty:

    st.warning("No records found for the selected filters.")
    st.stop()


# =========================================================
# 6. FOOD DEMAND AND WASTE CALCULATIONS
# =========================================================

# Estimated surplus based on predicted demand
filtered_df["estimated_surplus"] = np.maximum(
    0,
    filtered_df["meals_prepared"]
    - filtered_df["predicted_demand"]
)

# Unfulfilled demand based on actual demand
filtered_df["unfulfilled_demand"] = np.maximum(
    0,
    filtered_df["actual_demand"]
    - filtered_df["meals_prepared"]
)

# Actual preparation surplus based on actual demand
filtered_df["actual_preparation_surplus"] = np.maximum(
    0,
    filtered_df["meals_prepared"]
    - filtered_df["actual_demand"]
)

total_actual = filtered_df["actual_demand"].sum()

total_predicted = filtered_df["predicted_demand"].sum()

total_prepared = filtered_df["meals_prepared"].sum()

total_leftovers = filtered_df["actual_leftovers"].sum()

total_estimated_surplus = filtered_df["estimated_surplus"].sum()

total_unfulfilled = filtered_df["unfulfilled_demand"].sum()


# =========================================================
# 7. HERO SECTION
# =========================================================

# The right-side food analytics illustration is embedded in this file,
# so the dashboard does not need a separate image asset.
hero_image = "data:image/webp;base64,UklGRhrHAABXRUJQVlA4IA7HAACQ+gKdASphBPQBPj0cjESiIaMhI/OaWGAHiWNLSHXj8/R7/UFbJ2XmH+ZlPbxbKRYvTovB9Mbmg0iM32c/PM7geN/tP8v81fbv5D8Mvdf4b/Of7z/D/uX+Fv8TyO+o/4H0gfBN0F/zP8V+SPzH/5X/t/3Pu1/o3+e/7X+X/f/6CP1Z/2v+C/y37UfR7/tftz7+P7v/1fUf/Qv8f/5f89+9/zGf8D9xvd5/dP9X/6P9D/2fkC/pX+a/8nry+x7/mP+j/9PcM/pP+Y/8ntH/9z9xvho/sv/D/+v+7/6f//+if+of5f/0/t1////b9AH/49rz+Af+3rN+8X+79OHx/+p/23iH+PfW/47+9/6H/d/33/5/8D7wf3vS/8Z/leZH8s/DP6L/C/tl/i/3F+hv+h9y/6O+4v5h/D/8T/O/vR/nPkI/Gf5r/l/7/+2X+K/cf6Uv0PCY2H/af97/Vewj7l/Uf9H/gv8V/z/8h8W30v+69Mf4z/Mf8D84voC/pP9R/y397/bj+xf///iflX+t8U/8x/yv+R7gn9D/s3++/xP+u/ZD6bP7P/0f6v/e/tz79fz7/O/+L/N/7b9rvsT/mH9s/3v+G/0X/h/0v///8nM9jxIBIqtLSq5XCrp6enp6enp6enp6enp6ecDGxemBsbGxsbDeAQZZBDvvx/ggT2xD7ddvfmI/ISNBLdPT09PT09PT09PT09PT09I/s/6RsiJCsPN47YmeGfafhPM4jDChsz39OPYfL24Alh5899pLQ64KWr9PhIB78aW/595tk9uOioXCPxHciJON0b2W7LE8X4AjN1JfJoeXT0ryjstSK+/PeD7nBz6g81reBoUEnwXTbrAt+JglPNtXBwBjvSCaYBPrykULepVfKXtJdccOM+rfiLzntzS38T/NbRuDjeUI6eCV7rgbfgS7dXRZSW99JBg8zg2QdD25nCIMrJuuFZcojWQHW2r+BZuso2RdFapSLKcjdZ9V7vOJY12wxHxOzcF4mdyJdurm6rRFqyaDyFuUk1bWL3kQn3PmnaoTCIXFzybnSie6e99NS2JQBFEY38twfWaI75XvHCZyYgTEBwBxFf3sFS6qMj8DE5KKIMso9fp1bTmY/7zWfZnhHAVS8lqhvzcU5IO20fU/6kj4Gbv6OP+o6P1FJj3t9RpUyjco58ojz8eU3w+WUIDjrxovD5o65yFsRam4WlGcSXreXehh0N+AYESt/ZOd3bP5zdFNdhUDvjBLFSf+s5pT36kTlljVsDlBdrNz+PxqOhjFiiEWjpCKYUuMBry9LGTJMhdPwY9eBFKBLWBBvZbSSIVoSu67A9T8xSoPPL+9nB71YlGhjbOKUwXMd1wr9PzRoNk7tK3Rhxnn45TXWGJZPLk/+HSUPoh39GmcsX8nEHDd+xP///xEMIbP2kRB576kQtUcb4rX1p79MM3JNIch9uTTVr3yCeTWMfu6w/iYEgrOLXxZlKsB0FD8n+oTt3ZMWd6hfkFJQUvkyKb4ul3atiOdR/EGHX4HvsFSzeehernFkbrXgIuEWUEuv3YcSgca5BK/kyDgv87eiAsBmTox4xhR1iREJosCu+dzQt+3Ppm0OFpuK7SENlX0suH0g/jT1iuZ3EURUJ/WqTxlY1avXO+i+yp4F/COOLxt0b/gDgBbloHbA5kitlob4gVk7Z08PNTvq1iiWVeGjO1wZ72/pR397SB1neTcIy3Xza8SqdjiOv+2oTMB5/eYY0vMYKtWj1MkuElWqWmrkpq9+8M/qNTDxK72AjQMkPzJnw1n2jmb7fLypn8BGXv3hw29nw+hFyyzO7QdJQ6tbKAzNzawdeFTTLCAqAJ/2xvFHz6PFfe8fi2ooIma4hpNu61PMD5N6uoelIU42E7AzJqHKo+YUm9RewsN/IrZIs/ugyijk1YOXY24SMuUedHVs15Z8GVPn+3P83Q+9nLulT0oVJo50TRvCCD6LhSPb0aww8BWEbmncEAGV+JEtJqt+3ltUScshqfsvM2Qh0Bc1BRHZIwjMvNb+esCQ8WJ1iZ3yLrxebVJy8BQ0YNKeHSArlnGREoDWA7VJHLojHG7K7h4U9ly7F1MmD+fym4qZ88MJmGUe6/wrQ6LaFi2IQ31W4UzQYPAkktvJhslVPoqC4TZf+lzaP+MxH+uzwGUevdvbqPMERSg4uFK78P3y13IoWZhr1dSTK1/pIO7R2sWOdvQLLjzkkUlF5Oq5Dfjyw31bDpzSs+i3P382o37JABQ0SPZ0xSpo3b9BrJY9tl9pOI2lriIEOstDWDZD7IbqiddPf9zVFAaB9pIoAiIr6hifIH76iDCdIWDUjqyXWT8+8d2KQHN5WFz7LLOhlJ1tinP7+wa7nFxeQ1fJMre5VXsIfOI7EM2vL6V8mgKlTZy4ByObxNtiXQJGuIoGVBFpnXRGUwiVrwZolHfylxZLO5COza12cAS54Rw35miLnkGMMuLsskf7yfTUjOKSHe/bGwsd+OthYgcX18zpxxp4q63mmG049kTOOn/Y04r7NQjLh+X7d7bn1E7sRwVwMSFjXMITWKCSDpBW52irL6YHvwElzb1J2wxwnEiNiiYCtnVZROY1diXR/kxWEbB5N5bbbAhG9ZyYxlB5se+amG9aN93IKhxgtliN9pF/eiK8waFGtyN/7s4+VoaId23ijD4AdfFfA2ivt/7NFy60o98bYNmPbHLUy18FR56OUkOs794vpf+tSWDgNwx7FehgyP0fOy2fEaCpZ/BLNQklZw1LRn+cdjIxeNn02cbzO+/IrTgitY5kHCtUwdd9L/UwYW6NYQaMMmcyWKZ3fSxzRYzcOCVFMmspn9iNQOn1Wc7Bo4TcMyVWpjyX8Gl7ttPJDXcLg2WMtXSLawd3dazHYdNxdy6hoISrnDd0Eug1xW3xGpQDrie7A2EvLDThJ39W/PCymjDdVnnYJChzjZle+pB666IqAA4UHAG+F9+k5XJHUxwspn0eX0xnbE/ypScsIqjedpsSgS9hn/ZcyCrFDUnix878mj31ggASBblrvlKfRRGg/up2X76jQ05ow/FOwt2cGNmM4Rh5auCbotaLvASLZHLqZNuzW+EJcsHh5FlcpkpBD/bD6mppuBMTM4bww7tHHVHqMuYk4oZDVFwt/LFpXKr2DNhxjgi/Nth+kAmz4atR04WBYK7sRV+V4BpBB5HSivYMR8IHJkoCEylDTHpMg7GYu0qjKPjxU2jnqkfnggRpTUmLwGLCkP+RuyeMwlsgkwjWZh0VClw0L+m9gdcSwrwXLXtNULRAj/PQqcSPmWbrM0CoU+CA2M0Q5ObSRQ6b/SXHgtcH3hrWKDonLNCrdcpNFzpY5eUz7KF4pQqw5yk1mdFakIzsuJ/Cuca46yaLZVl/AXzfqYFf58K1KaLoO0EIBP+AK+vWPNqVjT7I7Rtbt/iD04By7vSeCK4yEWWJx2tUwYHf7v+JVolYq225ui3+WIHUZG89govXGny5R3z4b6S0V50TVW8Z2QTq0mqWVnTXLHpIpxKfIDGFOZWcgM4HnBVqmwc+ytT2//1rGbzTsD9dSpYyhK6zbiF4Z6/nzeTJnqHc1Zxp2p5xBgtqcoift+Rwb1UL9xwwI+NE60cMDgtIKxZZD0j/bDf9Qiz2034P+FBudKag+omNL5ZIPgIe6Tq3R1l5ji0x2bobhX40ek9V58p45VxZ1mG6h5BOcEvYGyyw7CyHlnwEAoHWiyAg2FdE0SreyeUxwSBeboPSgxhYEOwPoXb4yfSWqR91EUb9pFZUA6BSUXrvBF9fZlOmKZA5lrbjH3jHqGGy/j7sU6OSwJ6tRUQTXRSeBcAGH7ojkSYaqGpDREMRa8r5Weu2lh4NQTwPVV2wYF5hA54bgLkn07PCS3JwDsoZjw02AKps3Vu5pFzcK9l6fX0+TDxceieUkYINHXblIRPvQp3HQR0/F4j461VQ+UY3A/dPiNXFXpj/ecEERj+iPU3MydgPmjZXPHAvMo88RwHaoc+WCNUABU7+vYanJqZl7dk7ZzuwLUH89TnBv7TZqaYEiL9jDKRRYO353vAq8NUhtfv2YC7DtgsVcPCdRN1L1uyS2r3cgfHtbM/DUMOD2AdMwxLqwVdUCLAsRxmQZ0/gAk6xeBiS+rkSWxKybu50XYdS1HGAyyr1eaViev0q3JMfQZVjqKzt6ywZGIzxvetjy9hyvkbtLYorCAMHxtWEf485fXTg6ECRtKwqlKYVSJtEyTFspxzwZhEtgmvyABqCR9y5WG1BeSumqAbsASINbimRnz5OBsib+iOPOIErZ3TRTRQIGM9r71kfMyVBcUz6oFQdrbBe2kjSemIGZ7lotqpJUZECks+1ga5JEDVasI5j6DS1qmGpKHZSpAZTcfg0jsK1q1upNw3CXeO8tMqMl/K8TVV5E5vThS4vI9y3M1egGxFbbE8waBBonAr8xKnj2qUnBUIiLjbCSfY63PTexqAvLzOd4pYOjG6VswSVxms/JINUTuE2SrY2yQzR0470T1xCi0jaoLZqwdVf8nOQIB/yKLGevflD19Rxwku4wyV8Mh5Il99I1MKKuV+EZ1V8+o5vOPTTr4nTWHo6oeSDFkY3XMfEZA0jqNdiCM4ZGaktQsMF6uZ2TqNSqGwiKXanqWnt0okqfZd1lZdtGQMqYuHkgpTBxTwTYWudoLFExduLCphibN398OQot/ED/zHOBd8fJFUBr6KfUDR0yK1lJQYKQOTBleIGy+Ef9D4MtmX/W+rFcN5r6EDR3bzve1uKZVHtRJ21yvS3KXjhAep2VSaoeT2QRRQnWgSNI0XgnsyMR5/ktAPBFfsl3hv1B534FXx0e7fiyFpZw5TBsxbxQGAN301+myqXaS/069CDAoEUwQ5WehLmPsGQFHlf/pv1YzXc/eCSn9SkraqSIXktRRA3W3xXX76/YKV8MltiBMHdbPf5i16Mucp6cz1rHErQiOygoOUqjB/++3SPnprZb/sZXwRquDdPxv1stq0is1FFCoo0c4cj9OtIHVYOHdOanl7f0COQNXRTIz8n6fcHJgJ0nj3Xjs/L9a+ojJt7qlPzKM/ixnFFaBeKQ0rwQ9r4cSQ08ri4K0JUydJ3kjbcr5CoaWQfP78jQHLLqr0E0GQ15Xgc9hG3XhJQmg4I97lXONO94aEfSHnsgBZNzdfctbumA5jlERtrvnJmWWwKFzZ7d7e0r7B4AmCD60IoKd35amKsjpE7nGRmIFu/65dcXJDT4R8YMH/GcwRuHcyQ8iAkUSLMEpykO2gxPhW2qCG0GftaBDfPSKBnK6SUeOfLfqDGw/uMAe+a+sEqMV+CLooEquZaNSRz1HTxKhievkNMPs0JU8H6LHdcksdCGLlQJouv/u9Dt/yYhdGPKPBQFMZwh/9G9M66ILEnOW9+urhP8MCHIr5TFM8/2Nd0m81qCq1H4dcL1XZ6lLxOw6WAxvNP5BxZl+q6z+7a4ghN1E6EI7sh5k/HpGgpJsTX3QiItec6xvblZHHhjdHrRwbVtEoLbe8ji0GaybxCMkNLDoKES3fslkeiFgIY/4i8cQ0qzlPbn/2jQbONw2tKuOBQ6qo9zGQyPyb18EJwfBNc/ZiUJ1lgbxz/lwCCvVIe8LJnAPD6wb7fYQBdJ5KAuQzJkP7x+lUtHwx8QSi1Kx1lVn2vtdpxiCwpCHOOYd8MuNu1WIWBucjeWsDtM5buCvlWwhb1UpVcp10CHBV8VS4fWhzNybWzQVnuaHqdNXo2ERkFCNTb6fes7nH+PZUsT+Y7wHowgXYQcDB4tm9j3b1/bbI5o9CFNLmbytAobikNSDHx0aCYHwPlOioUanqAV62k9aemZWyX6r0ergWWVOYtVLearvmdnIF5GHAprkpLAJt6+YHGR55aBMXogWvFQdW80++T/Oz5yKhReZZcHeOEeaPgK4kiI6I9aVz045nqo2SL1+eQBSMIZQdXtVQ0Rnc6sGeWI/d3yFmcCsXXhNNKEK+/LqjGvtbBtOPXI2+xsj2hGPCmwbjt0Q9EGXd50b8F/hibZxIiVzQ7a49G2054xWYUEIoGxH2/+mqnIuZ2mlBfgoXRnnNmdnFuhr5jUzDDyDBwcLb/ObdPVgZc5T+7ZTweWgiwFQmruxNdLZm1bBBBf3LEPvuHqUbLrmDrK+22qJdjWB9rQaukyiRzNAtRhhiewVLGU+shKtQxgPjDMXhy7HpQykFa8JZO44st1e3xOlVsHnlZ98u16mJtLf1aXWbej8u1yIQgVQa7GW+igdG7PxaYVGPhpLK3CYJdrzg9nnRQoaVxlP6Y2ZrNORX5xB82nO8yiJz6IfJAXmIFOi1pJ4rZDiC34ym4r/8rW7abWX4DJrwvpvgyjiiOcElmVkUydOQuvtDBPG3N/f1SeaiZ9WqIBTZnf0ynVTe2LgsZtt2T0RKO3HOGpxRNdzNwSm/MjnMeoKYwsi0w5zMYFGA33YPwfSnIwk7v6JW+D35IVof9ytVRWckpM8gmhZXGye1elI8UB0Rt8P//l4f3gjAAgWRIDqpPYx0UXas9uJxHNxF5WfQYWhNMM4DmEaJBaRTRl92NgIQBrJXv9H75k5gG1xewmaO+VLO+zwaqmmAW5K1hlWnwHbl0EiLDmhkOzebPBw0JIMQ3fKtz0OMWMVRDaoLpeAiPCJIKrUCJk/5qdPap34AmuQBnOIaAylNIvj0vbULPQYUTuFdk472wlLzvojaDs8m9NGymQ/icfVom242luFPrL/EctvAnE1lYcN+WZ9MBDy/ouoPWwhPue6nIe2Zlb4Ta/Ws+PnoWkdtp7+sOx4+ZGpKhkPcLmoOk+QdfB4emOA/psLFR1IrTLWe2ZavRtrCW8YCijWRkwaGm5xDrcYBZTKT2o3QrUanjyz0Jh27pWAj+cWKf1JefMZp0A/xrlh4ysk6VHHCsfM1AMenB2rmS2UpmldZxgbHporcgK1QKciM8g1iBQisJGYD3woSY60X+y1bdok3qbtvrjKGp7EGkQ0kVve5r1EW4uXkB/taqGEadqGh7IOMi62kuENejgmHpDAqtKvMBdd494beiwahCjdvvpHf+9VKi43aEt3+nw5xZ5rPityJ5kIXwICN0ORWWGecDryjQAJ8bwhafuTWQnwSUr9/7+QkNAXCwKu1Gd/esHPECySdBJ95XLuULPTpwh6MJaCs3/4IShwL4r5Q0EQFrWuNbV7kiaJawR/mssrYbL+wcJhG01hA8sNFU/+/ca8WK8drvQuuzOJBmM0himcw8u7fL3exiTqynPVi/y8b/IcnBEJif1vr5BnJRMkmcV4Q5U8FADPHEPfZTHsNSI6Mbkzz80K3ri8Z6wC+GO0F+YHsedTw6LC1UCiPWrFeAG6BRmGp3x88kLpMAbzOhNJPIUy4XVk5G6Zyb457GTcB6wLG13gmhxwOqVrFMXBvEJw6KLeY2Zv/tB/ZL1LvTzVdXvHn83x3TkmQHC5PRc1NkyrX5gd818qauNABlnvl/CkEeCHqfXKtUQ8Q8nh3QyDG96LliAu5XIIhRWFQPk0vPqEFtA853wPTS9L1xp24mReC3usOBJAhbiwid2pDQQ429i8DblI0HiqVEuWBO2lHz7wenNGsTAg60yElZhIrDsEukO9MpMgXz0zcztH1NvwdRkPuDJU/GR6ll1z+k/dPvODTRRw+dy9F3DETzq1S7f2tvmZESrgVagU7LoRUywhXUwAs6uUssFMDCcIofCGnSuelb1sVo+VKh+xEpmlnHSlOf0te/lb7WrnTsFJN6gZDoDtJd6GF2l4sKHkN0blBN7hNDlQb9EK9IHrXphw9gf5B/+fe3CYQ15+9KIvwhtL+wEaRAaVjwRJUwFIfU3VYFEmPXq39GrPkfIBRmLvXV0WGPmU0xDZTonz5+5gr8EDROzz0ZHr4m4fATqIV8ee2jx9U1dFiLtYQLL3pQOjoPL1Z308te0i2OGC3QxnV/KUcJGXZXSDCfxPcps84RtNy71RMAVjj9lUIIf5QAB2loAMyLakmNUAXVrEdp3oNhxU+nrkXPiT2A5y9nei4rIk+wFhcESH0x8Z+QHY3eMmT2A7KS6TJ6z+0r8/z1ZqXjiYbIbdYcHT+Q4iYdO4ByCn7jakzd7Q7RKhM/ZWDWBWkg42inei80e/Qw4DaJtcOc5Gy8YVgAP7/kUX6Lf/qHD86fgFsaOvu9Ibd1Ua5Q6iLKwjf8vBkkVYaaIZ8YcMdoAwMHD5ZBSRrOvf9zasuPJIVg3xcaxBmvyfqXJZxFInMCjJKBO6p3IrIlEGb3QgxsuPL97lEMYjnLrt0NnUljUDLm5eNrNxlnzwCDcclMGjSqA9VvHLnLqq/5rwdrtpydHnKIzOVx1WSPdD+JmlKmTFDVENAgngefsH/eYx8yDL1B9KOEvWMV1qDk+Rb5S4xTepkxYDOrZ8caMVFsAONwEKETpTsQRWPJ5L/XU/ddLNC1F7KsrsSQYUe1FbF60N5fp8cMUytYVp9Xo+XB3AVEQLkd3URkdduBFg+We/+y7B8MQrDMYU14dlvTcx8CG3qaXd4Q9abZz3xTAEzraKjXw2Lav7f+1P4gEPWrkXvffZXqAMLrnys9qodUrbgKTE4DuJscMj+TPbEhDxfGTAyGzruJNpoohkUa2eQHyPojlxyryzdctaQR5Z376vzl+oubQ51h1h4bqBFuxwtbL6xZP6pbAc+Xm7kDWGpZULgvW0izrV5uVrUGenILUqwCDJWLUlQMHVfC0iMeMbEoLkIQArzkzaDmLSuN5HvClciQ6NbJmnb6kt1QlLOm1VkAW5Jbspp9Uln8FJkXD3ZlBHOX/pSGAUyTy5qRmlm8hb7sJl9i+dFdo9Stoqto7a0u0D27p15yyJUFsB5/IUh29E85gPsIMFOg7HmfkZgQ0I2noVsT4/l5fQ8AsMd0P54bGYm+5skhrZgD7hfTIiszwLBsxN++LiJmjvf7PcMgNzKWufuC6iM2uAeJ0oX6w2NoKABfSjnMRrMArh1DIMMs03sE0dD26k/CZBWQ2T/xLzII7KoXtnDGkdilHtJePYKAn51UDxXQ9T+gX/MCbBK9WzedhgW/EBHP2bO4lnHp7nrcE6BWMkOPiImxzJg4Af6tblTI+FWNX6dktEbO1zU4gjv9rCxCzVADldv4gm4w/BrTTuL/v3qvRdUo3MfajIbilqcnQgiC9xDVJ8ztVm9hIfzgXRLa7AK+yfKFkePzzVXL1WVu6JiRvbcBVBULZ2QxaZYRNa7eNgVedsD7+mMiPJguLgStjhzRPBDuLO3gBEyY4e3vqF+6dAnHgNYYJJ5/dsA2kLR6o5ZegaSt4n6raQyI4Ef7PDCY3df+6GHTxfu811/XfUiISxAraD92SoKHgX1rXPmB0snmdXpvRYt9vSquUvsvMQggynRrZTfhwwg76Rsgk558fnh6pmKAPv8WLUWvCui74RaSZBMOA2nbW0M/KBC0qmNgjiOeQcLtVE5AVGguCCGhh0MZS1c12vyDVxNkWJJQy9+90skNBdJP2zvde04/ynsqYVu+Q9XARlPyONVqaLJS1WTDxTwBIcAAA8SJV/CsB1Gkz6Th/ntR0FdsAACaAkm14oKkXmApE6H/pZ7qxL2hZc/4EMVZNI3arSLcKo8njTgasr0y21pE/hzNS23HNbDlxLJC+p05U5r7MJ498lc7/KTET+Isa4p/b1rs8DYD9fGJwmu7nRsffgABwWygycYkVpU7bVYgxsDgsfQKhEI7XF4Jq0ShEmEdOFVDcNhuOvZHu2FWlzldFDc/UpK/GSqbiSIPlAeiPdJgx8jNUJMouyCQNIO/YZSR3BwiXT0ABYpSelP4kQwyrAIuU7TcQStSbb9qAs4C04AHWoWCUJtAkCYL4NKgd6DGcvS3xxC+FTgGFcaAEsJB3qx0+RTe2xAp/rhOLJLdI1sH2PwF27Igo66NIJOqgiSBO6ALLV5Ttm+4n5vy8++Pn2uAr3rEqGJbf1vx7G7Y0Zz5RjbZitAHOzxBTHZndj2iJMFaOYoiecVDTPsQKhd/B5fzngOi7m0cZJk245o9P6LpI0YM82fwgmGTF0k6U8r8qzJ0/bwhCAoukWj8FXLODTA5GRSvjdg/4E6M6tlCwPrlALPA1BBDhEG7EipRA9+qjaIn9D7hh+Zr6/8FsMx055KSazMMgJrGTtCHFB01vQPY2HB5fpIYRTmL4GNMtGmfa9gzU7lqsPIDVsAcXZdArPtaaciKhd/OIfoRoy+pnh9JUKMp8TwWe3+VtQ9FosPLC5dVDeFtt9w0B+d+fQV6D24kV2OumF2mi5HUhLAeLIQdWXMRSC/G4J4IG0p7hu65uvCF4hTvQmpXxOPmkuRp07d4CRVw7t09jBYAKKy0KTa/Ny5AnBmk809BMFXeXS99HBE70zwLynTH2XADaeGD26UaSejhuRJKEiGDnmXJx8kQ0qsR3DaL5OdN6sdJAsZXAj8Zc0H/tn4eVUpjynEvTqDo8YFs3E//GSz20zT3iMikWNJCNAAGTHqASj/gwF9wDLgVaggcIud6mwOSy6OgId7O9952FtUzcRf+hW+nR9PgUQWBr0I4YoOO77872f8/2XqPA3Jd3iXzHh+a0WhJUFjtPIAKytb5NgqIy+0UER1yS1ngodRfQsVCOmjd/K3GFhP7RiS5qSWb7iewALODsMpMB4C8TXExoecoB3mxTFFxm/mNRS1Gn8n3bjghs8QNtPQRodX9/gnED94fcLG9Mb0znpwIEIzdZR6V8XURhKljLCHfSuDJhvjXoejSNfME2LOIZzwQv3z/bn0u8JinPvB1KPwYXHsYiOQjQTEv7jqhuczQ/ZpJcBaiHcNb9k4FGJdD8LMxP/Ltc5tvAYOtqQj99sQPNS//+b1+mlwssGIimc0eSwJfM79U5x++KbBfmwlMlcG+T2FncRMp9N3n48rijTUP1YK9E7EEpEhiDwmDBCVbrEncc0j8y5VpqCe6BZAf59rdZG9teltlS9mKJfv48pLnIm7m6cnP+wK9ZaDhRggtKpYveWSb6OYZnL0tmIBsP28UmGU+LMo6n1DUs/PR0B81OvUb/OR69Mwprpnw/E1lQWNxDhciN7W8lzCWINXR3WuvaeZsUU/8V1BNxFDtaYGzMyBRVR4X+oEpfbgALvc+cyYaZjYjRkHcv77YDDN0RXjSi3AAAgaARs9+55BwRu+pDXC7/Tl7JkcBiU4gAORWfyUeo7wbkQGcXx30ZPwqGYds8wm+exkFZKN4Cs/GKdtXcNaoB5gzAVPFiFrMMDnVH49eLSw7cLphFG0OMY974cCCAvR0wEKEdPAEAfuH3LGnCY64+7mUxoIio9L6acwWe3EGobKwVYnLguUoATysDb/JZjip5IWTB4IAMesIv8cro070TegMYyK+aFYRgxiRgRUN95SUGosP3u+2j58Vs/2zAHIAI/BdexmJmqHUQz+jCuUViubgwEB1W7cqBq2oP4dYpbWGaGbbn29uFcCbL8dGN6NYcet7y4VbADlKQajwMCnSYhG+1bpVaZAR8IGWymLuW3lpaIwmYpS6OBAlUNKXP+3iGKsRLv3JKwdhM+dAnd++oykT1V7pf7a/rZ1vfoJjuGH1RDpPqb3qCIqoilDAkYuGmVRl8lUE7Gd96KSedibnQIfUx2ZJKcIt6WRDIVYUueQado/4Qdl3wE4M5ySP6NKk4RWsJhGObSW8pr5HxZOZkRFJgnpkuNqcAokCwktNv/pXppaG2oYqD5vUM+Mb7zUrVhaukYx04tINRGDnLSrYLcAHw92CYQOCHTb0RuqX5EiBgdA+cQTIIYPStvLbzZN33SJXjBXIZL75izS/MvXRsrV5IMAHCauhG6xZFv4zRQgssYTLGiF+4qQ6H3zhBN+vLG4UESzHPbFe9pXiL0ediqM5225vJMvLR2ddmiqIAOAtTlgAhtB4Rv0JrnEf8PccwOSWjX1SI3nRp3ywAB6UznC1x4MlNI6zlG6nsUADDqtlb8YOe8VZjR0V4zL5cEKoigDRLILkyLXNvQfq9CAiWOY84Ny60tqZUhihU65V9I9a2J+LvdPAvWdCcZGKbVjToS9TmEn62W3e+rXJIBM4zSoV5AqoLrXlYxIIW8VxD4OLCc/61oxyYZTFVUDeipZ9Pa0qh7OQb9MTSab5kaM0WIZIYfyQFtSG2cFKzVQt08PiOu3L/kewG2JCpfNGhOrF94kuJYIw0FQgA48aC45zLcMouvWj5xKulL+0AsvqMZM+VJpX9jiTmAsr+lT2LVnOVXcDjIwI4AJohHqu5ihk9iUrXIybNALlvm2KYI/GB08pngbHuziMmIngRhva35Hf9f1Ke1hVnXrnU4Sv3jOqSE29YDS+C4VtYd/Xx7KWdKVNJn/+rmittUFg7kcgtMSMdEiK/w14jThXNHUAK5CSBLcAZAE/Bs9m1t1Ej3t8O4l2b3WpIJhU6bQOIyXfJYXz/HOS2IiwUstD6pFtLTc6aF7POWAECY3q6JDP3969bub0AJMR1JjKd6ieDRIXCMHx1nY0JUGhq17tMWwx935LjF4hz2oPWSgvNxAuXeN0xMMywewXL4bR0EWS8rakVXlA6I7Z2XyXlulK0G6vi6VuZzihGZPwGqBWsyFoVkaUH0e8uNJ4qjiZgju3HjSt3v7NeeHSyHoShz2ejHLaTsmvp0NIT5OAlRVV8iK6HMZbaz4meIQyC8xdzDB7RSiVoqCKE7iB3IqBjBUVEjF7t37Gto+9utCLA4vAnbUniM3p1ZHZtfH+YlikNhCdJkVIxenSUP7kl9Kc3tMQJ7TcigC1ILTvNk3K14JvL3Pan4swuCZd39EJukzy8fLMqQ1kDT6ffDyr5NNSol3YdIc2Sv+E26y2CBgLwKzlJhlZYAC51zH5MWxOIsXO+BB4AOBNe18YhQ0xcyIoXRrhJRHuuvMirm12pLpnKQRHlog+ys3dgtkSr5AlsvZzzJjfJVNPgVy2QaUKmrTQhjGLLaZ8wFYeCPaFsqr1+lPtnee5CN+nGnmlOwtpGIC0mScmYD5pYCQ/qTI4aQrYl1e/+WAxGj3l9nWD5Ui3+HOyV+aC32X0W0pmygAgmUBzzxzxX1B5Z1llN9lpJzdIXi1FdfKxZRptH9/nLvA9aYGVHKD2XWLYAUar4oDc0TPdPwME1ntn/dafq1nQd3AIqrxfDRsEd8X4xj0S0/ByJyhDySDpgqMwae0kB07U0n7QKaCbkVfLDkBDlAgPIZ4YHU9HYGur2LSRLmJ2d7eevVLdn+IMczBsGClg8eADTiU5Q3ZnWroVCnKAm3KjG6IQU5I8mqLjYYGjMGEkuVMtoTMRCh+FMg1Qk+ssK7wl/A5bWToBHOV7l9DralK1vuNxYHzReVC1S/F4bd9ks4shxWb4xBhB2vplLueeDceUYrHrnaozUSU0HSqcmztvqdCgcwMLzTDLcGfTsfDCcacABPICR4XJGEWtSYbx2YoiGafv1FoCpyn81eOTaggLgrO1zdsDkASdd+S2UDS89tPPZtnht50iK/RHlHPxok+5rVaCtls7ydJu2DCfD9EfxwV6iIKhCKXKskccLFsLnMgTV2VoNcavzX/jQ92eTv/NwNJxFHkI2bds+CLva8wJ5g4XTNQpIDNerfqpYDq1RLjRTJ5FUi6pNkg7epT1G7mmZfLBe1xraxzDlOJku0nY0pTdor/gxv4mv+OMNvuhqbr4KzgcsndK4YibdjmERZfDK4ylKRiJUoiykycG7Qv9kX9eIREdbyWYxGmGbR/ZV3zc2TWA2PF0Tuk07c0zSW/hmdBTBkCbbz216WYSSd1kTESa755vfTNJ/BD13RtLab/cOB9ycI+3Wj4Hz4nsxmyhPvLyZxapVdLGmYixzxbnvZ/m3x306MrPG5VfDbyMyBIVf8k5KZ3RStNHB3v3cs4LFpyyAldbbt+aImKNXZhBLz2ZHj4d4xty93jBxtWQsLEVOrDt/C0L4ZB70k3jcNok25kiC8ddrg52IdGtR9OBZiiXnoSDqV285TW1LhuFJtnSGguaQTCATRG4TBAycdyFTQRJA/+I/7BFoh1zMbE/VbVKMcnIQHT1RAm4fxMmNN5d1SlYeCeBULu7f7EJR+HzQGpy2lBrP4f0JRpjJzhgO4/NiJhD54TIUAFN+FpZfxOyxWHYyqw68BVOQ/qndr2CYQv2FzdGDFmcuNgdtrRghJ/9D8S7yWPy7CYPCAVJGUYQaHRsaDlJ80tsIS2E1WW87+DK5ahxowOACQ/m77yOqtmOZM3EU6DD9KblF4wMDxoIBkfL3CNXMf2CGruczLGlD2Hz5plr/ZwB0mRcOmJd4mZxME917YETBb40ckAcIs/99ujHYWoS9kUTQ+oxuvFOw+PhnfAWnfRtOAMLq3RUHPRTKM4DEIku+2u1hf0HYRKx7OBUI0EU23wtEFmN46VFAfKOLr9OiAjRL+rud56Jp8sq0biIh23qGf7zH0ublpj4NA3zV1Vs940Hq52oqIJRAp8WqAHhdp02j9Zeq4M0TG5QExDQX58Lvr6SpwvZT9hsbR6Hz1AOKg0MWXsI5Tkkuq8kWcj9qvZOtuD8eOt6Pn9/z1DmFQEkYb5jfJbVWSd/vYIZJD0Ph9qBoDOCseTx/1dI9KDNyPB5WehvmtywoVEdmPYqNs6CSRQEC/nrc0Ge1Pw4A6iiKtXhFsGdSUJvSuFTKjqiTOujBkTyLfCP5gVw2qfNg2TAwGGc/F45Z+dhTl9WHZIh7uGJzyzutQcDkROTLE/VWM992pXGfJyhmD9kPy8UXPH+ijCcpuinL2uLT2doXaT0keFZDWLMUBJUVDt1JXzvy0mV/CODH7RX1hwLzTHwIUTZlNTthX4E1gKiqCmv22UwEf6Sa9W55hGoJvGB97zIgXAxdXwQrdSGgkDdbNMUSVx7dr7N0J6B5iqcynZh0pNvAiMk54W8vHu6B7hJ2liSZqOEuHn/rrGYpDRWvMh8zMIAACRUA3hPkbM9k7YcryZaxjUlDrCvxoKHsQKjvZBlg6Y3YpPd3ub50GvePH71RbZLlAOgaK4+Hwd9wrPc6KGTgA+lcqA/2VcxCJMgZVNaKypENg/KNVgUHbHHbBEO2gEaQAFoI2qI9iI9Gk7g0NGX+N0Vf5LkS+oc1bY+Nibky8wmXSu/ACNki1Cm0VEujciBsgWgDhruyNu1acodyo2vcaT6cl7Bl4Ofx+46c+kIedP+ur1VWarnBLlmcScqMnrBuevLu048OR5kWeTjIHFNRjT4RW+qPqDp1QxynRT4NLt/ezf078G13MQGz5MU++Jr9wx5n7fVUNoLbBjS7ERHshmb7v17o+pegXTyxS8cd5SDbCYuVN4rTV9npXUEHICMkuoIbaUZLTvwWhUNlP/9Cfp9Pw1KVQQL+rGejOHJ+6dkfYjGjPplelgAeilUQvy1kUm5/YqvanX9SE6P4YfiL8KeLwN6mX3vZSJbBK6+m+Ihn6XcZoCvlDwJAfDGa0GaCeUv2AoLFUqMsfmlozYf7Sj7EuBer89juI99wUYHh/1RZEEwQhvjJJzvwc/XCn4WJGXmKuUFBFx2MCD/GSUGTtZj+WxpGHL7CubR/yaJuwwGjkd0xFZz1oByTb3txurAAHEJLyQ4RHFLDhk3rc5lhHbEFgTpAle6dWt7/0udOEolFbx4Z2IJKMexJ/WXqQnc1bq1usWelCfgIFpt3o619ZnHJ6OOXBFg/uodgz+Lj9qeotkaCFNVi4juHU7tGAxgkA8LauusYpYXDG281TQbcKjD6QmBRZRg8XV+26gELQf2OP7EdR+fct2lBh1oE+uCHXbpxaGpu+z4yTVpjVBLY8AZK1kMnAvVNSb0mvXe0OdY9XPEc7XCTCEORvJaQ2mFay+OSUwEhUdxMwZ9Xxm/S9mXwUxatKY0y+nwEIMe1c6ODaa2VNcwbkzaa0IEO5/fU/y9ZeObIi+3gWPr023ZMaLS2tjwqeQpic7rwo3WsiSPhTMZbV3cfcXstjJmfUft4Rt5TY97SCWUVugG7RJTNPq/IZrC44GXKinHHWeRpcLiHp+1fcceZZmQNWmj5Oq3eUkTwzsF1Lha/RRGbpEljcFAdPfrwErgZQxFa68jb2dRIxBWFvgyGyqkgdLqIYwdnebB5NcZsEawHt1g0dTEEFtER3TDGMsZVP9VMUiFL3vq0ME9QpJ571YxDoDju7+pWIP/7PeFyIxcr4wshsn4NJULTiu39XCrc51AkoZJNCuXofr787ADEuPVA+4zzonb9xlnCDok//m6IHoeBakDsttUchFIJuvvGgIyNUcfhMPkYVlql9zUwJTEuLXDEpOalhTVZ4o8sUKaOz4X2jIsUP3yVOUnINbHAYYHaYb+gqS3K0rJXB+lLHebshPQNUxK9YqIshU4X2XjWfThEUvt8f/U2JrAGNIsF4q+revQquKSWNxrUbGQICs5MPOG9uVA+GUKmclSGCD8KFisGdx1oduE9znNe7V4eAIJpjLGk0Vdh/etLViFz4QoHc8SxfnNDd17YVIwFA1wBaHRZAO+pBBBxyqtJUVPnXs8x6AVD5Oz2rFiY2R5+tddhgDVvtoGj1b9Rc0d/lmrzBIhxiJB3qpiXy2hTpBik2vYPfBxYBYAvDYCVUbdfmknXVfotkMLgx8Ws8Lk6wzNBbJ296SPSguyaoXOIoMyXbJd3/8i2hL+IiZOpw/P4UzqvCXhgDJANgVOUZ2vur0AUvuYDmcyBRkMK0vkZ4waBnFvH0dL+v3kaDazuSmnCDK6PVPEShtnU7GI/CSMNPYIgd26ldyrVFLWHOoyhYSUEaIJx+EnDjsdHyJ1lbklfFMGRDq/oUI8WuDc2fa7HN0x1KUvwQ6401no5gWq7yc//UmS5bV1579g+aY96WTxYeCyKxZ6M8qlBuefxkUxQ8zR3+5Kq4+GHPblFWp7iq9DHNJXBxnNRvSVjjUQLR2SEw83sF2tAxFggLfosLmpkph376yfOZN6duFnAmpHPHS/rcK93NxTycHFRSkRjYdID81i2guqaDve0xniG6TQppeaAuDGeVNfGUPAJJ11e7hRS3biuD664WtMjr7jlN1zuFzE9D4xevY5BmLUp+t8MXpTLzleqKFpAxa0UPXaMET18B6/k+agdho+CW8g6e6+/fzF6jvzXUK1ygas4j+pSlusZk1V24Eqn/8FJhAppo3FtH4UnG1f3+DVDcVOcUBux74oBatKWqwne4LUPM7T59KYsYvEDO3J5/UZR5ohJJjjoLomj+udbYFVbOgI4gHEmTVO7jOOLb/9HM/DQPeftp5ecOlMWI2mMEdmnsKZa6qG6zTsHMgARO7eqCW7DOvQvDCCjeb/x0uDcX1T+iwWtOEQFCgiL85C21o8KGKEorhWsIM59qNWCYesDbxbL9KLg0SW0LY6xi5m5DdUOSqrrbU+d10jsIdSq4FT/S4nFAQ1IP9Pa8908fHj/R68y9xY6sJTXI8z68sOMnnz47k4h3F3fA+JW6susCrBfWjFSqIVdv549QyD/Q/1SHSeKr1z68wnJKG+MUI0T/PawSpreOnaTHo62EoSolyMKL/lIiPMc8NPeK7fZPNipM0yuJcR3jSQbmvcnsgb6dqzap3rtZ/hrjdbq8Ivm6J3hW2+wRg3xaUv1q0OOv3AUf54Ba9jlrNnfPGdtvAavLJKFNajvcecenQIuPMjkhIT7Fic0GqaFhcwGap6TTVEU8p4Vym4PAD8bvXGgWye3WRarlQYFWhytpktzmcFWy+sCee7d6tL69L778L3eEnJ4NSn+UF7Gzo08cvPOo/SDx79Xn8t/zFZ/hFTlaUzXSdEwl5i9/MXKsoRroJf4Pne1eF2YGD5nZTHVgdbz8Ns36pYhBTSgkc68YftcsqZfIUEtPQ3D555mrQYG8TWMg2HHywraazstZaj+webdrtMi6r6G+MxJBt8pdimHfaj/zfj/ukih1ProlKjsaD8fHb4CsGWiLck4dDuCuwVu8jwcOtXTYpPKfDwbUu5pNsFv7lkwdBiEjuz3kxDnLZkflEj6c+O5OUtgUbfMropNCyIrQ8xYZMMtnxQaZlYyVNEEXLYjf4h1A9scaTMVvBX2OA2IBrDDXoLompVYtRiEr8Yk+9lCtba+0DDIBX3NqUX+FnD/yV/jppeBRXDAOWNL8sW+qnIEyx2Bbhkm7HyqYjrGyKLFkvR+zp7kQ54jMdsfNxzqoTKpvydsmGrCNWTyxRnD3sov4+I7u8Ndi+QG4RG78Fsb6TPLjGZCKX6hxK0Ot0IALdH6/F1Fb6JQO9yU9YA+iVlJ2GtkPBgV7eCeGULvg/TG4IWOxcwSGKau2sKsk4q1eqxdcmAWyo45oFotd3QezgL3XKGjFNO7ScmAGxAgAQb/IULYrqSxLdG6uH1hRhd6lXvo4k4jx+WJx+dmLj+zUlG4WlHKf0rW89K6f0+RH5UP4yCfFapsOzLNW7INtQ7bTbVluBViIxDGlsjb06SiXQO4AY6SSJura81aPcngOnB5+ouOsXninjVBYKP44bTXteI3D7P3HW9DMTAUFBUXUxl8jTmMHPM7a/8Ie9c6aLaaHQGub0bytkWiHJ0ogvnsu9wqdztW/asm8U6fDQCU3kgAKcBNJrrSN75hVd1V8vMVf3+OrFFgBAPUzIWk/4mTtEMTlcIgsn3s1iIxqB0cWXWFcd7QWIEiIJy8sPzSHbJ9/srgyalFrjZGFR3Ed0yVfVRogIatRK7TE0FOgBxsHPVg11JkKu3Bhz41/K0naY0RKaWG/5dF4kN3yybRkfIxj5eDgs6cEQCs8xx7Hh9Oopes1ceEJgh3Hw3f01Q5onlPKS4KLy4ODIlb3LX0Um9PrJBMJbeqxYhtCFbGThkIrqcAtsfmn5pXLTdZYRgYaqebNwF/ytKc5dXkCQpXo2cXSs5CeiXoMBIo+YYvjVpT1c5rP2TL+1nNtEpyzV43XnLBDa+VXHwCJCz8dJNY6+fogiMzJjT6NAPbUn2jMW/nBr1laSyntRmbFEagC6LwHXg4bLdqVtxAAAy9imJrM6vpL4R9LAUR6gpqxvxR5NqMuBf7KqCqmTuL1VfiSr9HgaEAYDmXUQgdpoEOTs3xeaHhBDnACVQMBQyqFkAAUFkJZEvPZ+J2y4P976Cf/dtjlGcQ04SOyjYVxp57yFJKTuyjMdUXaSXxXYMWKOd8BuS8/PTX3wjA1JGjpjYpH9H/QGemARAVihpUHP1L8NsR33LnTawuaBGFDlx3knCENEgiAyRqoFXk4uDq6Im9HVHMcW1ltuLbjLUI+fmpX/VMJMIC9hoiDNtfUQ+RnRFGos693hV6gmj/nHBYXj7nnrOh3HdmoTJAyT3D8H03EwCjHozhtdZKXa2FYnGhREAqsmAP5dzWwlR4/NdCrESrPVoOlKU01dTzkvkqspLf+wL4OlK9f1iFXlF9it1gG04O9iGZeoF+JU6cOSsFiARq35hVjgiyj8c19Pv8rfiC7x+YWzMlIkQ4NCfC/Q/3YSDO9ktLeu0njgf2Tkt5IFKTqvNQrzHtR+ZK7s3lLBt5wruuKuCJIiq1u+dDUs3J9utzDToKGD0tEpak5kZbkyRRnilcHAhAiRBTkXTCyt59ajOqd/l/kKa37ZJcQ+WToVRt+KSoDgXKHiq85/DU3LJ5fXvDIDRqXiPBBbHPNLqrHVQIBtM1aCkmUex+3RMC6Id2bk3Epp/zW4ZLyN2zKYYIlURo3TIEdVn/mcCzrNsmDGDf0u1WCuynCug+sl6EEMlm2ai19RfnOZ3wckMOXwKLZHLFJDDzEg8r4sK+AiPQ0TVqqGwydKHQR7OXDiL2fdp3wTF9pq7Q7gZWkLconR6AfsGkmRuJMDLnc7dkEI4hM5WIEwheI1o5yU25puocino1LYTRE31wiKmEU5VBUb+SiKntjYoc/v+17V1gr93OeRUCJBalH2rs6W6OyShtqvfnyf0s3Pc9VxnY15u+VxmQMt/9/STMvamO1QnBXc60SELwZlgZIgW3CJmkr7YKI9oGz217Hv/O4GmYL5yC6zC+Z+4o3E9+2dJXDOItUI9ABQuOcSR3wR+u/aYVFCNleNTdD4GJ/bT2QA/2o9gW05Y8obc2MWZhZLsd1X8kgsih3FauyPwSevHmJynVtFGkN0sUcasJnz2kON5m0z05nwRcI3dbI0Kwm4VxjmY7lrHDF2oxBD7Mdll04IHdyQzchVMRkx6X3rMkG39YuVwSJKHY7AFT73QwvLe6sZL45HbPS3knRd8v0Xc+SwaTMXfn1HrCdU8PHWFpn37hrxId5xW31OXOZoZdJH4U+IdLEs2NPdDpZOchC6JfUzqg+XlCuHLjxGK0+uscVeBN18463HZzg2bnmMis35QDZ2//oNowAJ8cwFl+wHEqADL5kbz5wSqt4kFbLRQdWfI5RyTyRThIjWH9aA1pFkCDZtzI1SpyPQ+FixRmwWsUjAVM+uMO5fVgxQ3ZXWKyYNXGQx3it4b7nOta9lsjGIEqMuKFftnzzkiZLZf2ABLjFQJqLlTjCXd8M2j/UJILNLdPc4H2Su1ZbJHsEIVDBGy01jIeGmLLQvRhEUoJPTy5VBY1K5xYs1t/sDClQVgralRiK1bgnndTtqDk7qQ2Mt4XwBn4NcIp54Y5BFSj2KMuzies7zW2NlJhSoOXlrVfGX8/q86R8dA60ZZoAOKco6uYk8Py8w3DfjQ7xJ9WFwTQ7aV79J7CZLCkgAAABFMoVCTSdcFgr1azuTUk8KcFpBz9sjIPlf5cth7P3EguPGcaUCie/sQwAmMdVsl4DvQQTwiD4AIV2ZIqYIaKUQE01XO4/kcr6awrWo5Z7STSyFyhQNK9Tgj03RFXY8Wve7NxMBpH4ZMEwifXTbZ1V+HYHkrTy6AqQsn0xOw9as/omt4QtNnsiDtVL4TxErZemNH/RG6Pn7ge3tT7Z4y63JmaBqLAbl816O6poSKFV/rEoc+CXZWp/Q++MVjbPcFnXIva0/l6MLn73/SGbeJOMFuLD7X2RS5jVUaqUrN26cTBjjmeCZe2yUfBXl5756txsHQtYP3Vr+kyvVuxmanjfHB0bNVm2vE36LxfTELQhRSu0DHNtG6Vb+Vyq6CwRXWjRHWFPeU6JRdh65sLwVO/NhUizqF95/Jv7Ag2okNu/WJWfxk3eMIduWMAREDpk4EN2wkGdVz2jgUiRfmA4w+b/lZnhAXRhZUVpBOjzN/3GVyRfe2evCYxKZIuwoP/iALu/GiIAqJ3T4GG1qPukvYd1a/TTiA1sG54ofiUYK1gAX6N1nreVyPLksjIhoL9rWLnzdpBnBIv0UTncjK7ZFdGO9/Le7d2Y1AQjytLGvsbB+kUTuw4Aw96BG21L0bQo3WKqmOHh8PbLn32FTnd/qnWosHJqYOUGd54lmqUU6Amn7N9yNx/bF9RWFVDDS5xoBkAJn8uAAQRxAxPl5tRaXosIbHcFu0/OLjE1CbVioKTqNBDT1QwCaxwrnQ5Uzx7+Z1u2XqjWW1HGzvZKlCrZSAz4bWIfeniyTfu6/5q3KSdsEbA4XoxGevCKFPYi2RwnWUWO0iLQGvqHyBdOrXmvn8W0oH4JsnxqlxjL1BCHhkLAMo2qP2zUoxmBPgkMuUf7rRuJRELCrFnn3OixR47eHzWvGSg/CK980DTCklVTNGbVxF7lwjUlnS7Drs8EzOzoU2Nxw9osINka+haXY4eE5uEMUBKDp+qtvX98zU263R6pL1nIs+ggPK4D47MIFb13Dc6tDAvoP56rX6XJIL1omKf861HCTtEXGpYnN1Ef7WRI+NavcDGj8v7ENb5mdji1rQbUIu4+JeNsTwzDKNskmvrZpDQ8RxN0pu9Whrdr3K3SiPpCBengUTNGAmJmMXjBgY5ess21EaIqJplkTDaydFMMXPf5Ta6sJt11GJXOZuYqvOmxTkHVz22WvsmTlKLv2RiLQ5jXS5CX2lKCz7PTusVBWZhO1l0XvWAvYgwddGCzp9FhniqCehFtDGVXJwA7pG5wBUCYKk9BAIHdlp4IG6Jf+16smF3DTd+5W8uB8wFNzSTG1XJ+OiKdwNCwY+oIsLZXpvQbBE5mPxgunn/WGgZcAk51hX5Or2PQ9cDWLFrWbd+uX+TapmyGqHk+9A0BRcEpVtq+vReE4xtub8y2EYWgNYejAbsK+dDil3JthfqbndrokH1Bo/4AN8y/7kniLBng8i7Z0MciplsXYdqDHEG8uwdGgWdD7k22e7aONxUTJb4gzOVhVxnQDB1wMORrNBRxZlmldAPIZE2/+EtNDyjAFcPigVlEZSTc0X3o6kKdSISZx+MXH7TMSnJwJvCqerv4xKWaLUJkpCJn+XILdQmgGWdbKFXundxeefs04A2wFAYxOkn+TZoMHDJPBu2VZbeyvKZ00QnboJXqJOcAoFD0yUk914X2c9gOuSehPIN/9QT+AX6XlnRbnhQlf4YdVc5af6u7uz98fd/4NgwAMaXiP/WekpLYh1oNOf3SNof99Fl4m1ue6wU8VP2O1wzU2c0JLthq2IM7Mt5T/uFzUd2KP2K9c+zE07HZGCj4QnOwLqVt0wJEQd19fNhfApt0IQQdRhEI0a09pSq6xt7YIuGvFfY+gyowzARP3DhwrEXHthgk4vrHpBKl4mrr6Rpby72uszU8xG9DdzDPNifFcQSuW7d2hyZxUb94d1Ws2ZGh9cA0V6tnZlo/T1QNYt3jV10gIyLrO9J1i2cotsjxnOAQkx/z2Wm4THXS3t+ggvyEWUalU11SZTl+1JOZ1ayIpyDqKeK4V1IP4PAs7DjeQIfqbwX0hPlziDpGOtVxmvtAbqgT9ZrgOkbUg4fL7Bf5A7Yn6/tmfXJp4hO2ZeyfH0BnlT/7HJLrLHppO98+XmAVutIC1RcESQqsDjFNdEu3vrs9d7oPP6GWCIlZIqfDXzX3+I/3vBJw1mvDwa8ufkF8gSnQH9nUTVwWbdvW9Ga2eZk38Jc399DlXnv/BzbbvuxF+Ws7vtCKfV0Smd78dlgPCwkcaCYxsRDbEBz5yEOGqjt7cS84J3jsA1n1f+nOWdboyXy3PuD2Eu9ps3f76SsLhX4/GiwGBfZnf71OP4rNhf0VCiD7YA8vuK/BlsW3xt6SkSU9eZAm6JzQ9HabyfLId5SY3d/OSaN1DOsOYhf8lMD/lcxh2oAsphPv50OdpkoeO1M2mTkrfO8t8HByL/qqisbwX8grBgv2vI9wnXbL2L8nnNcwObzSAMbcUPS/i9FVGFObpu0kRffqfQOHIGI3EQiZdt/rprByqOQJDrxBsAmLHq9PWYsW5AQVJ1MNd3CfLgi3XPsR9wPYqhsRQc2Hs3e+3N498RRc7FpZzlHvvkqdBpbFlJH4xtOMOFxND5KUKNhK1JpJ/Yq2yUqWlF1VG2rCp4StcHG/EODQkyaNWs6GNrlQYLoxjvc9YPdbG9CHAgLQeiQwXinqOpSq1Wu1i6X2IwNncerO9cROypcbyzifJbNhSAZC/mR32Ie+DlDymPeVh4AHDk4dyBGltoWRjsw8yNOPRHIcAyfFkCA6AVurpKB++2EV+88lqX008w44uDibqnFiAgF7HyD6QSv09Z+HN9XGKwkiInSbUQfQaWvpbldyu+getkNTcXoxR5M++dqzmcq2DJDxO9+SWViOIuNgjF2KtuDV/3cZs93VIDZuT3K71g4BJTt4XDvOujs9pWYXRw2vqM2HvTKBW2xtS7vNVS1sI9MOS+CzUEN865okt/aGSRObNeSovTMA6YVJySi303y4eNN+3/V+8KovIoaiyXEnAdrX11ypGLQkb4jq9uxHBHRXkuygq5J17u9OKznm8HLx9h/U1T/BKLFbUp+DK7EfwQyTYikBw9G7w+hn1ajHDI4/JaPF/qxE5DlErDSuiVgQurzdZdF7YB+GO2pNc4kfxNkzbUHYMoOHJy5BONjkqKnMcAd56gct94vJ8wcF+A4YB69Q9TqOxwgWpifjuSSDhrVlm4NT7SLswwTsLwwjdQvqPXEZ4rYE7Ia/Jbb/9ncQGRzgzpCxB9wNVa6FGPrZ0bsE3edkiUyzQgisAMl69elpn+i+YSZnLqJ2qtTNGVFUedOItjseQO+mpLJzwowkOu3rQUNBzPH2Fi10OzF9HOV11faPsM+oxurGe23juq514zCMUqx28H116a/HWbbNqFBgKi6nkt/G8gU9Qm6XnajCLl/ITmrQqbiVdrBDv+AVOmYzX8B8XFAaxCjjb2T1jhFB6P7J70BOFQnpLLjzROzFEDq1NTf+9co105ag5Ih5ws75xdiRxIRawe+3MijRYaTyCqhnxrJMRT1QXbrn4KlCmqngmq6zQCbUoUuDZOZS6WdD6fZkqFGSt3BQrbfog02DJ3OEZS9sn5aaa/IhnvxFTa8gViiANTsiP/SyyCKFluaDbR251y6RU9J2nQVM0k90k8MgU+cuM1Dc6xObQtiN/nlwaaoXiTEW1p8NzinGK7TZBHiBSXoo30mtZsbZU5T359wQDOSWytargKLvyMo9OCi+GII1ae1ko7V8S0E6JWM426rOPopltR7PD44i5v5MEzN3LsD52M2MZ9F9zw6yrvNZVy3I18FmFSASeh1KHLoOwKlULOvbJ7vZ8Qsz2XJpdbfEoW1OZByfT05htVw3/V0VGedFMmyEycMyAI2Z05KSCSse2yObMyRNhBab6Orpri+IgBRqj3wIPq8flN4pmdPZTO8aWFYa0nUHBG6y95TKfL8xlPZdijpO2mqn5oZo/d9ps61/noQlinlmbFn4h+3JBuH9x9T1kAWIN1h+2f8MqUdtOErkNLSfQ9zEgwXh5+HNYOwMsmZMaw01bKyBJkVJt7eD9QTpJlyo5VVZv+k4z+uuqaayrww9M4ACGSiEJzp8fA+N3Rgk/oiJ5p/1LJOUyt6YIHOAWgheWDkUFtKt1dmHd4/99mFCoka6MkX4iOkVzM6FXTkp2/rEL/8x9fzpluJrPZX7MAzX2cmSQP0Tuiv3kWxgPDr5kPlttFt2Vr9IaR1rmEjE3ZFKXehxpmLbBg0ucRL32sSzdZruo4p5d8kwZmL4ZzVol60utCWUTAQ/2XcCCVG3/nMAs28TJYc2LcgT8OL9lCNxYboB2C0OrZUUgYM5mangxLApyjyJ57QOkicpgrRf6wR3W7N0tqpNa1gfXVGfDGVlALvQX4bwEd1x14tDZ65270uAO71ZsF7JLamWETNhSJm4D+TkT8j5/krUUJGx2cktSosX9RoSpo102IoPXE7MS+CxSNKMF7utQ8g99j+KWqKtDio6aDEn9vLD7LNij6MiDiOaB68rDhg2sGE7etIVEE9b1fhf00TGWSYPIum3AvhuwZl9Q7adysSfD194/CHjzdMhtIYjktZp2sB3eyXDG2N0EmoF+vzXfiVXCX5n/3Gp32l7RjrfRb01ymmpVM8kA+1L8mznKuPZROIheg1F6zGFODxvOUhwNavCInYs4bZ7c8kOJSpJpXp/t1JKc1s9IuSXeYV/DRCn9me1veEnsK4byZDF0y23wz+HdEVseQMiadI6s7E4ciuGDXySFgIC1EqlzjLUy8yFAYAqY2bdh16nq/XTIvk27CsIxc4a+MYS1SkRNrkLtc0eX5dRURw4TERNxHMNHmjuzS3jiWJZM1M38764jXKJzEqA2hgMLn563B0QLWk0ToKNQRSEE4oIt8K99IDqJUZrimygURgCn9paASslL3BdwjnASYEzhO/nyHOyvQu3SJ5Ws7ZbQozCBKLmABfPM4rBHPdsR4FvugQqhQa8CsPLvoXCTQhraZ49uAJVfcP+/ym+3yxpkOsCWM7GNRYVbjxU6TYnWFwJVojm4SyjlTh+4B39CO7Ik/Cry9oVRflfLMlKLN8FgMyMdxORn7rpgwU/ydQ3p9s70wzLg/+E3tI609SEFm5Qa/NqL6N1DeOtdwA1/RIAvZfSnbjRo3z9VXybBhOpAQO3N9hykJuPPQ940U02buoE2yXQqF3/Whfnp67HZgpcqcCWN3aLYSvhvbcEAevXHbpvZJmpzzEA4+xnSbraP5gzWdL57iB8T9kh2ulRDoSG5V2Y09NyJ6K4L2JyLFRmjKWqgY0yY/LOF8LzdwPU56yt1P8QpYfJcukVjkLtCFj3UfRYNNVSQfrro41a/UfkH/uzADJs6UT97jKamDa37Tkl4SHslHeEEc3JN5r/EsTYkFkaRBmyCnLoBOOcwPCtGS3dZsmWylY6DFx+wUCCQ+ayBnG58gVfqtQVCbkiN9TVxYucaFsbi+lsG7SDGmtBo50oMdXFgLWUOafXf+DIBFuXUJ348t36Vsdacb9kc65fVhb3IgaIieqBaUNRhZocJu0OPO5m9bLP5avO42bo3bcevGjwM18WkClE63excweYItPq7FconpJSpBK7wwgiua9dFaYuTiHHtppam+YvRKhokZYBszrHrerFRqZPkIbKvA35Fx9jMqkjlj22R6BdDzw5Wn6DlAWQnM8VAM7qPehCI3hkRB5Iq7ml5Gloh+NzOS09SXydmEPIs24PiuTKf7WwHUS8jIfv1+JHfh8JWyMhb9Q2/VbwJIvmrG+tHsDzIsbHr2TNIto3LW8OmzZILVZ+zY2Ai/waf2R4WhA7CzPXtOFejp3Qwug5demIFf3/ZmLWfB4gOu/xC91+DcUuOHiVf/XAbVYpE/JtueAr9Kh9BU5FGELQ+4g5epIMxBhf0/nfFDCqucnnFP/hD1/UgWt+DRBHQS+nyNxg0YsdNLAsD+Vlb/e3g/YyosHGF2svDsqbSxt09VrYTqRIwZdMO3dAS02Dp0Ffi3247ExaRTv/9NfhddEVI/9a8ocG/QLe/vm1vd+faSAGnunidCQk8OQ8VijCMA7S7wYXmXZbxafYFkYRWRvC3VrXmwE6Pdi11LH7X9/LiE/8gD4ZYU7MDMT4/VyEwL7hyRNdV8asjoQ42pYFWS+XIIhY/5UQc3A5K94cV/IWjpnrGwanDSseGX0HDqQo+WdS/nb6cYA07X1vLV3qfmHmRWQpx1t8XDws7jk2TNDChRipoSbVbMJ38HN9ScHJEI8+IIW4ODU5ZYog++5mUrp9LXIM964qG+m+Mk2fL4Mv8hPM9zbBmLHYMrSIfuhipkSgvXyKh+JgpGtn6C8R1QAg2FZqG4Oh2W6QtjBwJQEuKieHZBmK7GHrb1sMDJJL2shDFKzNkXkjqvbBS9l6aeKnQrzcqnCwfod8B3kZrhbzwgMBz7VfEn2LV8tPj1ROWZNELpvPS8hnMpLfB6LahcXrmFTHIQ8yOyiBEFRaGAo1V+YsacQICCrCBEtHY4/lDIonfGSSMgwQb2ise5sIKCGp/VF/fym2AZuF8uuTUu/qYeqGGshy4rN5N92wLfg4tuI6D8BsDfhwh6s7UsjW0YyRCe8oipK9ZG7XSqVPQR9sIoMM0YFhIfLBIACHnp+iQbG4OOTA3gjBIerboZ6Kjv7fYLxVKCLUvPuAjurd6PCOTqlyMzOCHTMzz/p/iUoZ9G3Gmr+JvniJF75tTPtqy8+5w+xoGRIGIQ3aRLuOGJdS44N+N6BB0g9eim5Skb2N0ViM/mTPCXgWOoWw5cUZ7qU/UxEkSYu/seEqUZwXUkhB3NNVpIxrPFDju6YWWpIWi/a+sQiH98KbL+1hqM4v95frr8N0if0Yy2XWKVBY8d433xZ13Fd04W7gtAWl/VEo+4QlSr/KPSK7Z8HZi60Uwmj8D6IFnpMJ1vXik8menTE0J3WtoocPYnJz8LTcD7VR+mjBRcc4XOHOLhAAABB9WKWOScq7cGc8X4BlnviUBONL163AOHkM2AAToFftpfL5UL3tabEnvOn8eLcxT2t/mqvIsb+HQMkASwBfkkX8feB9+gByFkuH/525Poz3htTMV0DYdHAqBAH08VlM7IA8Wg7Mo5VwknGoiMh7Yf+xnPEf/vc96A8xVyKkWE2HwcdUk2ELLVxKe38B7VahKSLwtXtEO5u1AWyM66oEvzigEPgOf1YRV86+TZZ2VXJ+/XQEXP9aU9EYWlmcFgpKUmlUz2ygZ+TadvCasnFPl9tHIESpuib8WNLTJj84n30hDhFUt4I+VudhBz51VdQKQ4zOu7dMFnXxaluVPjlQxxQZyCQ8VMJPnmoruekhjRGhC0Jteh3En8DZuXh1vp7bIhjAB9V1/Fv9Df7AeuEu3/e1QGviyUXqlSnxkLcJbNUqcDIwLpEXdjiA85y2GF03qMttoP2Kof7PY4xKZdj5f2pfkQxV010OMrt7G1uKujQ0Cz3vkgCPZf2j6qHKu9e0aSg09Ie/v3UIWd5Cn19oeuto+p788U8YPcS4Bv3pLtHQfxvSu8fGoXVCKY9oYAY21uWC9PpNDGXpSxs6W3nsWb4PWcMiCBDlyNuwVe8ZVoOGrv3s6eAiuOs/RSDShrPpv6brl1ZPaxaera/OZhp2Wr96IvIUWUcX0VogUqOUWpVLmRYwo5VLhLQAH7Q8s4l2qw0F5y0AQP0T+wVBM3MTU9+I2AxtTMSEECYFgp3Q/e1nXcv+JiWqHAh7mkuD19clnOZj+YlljnREKnrU/Qwadqo4RPv7TgqwZTSJFgkvLzld+njlrXqRLJ8KUHWGiVLpGs1KpU41/zw3/nxOseziLqUUmKgVY6FemyrsNef/MKjakHBK6I8DgjNkz2eNPiqMyaXQqUawHysfkBw9YHkQ0e5qr9Y2YSwBsaOpcr1xg4eEX/xpWUXmyNYgEZirAlHOKEPTmcVS2wYKrfqlVwKcke8vOERtrFkagxlpHYXZ0Kknw/4W3IC6QETuRLnyBhyqyGZqGn9hJnB4kxvq/co0ACZuRrQ06XcU3h/7fU2KLndyg6XW4c+ghd2FNAGyc6NYk2fVKInHDW8kceIKARFQQW37g6pkl3NgJuHo5vC04JcqbvaIavX2Pangtu0aklOVDyTU+IaeLK/xPweY4upvbYLvWVqZEFUBIrlMcYFSrNKDKLcvno8Ivdp8HV+34Ol3QC6HZjHpVXtkMKjjy5sN2Ys3Xf7X5/DIS+7n4VyzlyqLSCAlTzTJtdxXcOXoj1/eIzcri6/Zr9kWZeDDutRrAym19rPoQNAY6TiggrUrpp6jhQQdvjl4179xRrsdfu3y3M4467oPjiD7KsBCk+uMF/xQ0/4OqVNnvebqFOlayIOtayhC+sN4jVWg4366QGvh9QN09svPQtvcVDuxKRI7gJ9bFE4pKjhwl3GJP0r7748tfeXaq0yp2caonO/J/hveW4kygE5n7kwWTwXMYNEx0g5trYa1Ljr8vGPgPEZEubGu03sq02rC2LpEoWFAsSuF1JToLnkWFdaH8TD1od5BscvHdWub6NKjSMeXjcjil5Pvu7y5v8wU+2x+FjZe/M/sQS73VSOvZcxfSNBYpLGNksvavJ4OcFqp5sP6pxa4n+dBGf250rmFFrZxSYHh94Me9kVsixylH2Kx/Nmmhr+9EnOtGZW+x334jJbsH2OOtUZup/tWeNX80yhUoqVOy6kV3ZoYp2SOwrR0zgI0M7ODrk2pZafX5rugUYVCr9d/ec53Nz12LyUgLz+em5jfhnuspdvCN3sLlupOLvwuIpNgdAzW/l54T8/OAyr+JnMp4tshHiXL9Sx/gyGJ7cYGvEzHvHVFy6K3OTUlDjJkfg+dfK669YVsa1IVqnvmOQwYZX/BU66uuvQE3CoDXoNy8rpx87QYvOWHRd5FUzI3avrkP6t2En3aXU9M0Q+m0azAeyx6EmyIBEUkCeRsAnxpBq26X/59eoyFn7XZVp6oA3V9IOexBd8jWsxyNvREsBXxtTSLcdYxxEI7nNg+arVBRSN2SRbHwVg0ftuymE2SX9rNGRQCESf8Hqq9M/9wcyzpAPxcCVrMinlaal+bNRXQfZUcDO/3K1j520+sUmay8KflJRyBE0g8IW4UyqOAAs73vzknPYDkdo4j8oroW8wgCLJC5LDJqw0o1YguwLDZ8iUUkhYO7mWorLL555M7wxfKOi2hbWfqzlrUSqS6QgYee00plBuSSRC5iAqlwtDZdw33DiVC0A4+/22nsJiuoWYWGkb/nDB5Sv/GqoLX36RrQ9fmWSB0vgdapgw8JzUf9i/5jpT2kcIjbE4z43o7W+ZFIE0M3IecGkDDprWQmBRwkdkYdK/SoBp+XfcxgrWLdNNza6ZE3XQqlccYHJ2jaHqFJerPx76ac+R6ogyVTXQDO4qZxR9NFk2eLhX5aaFXxkNKipOL9kQEQj0S42sGgVbmM/NRy9vg0jpPW4CbVos6z/X3dnbKGwVfTzAWFdGoiu2UlkBS6moFL2lyaTKZb7nT+nEasi/uovia6YzAo/9K+IV+H7jqZp8vpHWEXo6QEjnvFj1ofjOjS+I5WweCBH2S8ynqYQpOKIUKrp3yV4c8tPvtAVzhKOdriA+ih/7Xr2nzu4hjrygP2EHWUDaIdMGzWlCPtyjAPV7L3HQg6PE8rjETcmtsYVIxBYdzh09wYmggbtFtn/YmhBnL+xRd1RzCXdxFHhqSlKzgCKLbNkS7RbZkBPh9GZcjh6ptTftdza/EyXVpDCDMzQNoL6e3zUOrbyQCsS1PodLx8ZvwNUOaVBSNrNZjqk6GOmZV8oP6DboCugFHDvHU6yv+P2Bqvj/sP83BNNZUe0jP2w62CeQ2Qod64J2DqLj/xGDU+x7G2ZMFlC5q3sgWh9BttAB0ecCU00tmEfN/+68NuCP4RZoOAqaVZE3/uvCicatfOApjZOOCYiwfEkujonAm3/X0yWQV1Dg95kEO3ht8CtFrMikoHV5NcMO30UKh+xhBM69fRixZXNwOe73hKn/BTkVqm36wFp4oZUcmWL/Uqz5vkGyz9nurYSq/XhU+sRRcFpL4wmfqj2jP+Rr5m2N9+FF/6a2sSdXFUIJ2oGpW3rZ42BY5VKC+//svFnECLYrStag9crecS59kZiN3gkR32wdmN/7eqx0RY+y/3MAANEU+wydA8p2aHMJJ3GQ1APuV86GCSTPq7vJBp2yqlj2wuJirv1gUmosbVwF3BWxWzryeYxhNewTJ/1o4iRBEfLpgSyYoSU2BhfxIWseOlBte3y9imXik907cxXRPLjDYXhfDAym5ncIws/ZsKvFHG//sZqrxeEBLmwtUSG1wL1MrlhJoO4sVecfP8tb1oOx8kw4LRuhLmjTidkvAwWqMOgONVUhLj35bhmKghAi0cZmOoMULMp0qOu5FgcnzRS7nWP+i3dlSb3MLxPd0KNF118qqbq5iF9Wf2aKvcjjVoUQT5W6GYB+PzdXXrzPhfCbo6EJvF1vqmWhUBsReXDhQCeJYNG8LgIXAt8C44YpAAz3YLhKx5qnZWpMjyi+0VUSCelwAhj3uJVyJbLms7tZOPyvUCRV3tIOzYBlfMB5CGPSU1FttE7QQYp96qwFP0mU/wZEa5Vn9Ld6LER6EoVB+mstNqXc27KlUeOlci7FSrwS69gjl+4jPqAC1vWtYgKYQsCd3sONs3hKMkiZBGLqxgITqeYdvRoB1TUg7MCnIxxVKv4G9nb9sx36pf6xhqkL56Vmy8VPtdVTE8TFaqKhQ1nn+MgEwVn8sGDPwfcBS5RXYkYOTyjVDgQ7MeFZSbOv7ze64fphtd1ZFw+lKUhIT6REDvzhbJ7ZpTyFN5iW+qNFG2CaLs181p5Ax9onGfkkVOKfPGi6AsXfwMbNstxzwdfugXXFEY/MQN8FluQJJmZ3x1ORhw2IbTFPUfriIcTK+0IUjQSmaZpyFGTKd6pZUCOc5JsvKgc2VE5Xe7mKUttV+O0Yg5cp20q0kmSuN5c+w/pjNgHCC3CIWZutSbEozi76NoHatvfOeNJzRg22Qd62aSMtJUAD2upam6ioy95is1LDySaAV02XalAVS8qy9KMzr6tsJxh+UDB3bzy6N1uLF01YXlWk2fE61wrBtXIB2kyqxBjFI2F0jsJa/3v9R3sIUzU4SiMiIOGkIYAK1KL49igc73Il68X8JYL9SevHAFjtIBqbl5ERvznsK5LstQH+pFNsU9Oa0XrbWZEaumlxw9FmeX/F7ncmYSEMSV5QT9wUvKSyYDfNt0ULPeqzoR4FQlXNV+C3z3O16uVFEK+JsCFwIOFskc0JUcTcrvJmeqY0zjumku1i02kflkDV6nvj1MjMmyICtI36peEVd0QpxX3wT6lUK/Zd82ocyOKztCKA8iBeOm59ttyPZtmf4CuOLVzt9aZrdPmogT6UZxoqYA/9EzH6juvjoOaLt9k+fvjR5NBCSTBamSY6qXovVpeoHyc7EDVMBMZ16ZyiHaBDP3TWV6tb93cmDZNtRvbouklWeG77IYylRLcAVhILl7mTRMuLHsMOalwAAevx6Dz4cXaAV3Cg0ngnmqHyZssKzHoJXz8UIrEqppWBXwEAEIm95KmKp8i37H8UqwgdG21HUSzCMv7EDg+EEkGDToW2vaUkailuo1X9Xou8nC+bU7J/57uiYc3iWTPuuLufp5PZpQ/LR8tJonReQVnWHZn6HiE71MxY6efFzWG7zmHd5Ae7f86MP5fuDplm0BudBg++FTRO9+E7ty4hp46pSV7Vuimvc1G7uuMPxyKEuYI/nHuDu7oVagDqSUIzxG910T15ITLFRWYZmKEmVcxr1VPKJslgksbXwmvSa5/MIjhHhCDNBq9GEmkY6v4kSGWDKKDUg/OSqLaZ0GUiFw4ppm95UFHZTvr1SBekTPVAFbxScV8V6e622FwyEoLKCA01aoAaPFem+SE1/4OKUAw2Q1gMf3F6YGWMNPq3O4r0cvihnPTi/jHgGPSsPTWoc2QK8638rL2atZgEB8LbsUSn2K43c9AGX6rARX1bB2mwQdI64P/Hnm9ZAlI6mrSmpFi/loTb/cWvLeZ9QqDtotZQxrxzlvf6wkk6tNqxCvflzr1y6VQct+feOE7O+hsN4OOHz7ixoLfGMLKWWhcfC34amp0FmgB/DotAZOhucIw2msB+jpGwvrE+HVPK60qgkMA1hwqeXHoyapTDV8MGcmt3yHHmhsYeW3T+ukG3lggO0HmX1He+zTvUkxlEX5ATYqJVWr33GHZv6SBRXSjQuqTjdMU7Q5iTBvety/sVNY4ndkPp/bwYhUzkyjWBtBTsrbOlM9cPoGpAC6XyxAFdouzA2ITt5a0oYb/UYUqEe3n1ta034Bs2NaGwJRdCkM367tVZjgodQon+8ps9hs18VUIQH/lrsoLYeDs3CTbcZv7M9RKWcgFdJweN6tXEvN3C0ooN6BrJj9izu4PwltFKXuOyyWlrvXeqH6M0uXEfpy4aT5Spvd8jb1ewXgP5QeKNO/7/Rd3Yrf+LvVXyaiqq+/4p4LZgyBhHl6qQ83rv0vwKkD8wtQj92/gpKpdky6qSmiNwPdwQqq3zoWfq+UJsubIsBz15u/NYeAeNGbpWmMF5FyNM7C8XSaW90wwJT4YRboKTWM+Q9UfNavgZEStKvgdLfUDVTk03JtHpPfogmWWvvT99YckU6ysumXchHv3BpnZx72H5OpC31enWmlcdJrhZph+H4cRqATPJjzzOGcxRGXuG/N14lQm1HXvhVkTc/IFJklOBMP5L8bDuKsOgyptCwvll0ACiIl84mTj1INOH4LH//tH04VYAffRI//qc5D4yvzivlJ17vRIRus6mroGsf76wVoAvySFK80Ac/sm1XuAN/VvBecaGUF8cGDMvAsOeEfx5mFi6jmSxzzuEjgKIdx2ghWg8nxZQ0D2LJZM7AsWemyRLQ9PezvMMnLR0kvnYFlnMeTacWbKvriHEOIpynwwzz1i/+dy8oszm8byuQ9odkApVeQLaGXpelzkydEOYkxrs4gf3ecn4Zd0PUgGgOot/qzmgIM6PibN1i5UJLo4SBIrb8I82o50gLGfGISLV5GfodKJqa3OqUxBcZEmVtM9RPBaIqDy08p6p57oAGQxg5lYS5MrnW0gFf0BC+C+ZqKUA+ZeANaSdBLNpQObxaFTMWBNBFKwnicRQketxx6IIdVzP2WzhYCVccDvZWvRS6qZUUfez6jSxfnNXUsr9qnut8FCXHlfvfo8gIB9IOQiIjIVZich2zKO+XffJ4P9ehGe/ZrUuj+Uo1q9pMv1il5uI2eHTNTp5+ZCrVMji5uP433nTjRIsUpMz29DYxQ0YHAzgFekr+k4HxoSoFYNmnwKRJLPV8Zj/4qcuh/xmUCDV4MK4nv705Hb69jWeVJLPV2Z64CEG/hD61syY7rh/V5YkkHVvr2BHPUtG2IySAGnGEGI/lvFwWssvVGuAWRAtK18UMpSoh6NKY19Rk/bVrvzbl4NQTVxDOi7SXhgq+QYFkrZMPDdFOfUmx0sePrQreoDPbg4OLunZH6a3EuYo2mrwxKN+OzQk4FNu8RnT7FAPZtyYwlyX0VCfMQvFXYW7JzHFYXvzGwFDpTOnvnz8vjMp4BydQ55LoDoIb19TYu038/C4symu5WxnBWu64K/35Zyn7iiwmSobVrLIzYPsyrU/LPv45uezpcEJT4zwtfnQmo0T4e0sIlqWXxqzPXepY0Bpur5wrFwteXuEiGZpxv5BN0o2WUBasj98b5VNokpeUxdmK4MorT2b7CH2w9ocwQUM/3zZg+RLlpa7KOkEvBMa06t6bbwwPPO9Wn0tGSueDF6f30N1DEpJTPVehULkvXhf0D/KrfUmRLlcdupXY4Njs/oRj6VhipLrVwlrHIeIl1yElSi53B+MHzaw3n5/ONvICw89HtJLmYRuoHF16yXCzEt9CJDT3j6LQnBvp5tAwq+BabODEzQJa5FnR7VFMXEJbCv4IH2TCrHIRRuQQFN3y//EAVaaHqtxhaBN1QKz6c06R7IWdJLTCjfpUYbIIk/HXqUvrlD6Eu5WAhUbtf+8taVjMuSEr6kGHSSkJuw5BiZEHpv5nc+Jnp8N+h/eGqSWjMDr9ZdKV+PD4WXHDrwTq0bwtr1N0s51DtmMOHI1YnnrAQuSLnTx9Aw/8K+8zTPF0vNy/16BMPC4pFd+sNbRqkSeo6x1fHFzCZFVBNlNm4Yc2uJMh8Qa0hKDnVUr8wBoMTjeY92iGpNewtjSFoOkGkMTdEFCIqqtnAPQ2I8UANENgewmwZA+nsg0XVDjoOHooO/LYHHEHD/WZixJ5ds45DCFXhVUrzVP2HgbJubn9VOyqusvS/EqXg2IG/K79ogXsp5MkQrM5kYvnQHVNJIlNb5LmyH8zAIJ4+Ba3xqHzupf2bFaRWJvMLs/uy3LH8ZHEzrxcFUaIfMdwVm39UuiEDNjPgOOGDxse0wI2mfic03PO4aNySNMOL60ILOaeskBxCKjL6pDhMASfvE5ZIwc2SFzJGjIdxM/wPRNw1UXCIaHO/iUUt15qzDYGVZuhblocbk8t2lYbvpy3iz16DcLK5hiXK8bLEQegzn2mZsSb5znUf6+MnrbSJzusx5rQ/VuNsgZtPouxYWAiO5OuIEDglW/m7pD/ymtrk1e5eMYvHK2X6toUxHSu3RmnlApPKOSYlty8gqqBNFre8JlBcPDIl11tqLMOdAtv8xt9meQuXu+CmnEzy2m4X9122roNnhpn57nw8+txDP7ggq+ItrBXDrwvRoWA0mSgPkixRvmjbtZMCKNQiORhX38AcOA9HiAs3F6uG2ARrjg/Fqe8LTznSyjqed8zSFAmEdxZaRVZuBIBi+oDZi2yIJ1eEMX5t2uXD9PJdiHg2KmXGzTlIlMO8TN82PZ5HNvZL0mpjERG7SY0d8E/WxVgZMojtANVLULXiA2is+tGhkAvpGPESa1JM8T+bhx6Uof0G8bDQKh/iqWAEtgADmHGXQA6A/ZXfBzCLiYAAS8tgJ/UBW6FABO1j47BhDKTbgYGnVmSiKo0zB1UofgcEOqjw933zGMtRSV9htYdjefukB8L1brfnGXNk0GtGa48nXVUJJ772yd7iq0y3xZiJffMwExUgCLmg9HUjLA0D35Sj2ZGusrcxZk5rfnTAZyFyuWDaEl6fGi4h4DeF1Vs+LUUr8SULH3PXh6mHzGhGzGnc/ciktXh1a9SPGLSKLhlwzObnH+vLyzECDDKoi2Q43SN4vD2WGvmgksh7g8bhtY+/oZ8YyGP398oc0asG1hRFVKhQ/Ga/++kZ9eJXQeirhfdi6b8cp8z2d4vMtuxYb5EvotkBh7dP2s+hMdxS7gOFTswutKPq2zBNBWjTFoGD8ynexM29J5Re+BUKoycYL+D8iuaXZry17nLuDYLVWxisBQsCsCaJMCpNiDSoRv+Zf5pKMPJqTw1bwRv9Do4owIGmvVET111vfjwtwDsxLmZxXqFR/VQ7YEb4r8baGnzE1VYTBdsr57iKWO4hzSEYtZwfUkQqgim1QDtS1JJyRE2MgJKRdNnBRNd1ZY97DVvQgkFwinKqwpKwjN6+HkNnGy5KXdwHQ2uvkf7Yb++z4C3hTbfsPkDLnMfgATgZ8lcGedBiSsPxli+dajxtIw1YstiOuLNPvGpp0T2QGcrDzHBz/vhyx86OWl3cA7HzEoRtnlONjWe+Qp4Y/jXrMAYnqFifRgvgJC/uYBxu6h319VwFXFglW9EK+FKk1QWpkHTQycL4QYsD9s7t+HeXRb0pR9MOer1FbI9N/q0WNRJX18kAdQapGrKlEdIQ1aB3UxBsxgZbYtcXuOuuJH2cHyEab/oN9iYhAF2is3KdLYF6EsnvPvkAXpqzb1XNHMJP+yr92jO4knsvujRg+JyXxoiUzXnf9hlmXyEtjnSuBsUUf0vRJKZd5Um9QwknObkbUmTzO4fIv2x/Vg6B+eE+vsNLUDxleRLtXapZi93zszISDXtFcjmv5Ba18woZPK/KqOoTtsJLSyOcExbCOmX1dYZ2Dobuk4L302+dWVyr58HBtfZBGxoLVS5AgqcKXwvux+8jDAyFxJq5Rswbitt9jfT5u8Qaur2Dphw7Vq9Yp0D39e5JUVEs7DCQGHT1/UsNSDFDoGI67QwmBQvIfXntChPggOeiH3T2E1FZ8OmCYLCgfaPVX2my8P/GiK4MBD0Ou1J6ZxSBfZfkdUBBUNKYYXcOL5XXH/HRTVf7AjVEWQUUGiWmH9XJp+3deWP6snNQYpQL+efd/kFN0iQu6kk7bqultVICadmC4D00ei6PsHUnFJ1n9uz+ES6AwjDbr+EZy39JpGMASL/hoy4eZG6das79bO0V+oMMA4VA9eLNZMWXMG+1DigrRHurUkmtYbVY0P0EkkkoErNCDzqY/8YrGd65cKsiporWpGrdhKhCY3rB6r4d9bIv+JS0sr8TZqcKBD5CraCeEz9TRjR+UFgRpKfM16R7Sl5fa5uOmkmiN4zWWab/tLvoF72dNRlsPI7ZLNgZCS2HEk3mDA3Ne+8m7Ao4xZLDaiK4F/loXbrOWJYAAYlk1Lu5rOVo/7ze/Z3b/hWqkmTce5TIYFc3j8D9T5wy+LyxthYESQhm0Mbza3Bapit1lO0/EZhLybNdfwbhw/gR2J9BEQd7IYurEwgrFa2J0jNThzd5U9H+hrLpLj4PTsdmHnd9EGRt+cCCLaWZ+6ZIfVYiY/nraRKvW/TIxBfR6tvqvmOoEglj96EXCNnonaEXyVASIY+oEQMjKF17S7M3f4uElnHYfxUpBQA/rN+kJuhg3NRGGBr7gu7wHLIWW3tz9/CZWzvjIUJwDQFyYpfdCaRQx+/vWucfmLeltIwnIqnoNZ/C71OldZFhZ9q5v8xPVCWebb18MA2MYDWrJrWZfUYbolnKF7xmrDQnsvfcNO3iSq8qMCOzqZyBpRRWcFvm1V1JBKPzngW/cbwXkNM2Pz78YWUmEmAQa0iVkaM0kfRRDr0YJHCiq7SjSlC/+NWGoYi7bA4I5LH88vuRlTXFxNTGgnpKyUaxHNxcdUxQq+7DJrwC10C5+6cm6uljfC7R9yAUS9rwhI0TQInjdMg2btw2QprWjHfsInHtIij12RIGk3O2BjP2WAzZbID9bCUSX5igsSZ1HrAlKsxle1eQqbjIlRq+syMpgQu5zyJRntTAwDWA+yik08yJJss1e3izbaBoz/9DMs86Wj1tR4hE6ap0dWnHMcrR2PzENzSd4ozG3WjBf19vgUYJVCTXARd0vRuZ9gj/Jddt5ZnHLDk2moa9QCDKjPkrfdmHrevNMZ+F8hGRHkzPH+BFo7YFTu27RSV9H/z7Ox6ieA3cJZ2+AJ8QGW+xXNUDQrrUpcMXmKKKmgsuqSb7muYjs8b8aSgewTi8PLl6zfWOpDTet1ZxQH5iBRttM7LjYmeyjYiwuglqrqkB2h3FEhxCP/F/lz8pr30jkVqyhBX1T2/qKkj1izQTDh7L0akBJFwDjJDFtF54GWq+na/70cQQv1Po7/eZCvXzkKchYCDvZqC8rD16z6BskyDJqsRbDWeILFM84FinjbrbUgNvwJbVQHbqJbL+SYEaFOebNiv2wMhdypn9H/Iecw00ORWT0aMR9LB43O2lS5RNW6TjdQ57iUM8ecZpId9cWaiyWc5E9pF9XmBFVyYdxNRunC6/4tRD+aDsNrUS83e8xUZDPHo1LiJxkxehQ2XUevwFl3qJMyyOjiqYpFVyErUfc4iCjOjFxsI3F0DR6AGHMKaVSIz8VKG6tjzdQzObf/Vql9epcW82FH9PEYihUsVVg0lZi2/6jOVf1O6HCjh6RDhpiw494o8uujEulDRkJDDIPS87254mfVj0pwbWOHnPcEkAlQDgptVGAAfZPaAHn/Wz3yka/e9gBKUgYgrBgAWeuhC3OmvB27FyrlrWc51QeC2sMiNJLi+GUVxD7Enf/QFsEZ92Ri3d/4BGLRqPUehu7/sLVd+Fx/ZA8G1yriEu+BZYpdLU2FHUORKjAyh9l/zafn53ttuYNTe4jNLHLwgd8cfUJIUaPpfmXYzZ5dBNWpckYD3S0h8no3FIvS/EGToXcb2aiKYu4IY+ktCPwddpOM7kG9i14d/GTGY7aPG+NbF/GKZmAPDZz6EzG1bItQ9HY9T6QsSBeo3W844zQnTau08hJupbRiiAZtS3BrXtJRBtc2jHKTloC9N5qCd+xsKk6rE53FOXTijtAyiBxboCZLg1UWLqwBWdV9eELVeobjSRGipTsqo3VLOwkjugao0ypGSvsGHKnYu0DGwI3iFHQfJLFKciHR2fKOipJnH2Gi4DlVTVRPco+M/yoPalwRHZ/RxT1sWpMIGdtk9kUXdfIBlj3F1z4HYNNAoA6oKoZfVdJg1DZogMbf1FRf9iuQH179cYL8AHP0QqMXrzyK7BT7PGA5Y47y3srHAvlxcxvH44q1nVtko6WJcAx3yZXPtfRas4dB3XDm6XZc55ZrIB07ImXTmUSJFbUW++sjXA3e6azEF1U+hU/3EKKTvv+4rh8lOOqiGcyKMtA5V3DwvZcuANOf8hQSxs/TXZWybs9N6OotvM4XrNDd/VzNMNPBxCYrfJlOQ/16E0VILUIFjvi+psYNMus8Dack1K6OW8I2OZ+mTqPPZJz9FZfMbWhWFrG0UgRmhBq2eQndIN6XmnGWv4gtNtvZcBLrFxi0t+y5FF6cPlr2JxfJ6eJEQuaUOEsT8dqeP+vo7E+91MwDArE7lYcrkJxCMYB5RkuYpTxqrVI8vff9fh/GJQbRvOjm5YtOs8AOLmr8FDCN+97BP095FJOjpiZYY+3PQHU6xXPELxBAnfJwrEIpp8DY7A1OnebhIbXlmDBpj+k0i4mNBMEuO2JtbJbGV/2R+jTpA18JtuPyi6h1aQrABo3EhKtO8d+K6PcdebGKZV2Zueii9Dq2XKspWanTSIkuFCLA+JSQH6pACUs/20lLQkKUMGINxSfsUTaEwGsGTHduQNfCj25Yu2D/i6cJWR5FsQ4tfDin9Cy0WkvNatX4l4GA0wCTK3tzV7bhstbjxV6jvqQ96Y7/K+etVLsxFymPXetfoTxHRnendSE4Pyxhiv4XSIjtO/6vBXVXVzndNFJF/i+9xDoLdE67v7EztpK58FIPeTQeTotgE54QtDqPPPSQe1GSnmAWnqr9+3k1cOp6G/3xJ83gQ3NTMEwDeRZeCspafUUhkk8IUxQLwPtpH3W+0kNXoaChUjTjMkJP0AMGPeC33Yg6F/mNnj8d9iY1ShH599wm1K2EIYAtUCxzA+269dKYEypgKIDA+jmcvFx9XJfast+c2r1AwqLOuBA6cIeH0lFwB67A9OAYeNYe2MIHX5xbohLJaUt+sDU3y1D4XURs6GsyBWUsB3/aia/WHy/2WX9Ov+19REHnEbNAUYWfW3UOcKlajTooowQ6Vzfa5yYhfqdLftS13aG6Ub9vQyGbrCqqnrVAB2UL2i1jWRWQmRHCybN/CI/0CG0sMkV8gG4XPoVwGSUGuIwmKCrGdHfeWBfzP/PyvlRhy2rbfGKz0p7Qql24ggnNCyLftZcX3E+YJdtpwK1iqZDTwqP1LMHeCR6eyvZO3wps7S6XWcC2DqftupjXS5GL2fc8gOmE4OyYvZhBYDEHmLivC7gMztjbhk6QfQPUBqGRQk2OtGrdKDZg1AAjz6/mmLWIJ53tiP94LtCKbsq65IXNi9n/t2ajI1AaJZXNK5WcPMOcPAtfk9pSFCFHpUdwu77Tx8v8pHO96A36iUYGbGf2FsEl43fRTL56sMoxsrfOG0Rhmv93eqAYrgyTOaDBFnI5kKXsEYZu0US4bd7AKyH6vmkDYBT6RN95Nl9tYjo79LNbgHjD3ZXwGD67P2nmK3QRXXKOrZD3JrI6gKcjM+LJaFaH1XPY2FUZjX/UMAcbbffiJ72hsIfKI5q1Em0ba5GP/yylLCdJPAFtriM5mRPK/PMaFd0p2BDeC/gp/NwGG68InHxqtCBUzhhVSLiD4ZxyELuapiP8OZco5s3cdkLb7GLKjJbUdEJX6+/cC8BpMIsVrLvjvxiwqfj8l7NlFYs0lkBJVs0akRRdQCDzf2UXTXH2eqW1mhs8akTwXrLkJkxx6q8cAD4dC6eEe9oK7aYK9eV14+5+MiW6dvAfNAy3yNsf5uQDK0DTIzUSM7Pgd01VPiZH6o6yh9NGWeL81PWUm1md5zHluBXNA/nzfG9N82XXrIedTRTAiE2JqJCvmWfYopDu/nhHiE1jeZ3S2IDgs4DlsyrujAqewoSKciruFzgv/83GlLuJgWYz3GLWanlUn0d0Zi1QfaXKCLikB4o7LHUThZCx8Js/fJ84sjXhFFlZwPHS6VHTWZAv3xTkD2WSaW7sA4hUxxneaqNgHCpa202ktywqto4zcQpFdRvDZBQsOTfdiVrZesIeWIBxpx/UTNY6UguNEk71JpE2QTjTgyJg/GCEyF58+2K+DPKRUXn1s9qKoRJIf2dxDQfzZueYYPzItjhnRd4VzDt4DHIS+afoue11ygmYqxKB/hO0ydfWiRXFcayop5EFv/a45Bi0IB8J7fpoJdeAfDqzViiCI+iMoe+yfnwLkNmsD4ogPlVhIQ8uE5xfnCG7q9xNurWqulXSUP6R1uFFC6eE75qe0MDIA+RZhmTXK7sL5Uz018tXo9BWpk8pSOevNX07jy6pJg78bk0BFrtmcJTjRvFuAL4u+b9wqH7y0kXqNkBbvhdxjwZ5baozNRGW/qmCiefvzGJRR1yw6CQt7u+i0hI0K+3eUpQBCg+sgf9PTEAhQbYpKuvWor1JeMSZujfRLbJ1S/r/LpuemT50p3tyLrBRSB6IE5P4PqdL3PGaNh9pv1ymERy9cJ5teka7MdSMOr+meZMw7WFLAmg/Y6DfgAeEuRJSCTtTPR2QstjhBthe4xjXcHIAy136B4LybcPZpmk8WfEJwNCAEjC75tVXO9N+MSSo+0XexWaHwU3XRpsylaXW9K4y25rZ9hF62AFrsgGNd0yQW0gEUjOj6DKe1/+47tRzhJBrhva/5dlKI6u0geO0d0o2c6mP/8fKToJk0gVzgEIGKno5B6KiMmmTOljA/nBk/zDImvyuNtjOtGjqgnMGsAIQxgrg7I2ZpRdxtnjEaraQIIJYrj5w89GiE/ZAcKlUQEYVM8H39eokwevpKI0V4MNBXkilgy1rueKglaWLK4TKnTfswVqnXtYPRqbPpLv20epid/R7Juhx49LdtEEAQSqLtR2+FMoI1aExoJLKEtq7mFsmpSqPOwTYqJf4LwktE5UXkWArPoi/UUIBvno/38jPqajTrYEj116XEHvekMriEeTwXRxT2rJVFGx3RRDzfFagqXP7gv1zhXSPLQRHP0FefJogwkWGUiOz2E/IB3n4Wh4+Tp72rhJybNkStQ3ysaT6i+O3o45sFHQNiKPTs7wOtqkIH78Wq8YvpjeCxcUXdi6Q97/hIQLZtZJIv2XyVIAYLzqHWvgjVhHNkQLT56k56zWc/tBbNkwvYXorRr353Jv5eADFqmeDIqYWwqMioBlXlSM5IJ0KV4sEbTpnxub4QnfAfj/A1YK2bV470lMDoPEOOhYlqx3RXaoyGEvT7vUhKLH+HRmteMH0HA+GVwvlgHYAl2Dgd8loqiuxsfw7MXbScHCNXKoVcqUbDILwVMD1KhXFus0xlmkbFUytZU1ZUVKTUfVywaQehMYYf7VJ4fwKbM73OZgpdZ6k6S8ztIsbUT8HvG2VVnD2AUFkfpAAYDoEtkb8O1IZK9T5fDqNvDOKkOpSJ+/Jng4pH9Mr15qOFLOlQRm3C+MPdO4AG4HzUfLvmiJqWZUknqqmNUFM7+8XUF5grBWIf2wxFXdkiGj6y6wYtyCHbA3L60p+DJqu/gVUmq+bK0B8QuTndP5s/xxtZrBE6InLO2CSRJPyRwfY2frYVtMoSwXvQPBGnoJj2Sbvry/l7AurY7MOi7SXjNTOU7UHBUY0YwqjjnIDmkqnzVBREcdUCW3PNCfdkzdIlpq6orJGZuK++aqSOJmOfuv97wVaQ0vYwoQsTIs5vKtGk8AyF4AGWG/ih9PP6V+n4JZ5eXYiz8lFiHCrDWXYb//952vJ6ZWUzp6KPVPd+jfpTsYT7zi43FzGG8hG1l4VGE0Wz3WwxNAxBHfCUxIfb6BA6M5VrO/ZEMmu5Vv25erRncwtiI6JgxO2HCxzjonfgfdGt0FA8K8rtmQySkHRYF1NSyz5hEaNxe/+Nnshsx3AcbxFJl9k1xIXPi1d0Okev+htLVCotABOxZ6H/kznCe0MifKh/TFm3ahf7a5bf8Am993Vk5EVAZNTnzPNwveLuSwcO1RqIyfnJhknwD0xscKxNuJNsjVpH4r2PV/yR8N9EMCNdVtYm+5s7WWuZHJF+npQvFxMg4YyqGooeGYtFHAo0b4sJ4jANMwLgjb2Dn9YZ3lMO/nAFdV4zM10p08GpCESjkB2JmvRTREWmm1jXOkiCcAU38ZwhXGy5s9AuvjREJdCqjNa1dvLAVO6vZHyfNcIO672jw3mWlqX5RjHAIZ9ffIqlKROx6wyfvNlp8lvYJnTjD776yUEh/bo3Y3n5fS5OmBTv+UWtQuqW9biToSDFcaQt7mO/mV2xeyErXO0r6KdkPBwRw+lWNae+QfpLNoJYx0DMS6/f6aF4b4yXn8HJQ+FLNrrlQXl7H6SCbhGH2pR+qafRrNx3EPHgdcdqDPGrj7FWxssfrPFWbhbU5/K2prP7Ul+x3FHcMYk1knKdEhAU4X+H7WnFUvVCkNr3UIao/aumVDWkj6CcD9vf4n5sotxomkWSvYSq/VuF55oCRLLFnLqdI7j8yJxMGEvcl6iJ0WB1IrvpYDIwrOWRsI6vIiv6qEJ0fOOs7TCuMU3Ex33CZKxr/tjysCyXR+qOStteiGsnsjAsPXs3t4sV4YKfu4epoieQeUSUbywJe3fsecfDFRAnD2v9uZvQxLJ0+v7xrbihYPyFlyv+YI+UUGx+88siOQ21EEyFJ6rFeLCU4J++73D3aYbTB7UFknMfdKwsZf5rJomJbbT7UfXMBxZ0IOcyVOykR3iXQi5YiNwF6UorLpXi9uirT7jOcsXp5ffLUiaY+gpeRpop33qwmiQZPlFsZIijIlw3Oa8JAJS9CUizPlRhYM9xyV3yLy50cV2qThBArT8Xs8gCSO2tL9fFUooYwpCptoSMPUS9eI4j8JCzSN0oTAkMLV1WrKTpqs2dAtm1aDJZA/XTYDaEmaqTmdWStaRFBa5Tz2keUo0HP+0PbYZFdgRHqAZ3AlBDGmaaR2ceYJdoAycp5QV9D532/D5z5bioFGQM7UcV9jntBH5mTq4q33SCSBIxgioCs+hn3o8ZbqQ0y0on9QUPtvBZN4ofLUUXjlCwUY3bLRfLB5/rMCPBY0LeAQ88IFaW9GMUuLX0g3yhcBK2Scw0lBy2/M6fXnXyctiTIvo4NR785TVVZJ7D9ecfFz/JqgEjRkSrkUf0LGYXLG+nrC0yZhnZi2KL135AERlYxQ81keG0JFSnYBn/BvH9MjarLTact4M6TWaXhfD1OFV6F1nastLt2GeTBrnLwKjSzgjglZrMeGBZnwwCMlpSt+3Ay8F5uH48xO/zlajHZnZTy5Y6Oyeq52MGP/8KeG1LFYbDUKrKEmjWlACIkEB5jVkjrHVFdZ0x/xNKxtKiuzAOUXAbdBSLaF1tt2NicU3TVDloJDvl3nsVi+um0YJHjwo2z5xgCCmlG8XVH90lWJh5KUngR47JI3OiEZaHL4GAmpy1T1v33XPZ99srpafzgVJlVt0ZmzHoiFfYdC68ii8v5IZ7JeK9gUJURj1QLFvwdiY1KBzbaNWjR15iqrERGtdX8qbYDXeolwwtnEU2ZQjjWh485VinGaLqemC1QoQT4ivyjR5PxnXnJ/P0JCif9E/qLAzKvFZj7ZL5pHDuyzWnP7EnAnOuU4OAO6XyV6wdUS7Z46kXtQzSd/bUh7YwfmBfRPkTSoB10ZnQdtINAh0oiLuCRNHLvfy0Wjg3vZRy3bbxxGDE+2NyQfckrqwbKf5MUJaZYcYhtMSI92whm0QY798mlXizy2+RU0nPnsVITkGfUK7dyqmmJ1Q8EmjF0uauQWqGSway7fGAI3uB3XjegKIo0GvxUiAodFxe+eD6GJ5WvaGzYSM8IUqtW7XbTnpXaPhsBpfms39SDy+HSffVF6i94jK8JgmKv3o4/nOMCMJPs0X3pBlNNnIQBeh0Y/iXZKOHdmolF9mWGc7loaoa2x8j+RYQ0UG0dxYHlmaCq1eNS6ZTqFGnBf8TqSfJ2K0hkvql+kNR7dOH7fodzTGePw/YNM2VXKuvAYVihUsPvLtdafP3m7HD5aIvmhqZr531GBgpDJDCNk2QF6xq6fNhScakPbWsSFC5JYmV2lbud811Dbi/xhOV4k3Uoth+e9djHH8zZY1x3y65tRsFYdUxv7nDospJc/3xdvBfQmQOrf9AG4pg4TH3/GiO0qw3F8aDDzGHSKmbQXLUSu7ifx45R9nJeuHU7CbzHLLSdfRAI0DaVtcac5bsKlYYH3oSBzSCHPTqCOV7JSqqNbRr5LnhNyXE+79/IjjKReBhEAMRY+7WwW5MVrJXEkzaU04MhCgGInGHSYMr2wLhzCz1dgNm7fwccduQKMVfnlX7Y7dVkgVVIJHAOWxFZo7WM7eH6Yr9ijEMA2u/4vfwhnNl6JTB4BGeiWyczcx2BOSjMTyVa5KHiXV94207l4dlkHpQ+yN0PZvMERNHlgql4ncQic/RWi6etI5vYU9lpEICfWAWyCLjg+AnS139bNRQa7NyKqE9r1pI+Wq6jFJH4G8/b+yEvLg8n04UKWW+hCOLawGEj+EPq5s+ZsbzKfmjaIumiaWxCvTGyXosboMMcEnwqFeg6Hzrw7jAg49ckqt9ABpMghjrgPn33GgipB6nzyUonjPXlw/gm5b9W0IHZkohS1+u+L+jpba97quvPCDIU+YLig/llxgE4REaQ5C30iFBcA089VYAHvQYt720CdOVDf2ouwxByZMcMgfVlU10ou61ZVFc3YxkCDkGWcxKHzIanI/Nq6GFSx1Ib1RyP5K+Qk/viWyAa5MNaTZoD2aHOCWlRYacLZ0e7otmS00D3l3+E5aBYdY8EC2n9Qvad9lcAoMlknRrmqy311LCstUANX891OyOwbzgUynHUXUwYnQGB2FWP+6AaLVHng84Rlb9p8mu/mCo5iSp3zteZrzFhtwzW9K7ZixgERjIhY/1XpEMcgN48kh1CswJO/0NIQ9qtOr8HxlG58OuSUIzVwSNXptS5soKjnYC9kAr+lZ9osHxn6oBZJUmLgMZyn+3kz2D6uL38UcwG3eq5SeWwEo5+fCjG3MUvDk9lm1NAA15xyj3TD+LG4shtR3focTtq6hCjLJKCq/VNt6aneNUY7pBd6HpaqRrIQG6EQsm0ef1xYy9cRyRXF1zxbWDp92GT4KGzrxHdSM+SXdbNdu4Vhm9i7BJJo1fKHYY75ky3wNmQfgnlQqOp7UOif2J2y18XNj5Hf8rC4KQzvlTsMVeF3q3fJVk5reBtPV/wNY7Vprnz44nIsvdyBpgJYCYvIDNhvRVjGv5bEEoKK9upLENMUzRUvP0ofB/yQUoc0f0e/Vg7DDDXs+QyWQU2DWpmtr5mz6ql1/rEkNHZCKX/yEvjlnu39dwLcnIndmct3/ambGxJfpuk/Tl37Jc1b3gciWmVLl9dT6MJi4GB+4eFUkyx3hCYyqUE84jBSG5U/s6RCdXekD4Fe2/ULV4MNCo+PNaWCY1/QAjE13JwvkzDakUFvB9qJNllpo5oQ9NuUydsmlwSjRYNcjeam2eMFco/W5Hw8PRZNd3IuRS8NhgeeAjagq7oec9fLzPHiKKyg96JOrhQNZztx2vPTTTb2SH9D5fbE0CyceKCa9INajZhiFGAuX23oceuxV7k2WSL5YWZ19icN1BKnZrcSl1NweLtf5bvZDdB53e3i/xT6RHjVs93vF/LD41qdJnMzcuC9TPJv4izXuxyct5c/iXDIqrvKJsYBIHJRL59Z61KH6hJm1imbrT77b7TS9eoeGBtitWYz1W8S0tLchBtu6OeNDGCRcMUL9jnCzEdn+WKkMCDLygevHywgL1VTgEITz9tVfhkLOA7YkN1JUoiPPKsAxSbSRNLoHdNZrNr43CabD/Gmp0smHQWmheRbclug/MZZR47T5870aBmAElCJF2RFTmybXbFvPhQ6szyzbKK3+Ku5fsnVvnVcTDkdDv9tqYVmlhsAM36u00NkSLO8rWKTVCFyvKkc/NxfL1HJT4y1VMQJpIDDKseMlqg6Z6WWIimOdQF0S7odCnewIaRSLmZxYlLPetgw/pzW9n6EfiZb9q4aMwnP79gH8EvuL54dhbijPzOmCbi2ai5RuCQV+VKdq4anYNCLkSimLrpdT3Nk3owtUYSPwpF1QY5K+J6J/mXnM0nKZtwY/+thfR9+xwjfQLJAq5NlPOQmebxCIOt+Tt20epPVL4JwPbEiipWQN+t6DX8Kmw7ndtOmV0gtqvhbQf/v2eiL0ylqaoMWCs+CPAvzfokIsgKEvSWiBN3p4B7crD/RSFSTUYlgzHXFaek3ic2mf9zT08O9ZNS/Z5yNAnXXmgYeH6k2JFRLCN1hysAbifj9eLNov6M/D25nWEkj2O/35JMqlJzqxovgZgMGssIaBRqUe6wSdiJxQEFc0/xWc5hjBw3/D3ZgUfNBDxO/1sSwNfp7lYBKypcYpcWnkTHn6KAz1vGM2XXpXmhGYI5E81DYK+7VnUmzfXhmfSbIRCzYDb1k7BGXvVcO8nXaHdJHm310fSeyLM4yJnRQ8kp7vT9VglES+XCK4KpzDqJuw0oLTvlUYrfP8Qs5zBsu4gEFwzrWmBIYoUmVL/Fkmmxn4B+O4HhUtYwB19lWo1w9HGXFNdOKO8DU04S2I45gj5VyOKRHIZdKrn83ObuHBexQUsAjx4tbdNnujRvVGEJ0r+7lYj6w6BY8QfOVJx8i+HJcbwpMqmIp2+harrrkvvcafdxDjKxMx736qCOIJ2q3iPRcqC4usFg8oC2J6z7NkVQzhl/TI89sShRATHde963rh+ASoGolMp9JWRnWmu3fMUT9TJpayVldHjkP9MT58bodvV9i55iOP8aKmMBhu2Kyfa54J12CR1/MMu3bxPzUvV5Izrg+Cn0jMz78HV+/B1daxIAwNh5kzQhmUcoIxsUUa/eS5AeWzIFUgnXVhZryKpboXctTmpF/iVl49+f5U5PiOi3jujMmZ8K7f7HjvTu2b5nP9IItfkWmzCbw1hticphzaN6gZgM8VU8Z2jRSid5NYbk03KPsnebFWBIh2Oj6ybTIgOvGn4ctQ7Hg3izxcT5pNJgLtbvZtfOod1wvDeTWcyNRCdyArvRCVaNLhG2faIDGQJky/kFq3UYnb8HT+PoZaZ46p4GeHyUmxoG7cRyEljIHekiWWQOtV0XYuv/HCJIJc635AvrvUY4hN+FMWoT8D5wp/KNnaXxT0l9C5tKR1FQpzmoVTC+orlhvd5n1ddiG1fo8cJNWjZHaDLLG3cIMLxnmJnPOWbgbYa4aLnufvry3J+am4nVSzWKYQdHSMBWOEMmMzZ/uiupcpt1xRnW2tCedY8H6FPzCPfSLb82pX1zeLy1j7YwCP0OpJWk04ivv6qmZ0S/hSwwBjWzDFZAyE9n7+fUfufUaZZimYieYaCb0yR8A8dO8esfLKrwkKVWXUlyQlzgeeYP4PPmtabLCbq1SyefWf5qJ4pT3y1c7dJC4Pp424hbp8zRz5Y+kYzMhni4F6hupzD0nOT2VLZFcnS9B7oibB9ny9VTyMDTsZwkmrRJrsg65+0Gy+VrLcAp0U7GaQrRxpGpvl2Q4dzkGjurb/wCL2ieRDVahPtl8dnlmQfXSLP2kJECILynkIiGXUdwClzn3TCm9o2a4ZMel1eL8fTIsRXysxHfwTReyVYBnhpAPm2gKZhnmz7dtmZoOMbOhQnv5NkXgdsEMBIvwIlSgAeEnlvb2eftU4DLyq1mCFfBU/YmUSWXPkdgpi+zHXMSSTiUXoF9n3QbfLWaNXwIjbYkxZixNCr5GHo213nwekoVSgLaqT/sKNEw74ApSEEsUosShbvexZVvE2fL7k3fs7rAIgEUANO+wWNmmCGpQUhXgEH/JUbhqjWTkNo+Rqh6KuEuLK7JboGUfAMCpv3vQbirStq1tw2mLo2GCvQsNuD//UWpRoHLuXKUMr1AJGEP99DDTsiLCruXPHkp+39uWZ4bdVUcCa2si1hAlnbXipOR4m+kbWU4Oascyg23+GSGDzhUJ6UUfAVSr9Mc8YUCjD4PQduhfmeJUX9M50nsN2q1uCc8g5yJ7sn9jVqlpTHfw05Zbe0ms+TLlwxvLsBQ8R6RyVsIr/FCf5JsvB4cIsEkhzjNZcueXlUezuxR+l/IIxyPGK48IufGQJdOh8LOnFT3AygW1GR/3Uz8xLckYayOPOpUJBwcc7EnppWr9pSu7fm1qKgInwTJOt8L8aiC1PUJPAuGcZq67uL4NeyaAnlHKIMlyL3cPcogIliKJ1kuyXFaB5s+h+PgLHVId8OCOAAf7tsAeG679FsEJdYflc7fEnGadYZ91IxtjvX0BhakzC2I3O4qW92LWIBUjeYovRGvCskHQT/+MTkvUCjCRQQvHi25aeNu6hKLUmLnzqHzj6TEB9PgxS/tFe4uIAVAemqG+BwgGyAH1phjPlNxB9XmuYWQs/qqRjjGFbWUe7AVX9+zro1Wk7rEsrIfF19FjoglSLuqXgdfJsl90BM4x1rUL1KM7o/u+dLLxRyv+kxxJGwyME6mDcph3Raci2s1YvLg6WR/7mAbXaS6EkkXoAnZyQWnP0xnWYKdU2fM/CSjuyPhnzKeHImPiGh57/4MI5kaul+w9/2U3HJf/sI/jPxcutVJiyjysB5PlgKbTE6FFQw3IU4yoA6ghP2GJAlH/XXyO6S2/x63oX+CLD2B/2bw586OBJxlqDHycdMd2Ny+oVStQtjEaze8d9Bx1q73vp5QVhniVtzVWBkIdsVf0Ikfg/mmzen26D6FScj9J2xstiPTZfgh7ts6WiF1cKru6LnpMFkFhiHTmXNk8TLf92F638fVeu84tkAhULUrdWBzb0QHeUFhpYFPJBdfj7jjQ5+yczOdyjR7jbag/K2QADFhFvxrdFmmloplB1L5EZ2JTGYTAJ15IhjLhdVLL2DbnVSVCtHKQEPZP6PyP5+0UegrjX2alT5HXGaT9Xs/oD+YYYvEgHWuppA1UYKwXn9txFNKcSN4CPa1JhhYtxkZbY1pRm6FvfRREwxqUnzeqEl3dhAcJvYFvi5uu3ZKOpham1AduS+BTn2W8hkaQqCJlaChhJLGf02fL+Q78ch+svP1yEpV2dYzUek+KXqTYlUB8H7PmIm/NrLM6aFIW82fE62sS/y5lqrOIOe/CssXiSADVxeNMGl+z38/1e2F9bfk9LsUTDfmWCAD0TAyGR7Q1DQ4b1CP4n9UloExlgZpf5kPtcCobf84feKVesEwhCOCqtF5VyXb/2C/G3732/D7suRQiWEVlYM/2TRqskI3EUzV+TwvHMgFtYSWBSM5a2paASuu18Fj3w3xOKTB0933sBVRhqmswChohUnL1MPE0NSLqmI/ylNlcbiqqIZmB/ozpIqY9eNNCzUuPCRt88UDHIFiGT3rnZUx4kjIqYsZyUDtwlTXCDJ9ywLX0ObOXFhMRCe+TZuukajLzFHQfZQbNR+F5tuonp+f6onkMEFlfoY6NN1UXb+jGvPxDCD/ST1myL2/p3TCvYdkqHdYTzWkW4g+YKreEqAN9QQ3MhhIcFTUe67Hc+cuhD/e7KZ+rt/kOzc61LQtpXJwz51ND5BjehPUrM3EZXFOFBoD2vBfOeDpqwSaCYp0+V1oSeHc1hKRKC0p97jXLL1Ilx/6iMoi6crMEgj8CI2oXQ4oKYESh/ZJuBQsMf2p/0Mrf9IsLjfdVcs6zw/KpZSFTNx+bJrYYbtLDusqfPo/adhn4lNjIYGweVbdTwxOy+Xq98+uOGT6NFeLw9cMPavrYC4gpC60MIFGHSpflmOzNJbfpddV95GVPZSDqtzoIuNoGTyJ4PnTVD8CRrBEKPMqX8ms/RCIo58lVcMHbB1KwKAWg9LpMpC0g/g8Shc6bAQSCyIafw7scls2dyXe7/2RH7rXM6sZbiNxuzKOr1fuqtozS0PviPLJMhAeszOzjAEoeBqOCnrzEhbHHHMaObOqr9MDNx9iQqiA6l8I52ffkXAlziH5DGNHGD9iznK3Crmf92Cgz+Bgt8cGZnOIh7t5Eb5Mam/SfEb5KXtNiz5r3E9qo8CECrHA+LvAVpyl7dBlKbQl3JIh1yoMto5ViovRnrVO0oT0uI1dmniVnVQkVjxe/9a0evpjKnx97tTuHMlbKGKosrrqw7a0YMTfP+LvuXITi0IJkfVELnT5dAcNDozLSDpTwHWZKuSs4dDYRLWz/jBxotOGObIbPTAHZTaJpA9GBHL70/jPjg8oiMO0h7sOTydsb+kinXn8U2ozZwlimS4p4SgxgNAOhHh54D2CaWVofzYbyppDUYiv2jv8bIRvcZO3PWPyJxMPvXm32j/YMUVeegTyjD2oehUe6igwnYxIdl2e62rax2YwznNhCsEr/qcf0remn0h+Hg0DkbU9ZVaXrPHOdNKFSEjMHFIHAn45wSV9Pc+5Aul1avyLSXrqVSM9zyL6J8/056WT+4ZMIpge/K1QCQ21sJq14V6MV5GRNRoKAa3fTkbaRYZYQXYQh/W70VrBb20eGbTyOaXh+W9ybKQO9eC2LAN4QvsbUyyii8GrrI7wvXAbWpXkaym0n/LCkQbWUWfPBCpAhSvt+3eLpM3IRrB9MiXvQxsVeOPyS35k3hczoZ4+3kyNsVTK9j7sT6W3+c0EoNDA+AJCFdfE16DqxMpbmDrMfXRiuWmcc3WVJrVDHEVgHJSSZ5kpbYT/Mislj0rXe5H2yFVoklJRtcygEUp6W88lxSqIRw6v/h4RBg5DlVGh1nwTmGSUjZVX7/03Oe87mv5jvADTomsEFPKFNWDqQmwzrMXoSp7e847jGvVFZZjT/72pMdb7dd4+XXq38okvwA6mo7N6u4r1nJmv13xsoYuN6dS59s3Q5JmzeQOw3G9ktWYm3hHCr8LHWaVDaL7JdJShtp6vZwDd2UPvMTQ42trQwhmTHxkMxjjXQ6eW8A1UY6nb0Ype4Jnep5WU5JHGBazhL60dVoau+S+omoZH2tB7+E/OUmXHAGIxGtiZvUd1pCjIaoGmcxtLQZqwLpZMVfPXLCPig9hXPUgUyxFkvDI2cIZXVDLJJgGqeTDyryk/on6WCEY5WS5jFTNLD/ZU6fE5dvnIWcYCx46TJJN0JIFVZ3kh2nl5jz+WoyWvIkM8YBB6/2g1sbcbxHT8uj/1afcKxat5Oz+QwOFbg4kWyYuOghhm07udncnPGGLhCKDHKocOyiFErs+L/wP+ayaxrhN1/l0oncueGM6giuq6DaI4xvQ3mDtCRXPG8MA9FtBGXU+GS6buq5tbXwvgQov4jI0i5FvwR6Mc/u+mu/fW6yX8BYf/bnlTOj1dscWTKrpK71ryCeJDNLT/fKAvAMcCrQulPu0ANHA42t6uysu4EdnX+YWEKIAer9qxCQZKmd6lLHBvmIk009boHWaTrkl6h3UFV3WY5Y4v4M+nsBdY89i20cU5O/ppJs4uk89micArJNoxZ9K6xXm80T1YYdRxIboVy03KB8YY/FpGDd01/1hTjksYYcmqbnFk7E6b7lMlYoHPmNTKd8uH2K3bnf1v/CvSvXBoOS+9aEPq5VAM93IBROEd06zNRr6yj7BWAykkwE8vNMxRxdBxvGn7Ggv4qHBrG9lC7C/n5Xct9CIPR09u2h++PORxzIfJKK7AmYLBfzGulsOitqEHsu0bHvDTCCXsJUFsc1Ler+TL6bRwiZwyxz7LMJHV6SvRn2ewFcAsVKimYD7d1OZbu56p4gP5lXtgQokGc3GO47FeNjMFJwfvhlGi2p304VqLCwgG1Kjrhld4yfr0RcVAFRMraWznqmrmq/SbTYYO8fgZlzWSOlorMWc2BHn8PAi1YJ2352IKNMdGVvxGz18Us8m1kCa3YbBxsfj6WUoJV26ugH+DC9V8/a0lF8PUAMDmgQebFBkf8cOF84dYReZhWHlNo9BORkXvYl1//XjRR7md9vN3mf8aZIhQWF9hbWqrom2yMgwdrKO6GlGwXbLMYqI4sQSZ9e+sU2rOH38sKojaQX2mkpy7+I3JFt9m85F7RsO3FjykkIlFDdnSPrkKYtBfyEqxCTNxbxuRor+YERjHNQJENkwFNoxI0pqiJW8KhX2QksfY9hDFsQ6l4WVZG6zfiZfZHteF/UYBWZWVu6StZXk4HIYVOV/89a1qvp4N+cdGkV3bB+hykAKN0iQbtNK1zTerOPfUaIC0r/L6xIt4H3QjVIRsdG4gF/CXXi2uAikySa7j84VPwcs+Nx9r2YOl76xaINxF+iKASCAcxW1/gNhJEfbpIFsPi7/5B6haCbwSOTtFN+loHY6GV+8d7iWXLwtON0Z+BXH+n9qpO7UDQlVbX2BJLSBy1n4ZbpMZPG/0l67c4xeK5H3gnzkLTaKyIqBnLBpym8NzMfjU3GwDxZb5jB7YD36ZvfiSuNoAo/cj3JQQ4Iybfot1OiFgcXPFzwYBeIFoVqob8kE1EF2CROZFsAF1zXhZMa2EL0UOpyby70Xyvbq8GVv8dznn/GPq0UCI/YPkOn1v5M6wGhIxo6VXP7PcSy7NUvVdcItNXqroySkfvKypsw5zReeEbc0hBRoh7voGrq6L4lkWlV2zFUiwK0FPdmRvbEp4S7TEN/o7PerkXBzhdB4TWuOkqWcSV1F+2lrhyoCFxgFNx1RM2Sq23ujjv16Gxor4WSxlQkbG3dmeAb/eTizKvlxam/4CcE0xNXI/pggoObqLGHxqbl50tcH6RR2M9eBnR4e7vcw+LGVdPF4dK5svOCv9ton7NtiWBsGzhZlU0/qgdrjCJj1GmjTex+DQTQmo4MfhnOIbHxzY5EhA+x9EfMIqa121AUjStTdZ0VeciHHXwnfphbopGt5ugl3n/WJi0GDkeBiddxneYfmaNZJAJ+5KYiXvxLTt6YFQsLooO88sRCzk5+6EMOnBHfmbiXdQr++g4XGXpjPd2pSF7jm288tMcnEOOBNPCX0roTiEF4btjx+TIworUQG6UVZLJngLHOLcXhcLKLvH1E9rx8Fse6RszzaW2S5ZAl9TqCqqiDmqBjUg2aJM2UMikqRAMrR82B/W71FG2FT5VQtFBB8rVvRkGtBZug5iUf//wdiy4fWuc9DvQ+OR1/SI0dpW2VUiCcggekeIf9oNZAB32ZnKH9T/GLhgxm+xSoxZwEN6QQt3Bng7Z9r4flMb4fKWQZfeY8/ewglnzotbZn2OwCsDSTyeZ8y6LuBqyRSbDGnJhyQsIdUEE/y7+8muF7dFHz7VWPcn4k2FsKz4/Ylu0tmiSG7i1PFDnTgSKMF/ZFISg2+nBxPyef4MaCyZKxzAwfCUh92bzmLALwm7EHh2skkJivjcILq10/Beqmh29jgvR5gyO4il7vTRnZ2I+7ZLR/Qs3z978NaPI8EnKPeTWd2HSKpD8HC4q1wZ40WOUL/NFN1KknkDIl4+tMweYzI0gKbk9hcwkoxQcG3ykRXkcrxXbem5wbzR26QNT+W7i11sYFiIfd2x21KQfkq03KSpjBuSXxqGi3LpA3GIhJmZF6iTVkkkj1cphrxYU1IRvdu2hl/UzW5TLxQl63ZiI//dmmMXsOLEhdQLEWSLSKpOx/wD8HabVMSl5XdvMCJy7GGt+o1npidLXTAj20ynW3l74z+F6cZM6Va8AW9X9aNLdJ+HXW+KzjcQURNoib4tAOAE/acIvwBI7/8c2jXD2m+SlRCPkbMIQKD9r1QYYKveHbGvFxWXTFH/VeYxB8EqT2EJBRrlldJQpXUoQOget8yETofpIv0zUs3xWvkfDf8CPdrpqqV/A+JRRgLXqIL0ozI2G5+0u//G8AXKlWXv5x9NA+BouO59VNNSrNncp453mVoEN0qgK1GyJhGIPpHOC+h8+DBJXEUkgtSD7Vanp0riccE6a4KMrhVwwx4o00Fs21/IXkB2bHA3rbq0rAkQY1avLxV64jNHCNi1+LoMlMG1HjfNTI/k0Tt11FT9BY/s8SOqIdqV6qR6IAZ+cs4PXp+mG0JEG+XA+XZT/vCXVHLWDuFO9nrwK7LYV3yQHfEwlrddCaEkh760iI5/Syc7fwikvkZ++Qr57atO8XlFggdaNqqD3TdtlI/88f85cfE3x81PSoo5YPIgRA9ohF4scuCLdnJrAvaHFyx0iM/ysZ82psNj0R/dyUSkyxJa3nhk7fhKXkBo+EEJnIRa1CKjClaTaJPbf47dkVHGErZnt+CVyMGvHXvBeXajBCz2l/+t6/mGuMKo8MaGFb1Lo5yv7x/2DoOBT0GyLuc1/Z3Icu1t+4d2ICfwxByf0m1IGRgXr/LOzKNZBOuNS6wBDIMehwrdNC9MTlop9hcpuZ9VQH1m4QOCNvN6tFD+jCuNlPgSW8yCasaIksaKycxyVLVKjChQfExA4ObvRmh9U/huZJm+AxNQ50whQsP/8is+JDdbWWgJsGq/SNKCuO71MUE7FejDBVFXP7FqR99qvGJCYOYa/NfP5BPUw4B7/NjTsZaDzk9bPU6QHnvk7dh3/p/jnTP6pWJkDjy9/tJLsbu6THLdgbUiKF4zd4YTAs9zOHa+eBXJaA101HTRccVck3KtPVr4xOPN4zBvYt27DWKv2/+NCs/HslFA165lyvkj7ELGFek5SZ3Nl81U/I6AEQlTqA+IEXudWAMX5QAAECliF5t60MYX8KgC9yNFXPfRRDPzy3TvKdT7DnPLvmFf3ANLtmydh/MvhvlpMCbHVK8kFAhglXIfk+kDbZAo6Uhn/D2H9nrBpIKvG38riBQfE/qsARJ3kzWAf++DFuj9taes1dFYVqd+v+Qh/ENBzdvCsaEJh/7ameSjzrztT10ED3EHfRcrNaPKcuVTjLtlrpw8pb53PVmmT9nEFAVm7SYpDTNb1XEHxf1rsYnN4clF0vtHrlpd23+qjE40u7Xfhdw12J4EDoOwViQtVdz1e/zY7pG/tjCMhYdWjThJFdYC+ORMLXqtoPvHSvgjYhh2kh7w1ZZbbZp15gr4G98BayAWiU39nhwUqYjSuXgKp77gZ3GCCrHpzeGkqx9/BH2tQd7PmiMUsVUzl7mi61yn3CU2kzlHx5LLkacn0mqSNQ9qBLipSic+xEGITZ16CDjqb+nyTVC7mwy1fk4ETd73rvu2LBmg07/i5kvTBvzlW38osfvjib07oht0Ff6k+Rd4XWPhyPYfftlTQ9zrSmDVDdkusTIi5sPImGblXDP+12RrP0JVY9ISEurNecWGhtrRc884e3lUsaseW5nrxepEvfyEqNMAGEoTH76OUhhlO3ugEN/UDyzMSKLZLRGnS8pnpN6dfy3XbtseBnglo/Yrz2ajBAiEErLDNR+zcixLuObYHdN3IbKL2Se+f1acFWdRsgPTgt4Ub5IuwsyRtW8UKfAlHjk0exy4NmxT2+eY+ehO+aGwin23zwf2bupOcwT7WrUozMMQVIJEPI/Xz+/PDy1txeebU151aeqpmDqCC8mhvuYtLyxbfM8DxKozpDx3xlPOo5Z9+tHVXJ7slOU6ofvBJ+3TG7ZLXscTu6zQWIdsEVd8yI4qKIgvXh76bBNfswqMMM2IVz/OyctkgznKc4Hj9BCKz7hIbNjCPBXxfovRoHYbvHQzYExaylXCwDKFEVN1b4ociB/NJJ9S5uEshoaKwHyu2OG0w3ZPIMPHa2i2DvCBEtEff5qR7u+bEppVq/zzB8APqT0pT/qzv1AHX0eJr3vXh3rCINNcq40S37XtLJnxVpmhQcPOZuxkbb204eqcyFniF8pX9NOo7MEtPvrJ15g3RlMmIFjG/YYMLY21l3IV+0710o4mle0E9VgpMWsVWH0/BocbPHJPpwNx1/JwoPkwoimRjvG49RVf/+Q2iRU2u5A4jIoYzG87YLYOTs7P6PPUr2ooSFxFtcu2TzxNw+50UJDuFL80EafevZutuwlIeIJS9aJqNG4FwK2Cx5mA9l6PyWjJc9NXI2dA4WdRqRc0fFw/ogrFQ3l5JT+540JBNtqk8BBuwNw/bmk1TcbVYUOz+beAJHGDvhwFJ4jI1w89Wb59Bg1QTWyho20yvoXvmJQD1vP3qx0A3kkW2OOn01KdkusnuAUuYBJpjVKg3oV9f6WnSszUzYqfnIw3uvI6n4lT2LMNmmQ+LELo3votOr75axyrsZr/agcxPkrBc4sFg1UDiznOOVw3mQIHV4vfQFjbwmC6DUUd3M5AvWAq2h9Azx2jMQcYfFb/hEHJ2NNBOqshChBV6DQe0HOW/EcNd2Cwuv9uLD9SYBuAbZSxhG2h3M/J0en1JghUUlHshaWF1EEMiRJt1aFsidF95vDLGCt40zLd38jxtwiZJdNltxc4jAXy+Fcl4A8DpvluxEBxGBPbgqf2RFFtCjVRhcqYMubJkOtbn51Eum0uDRIhIpi8jsVZZ9clOX26AMjKfYI2tb+V0qiktZlE1yrpIqg/ZmCYx9tJ2wHlgD0PHtchY7XekzICBIT7cItmzIFIxxSGtC3HN6l4gR8CfvHFtJBOl0pVWQEx0s1AFruAXcshJSeI7iuszwtQiH3jMk08DK2Ynknq9wTbW9GYKLX/q2eb5f/pv1WUn4EkZ9ij/YODBT6O0TSo+JpLi99H9PweVGqO1I0x0fmWjwPlj4lYSpFhPQQevdVgOTv+lTvAAqbjH76oatq1/V3tPeXcaPPtn47HKGFtGYB2+GNNc063Baal7aKT+AIZyTtx4amT0r65ot0yY30FZmx6EUcFMituzBbCqhwP5def7RyuxLU/A8NFleMm77rcDqEz+7qfK3NkODoJlAdSpzH+PCsKMx42fwDz5i/ryC6/izx8sXp/QAXveZMbw/H8vTHaBpPdf2h18PoVgJ2yaaxzWTrYN/FH79MLt5S5rV9vq0ecNQLR3RIgXZ7GGdC0JVReRYJm4NCTCcNzwTOaHfUdtQq7dGBNlBgqtuHW+NIinBwfVQxarOJ6U7wOU9OSA3nOYPbWhsuBqto5OcmOVjUzqkN3zZQcEfKspQQYn8vkEFgH2VZwu+rj1TASwUrPiyv1qLL5nB5JZbwx8XbhLYg5EZ2qDJPf5SyrqAONpU+2U5UxJ3KHZevAjbrZiupU9+hpasXcTEUeJXEDbobEkSmO65XqnLM7G4cd9NMAD0X7n/BPJasVJV9yQhRBgYHlTnSl5wpoozgWQ9xehJsBxl7t1o1GFtxhrHFJlCuNLnJinFpwvyvfHzjYv0jdhr3azsWiB5jiWL1rXcA4cAhv8DWLv4uhIPQpHNU+JA+L/3x61oz/8B5PQFavV6s+2LsVMvwoZqsZ/ypHYY9TdjSDIA+OxhEE+OkG5rTqbtzHxANfJehtqJ+tXl4tJtT+4K2Ac0CW5T4HiBT5UswPfMiXQbhfyoF4NMO1jZHJx/oTBVH7H2WN1hwOAMXytvlYib1vjohExsNaNwufrqkozVbDyS8temtP9w2HC3Ku8ko7klrjFa0OxgYAhvP91C+YNbxqxFMfjH1svwshDM+y4va9uXcxBcMb0gHE1eYl/6QcqT3Ju9yHNq8rTkHzIOoKO8FARVzDHmYxNLnXJ8H0XvJ6kWLHvmeC4kyHxbKt+day6iyr3v6Fq9Oh1pU6ZbiyQco2Cr7xvY75McIoXIJSIFNrMdWT6rpdoAKi1cQ+r3F2y+WXLj/l2jC4iPEQd1MGRxC30YFTSA3jSP7lF1yK/ug++qZgFTwVqsZVzVSpvHRF+JpZ1tvyPHcEbrf/VCXBjNGpKB7Ip8bUH6vjk4j7BB8yVcedTgFsoEMkLhOLoY+CKIS/hhBAU6gXbZhGHRuohLdYVSPWhGyK8HXPX8UADAsKaCqqJp7Vh7fXLlmfrCtuxRd9XCv6rVbqu9iO5eRyr2lcwtRNmud/USBxxG3JBKwlTNpivs9QNr5/yFtxl5EmQ2OewcZf8P1Z4oX6KBzoM6+4tMe2V2cZMTqdYLN//bdm69sgD5LaLlwotSkLcDYbLnHTuHaA9Ex1gdG9pVkipSOAoXKyQBvNk3fvG/oX9jFHgz+9fU5HvHgPXT81e2YJrumQYFTidIDu1JWuM9iYngPwszg0GkKVytJVsADzS83Gma+l5TCUEUfzTdC2ImlNLr/vLCeWYPTfQ4K58zqq7OpUPJFNVw1NImCQ471r2hMKdf9zDcfIp2e6FHfdbjnS0EHH6DztWIr0nsXLCgVhO1R6DQxoDoE17riWEg8QsZPOCx585Obyofj43ckO4DWoETQ+T+CzYl9KZW1bVq3MsIHiFOrUHNJXfIO9p6ww6u5LaeGvxJQlVH/mAFR9nBzqXsUe2yYj8P8WUxBMh4q5t9fAziXt1tZJpZLHVNBuEdEwjOBeVMejqAxGOcQJSawEaqcCTQXJSZmi4ry9IzeLJGiT3nRFj/uvRNUsXCDMg9KdEccDV2o3fxitbBMS55YiVYKuISTUsZe8g3BX0vud8uZp9M6NufHADHyEURGLiMbHzrVUZp21iiU6XnetE4UUhxcLGmgvgK4/gGf0CpFssM3vSoWah9p12Yb/lPQFKDMV8MkFlec3Ux3jGDIGALyHSv+7R+5ARZBCvJq1Stw5aCHxh5W8dCDjN4XuNi9s/csmRskU9avGkMMcNNj6sDrwxapn+IwUHSNUHgb7+lRFPHz9KOkQjIpIBgWMOoPvDIi4wOgq/d1wn4gsh7UG7xeuyxzjgDmhlEKSu+0P4YMgwL8LOKdzE/w6EqtrYCdq9o5U4ndRY6T1J1KsghST5j73flHkIkPrG48t2i1d5q8utyCtA5CTzG7rZw/nV6+XWJUXX+61hxKC9pzLZYwaTW0cb0B+fyLSLxWc8tH81z3H1/D2zM+itoQU1ax0ZVgI4m6blGEdgtt/kgd5oWkgG/JR122vsld9uaIGVonku8KS5K6DwbCj8ZQ1wUy4pr/n1C+CFHEtt8+Mq7JuBegpWxmRDGltFNMGG0xws8bjeGOwYXi72KVg0gGu4L4y+8vEgzbzpX/vUrN3/NHCUUGizg4iGvVz+veLmz18y01CG0RjHWoqKKI0qjOEBLRqpzFoB+Ly7jbdarUQ6HL2/Gx2cTzLG+PDKtQDOshZqVZgKdxHzaQrwJZeBKBPtgZZhUMpR7edelAV988YHB7FOivMq0fcxZ5/EWAazpx77zb0Rc9MD71a8jmcYV4qfUMU9+0rnUUW8Qcoy3HLB0wq/nmljkDOnaTvd8ksNYctZ4DTTgv/e9A3GHSqwY/6EiLJPUxLtmZnBudBglMBc8jqdz+30L6WpwFvRGgCfIjXX8OAPbO/RheVQWagZOuFzSeWjux/iQB/sNPwkUA146clhmsIQp4ax2QJClHmKM3r9DRb7jcnj8agudM9+Mt4gmoOQTmisgv00wAFrk8mBTiC7lke91/47flTXyBiWQiddBjXKkWccfiaO+92p49WstZg2F+PIyVPzYqd34Bl9bTivykW+n1UDA0xwa4OJW1/B7XbMpSuFMQvJV8vh5lzK4ERufiwh5BkFijmK3d3eeSuHHkHb12is8KOmGDY6RXCZwEvoA7URuIxlI5rb/8TI8ZWdvxswaR0qkCu4sbsTsgkC//+AJoRZvJBnwSN8ndI0vXOXrJmc32Htqgf78wHISjDNxPixYRecRedE7HnjBtPUggUis9P2O7EJNgRjjL+40oYAelfXDnrd+zDSO6EUi/AIH2nOZ7gFnLnu9MYhcS3I2UCXvo31Jopr4U4Y2ERiDew7tWRpRQ2o5pnyrk+4E45L+8S4Oew5YtcHzLlktAJJIAoQ9UjmVDAvhv0G8VlFMnHy8qw+HuvHO19X3j66h4+6vPbBrpwasN6C/4LEzV5071AxyC+/JLETZm/FDnTaV9qz8YGE3OOekyn2cnPeMqHWtAi7l0nAm7ovnVuC+1JL9hm/5/ZZySyLX6+cRX160geA4NSkeQtD7vhB2TUm4c54DQTbvQqtMgDA7VXNAwBvLWvwPZ1suYkg7maJ9cDX5cCZIX2/MhBbqjFlWHVE30A9dPg7kbJm+ey0PapjHyi4x39Sqms4CI8VOKL0SVTNC0qTyVwHDrXfaiZBi4UwSMr8Zm5301jm7ifNk9BhWdCoVYB7RR9DKK71zjkqxdtuRJQYcyA6npSMb1GsyysUq+kgtk7iX1zKB9uIhU6l/VcsYhKOl5Ky1Ai48fdYK1T5UpkQ89hDjcSsg9oFRUfn1qqF+EIoyJY1Co7A/Gd135kxnyTDVZ8zqFGt+IkvjzarRrLvXV+v7/MDT+uEzVOozaWhj7U8fC28IbYkbGGehxNBXv3vj/lbDI/6O/CyFoFRDBtZo0Li+TODq7LO6TyR+8Otl/s9nD4XAXWoZsUn07efQ0DrknCx6ktCZGi3ZjgWeoIhFhStYzA7ridFJVVIUKDB/z91VePw/US3cBYypIDXapncZuckiyQCN8nar7y8m9QrDVT0nBR9CY3LFpiZ4y+UvWkcuIwF6x9UR2E9puaERuvkmGHee9nsIPkgJCKjkHxtJpByeD0jCIxSej226EnUeNVxSl7Qm7Usae0Cun8eQOZUudW5Ik+RVHvA7m9ReCwx4GML+DQnNBxbJsxzTRb+dtJlkD696NGJxFbROhjxZ891mml0wstf7gC0ltE2AqUQFcaf1gKFhIFgG7Sfxu0oAj93iRxFsL8f4HVi1Xio+CoJ5pWeIO/9L40b4i1wOcxcJq/X5k0Rr21B3yP7N0+uJyxLcA7M128tSPKtMAS0rvZkgY2bH2bTIPxGkzdPNuSaJD17hhA4Yg2qcj/oPI1Maa0rDL7jmubgUxbmQoukQOLQ1neyjc7HWPMW4Vehbhacx3CVA7tl9uhiZixaDxmEZHM2gdQuCZYzkbkYn+5+Su3jpBdHt3CjqTcZ9upe38Ju43TeeypuZeSvES6OmVvI9Jek8OBTNdznSIAD5mX4v3IFKIvDZzIyz5MH+yTvVJgAWGB1iFic3HTNpN0+Bzh5BM+DUYFn97AU6Z5S6G3oUEZ2wMTEsMk/uv7Vm0FOBfXHPQhGg7ksRK62tlF2tB0yJVa3Si6TsLXtLAsIeU7ct3k51nueHjZymiPfnNOoVR1s9KgP5SsVovzMyW4tnmrz2zThFDALv2bTa0bVytN9XUHH43nKn5AwGYtCavJdUy1LdhHAuiUCSnUGCU0LqM6SfNeAatX1meSa+n9+ca2+z8hU3p+XO/2uomWXKPoUERaeZ3pVta2WUahijaTsONJyoH3TFjM4+gAuBZ/97qpxfJ8EDr1iDo5cbWkZwCs6LvWJVlG1MVIz/vYklW6r+37EFCCxWoW+sdRxt5nSOKHFYuScGTtZ5423fvqobG8wa2YGKlpHHrWtpqdt8EKhGD+qULOk2c7B5Fd9Rd5WT+bxP4l3+GEW0bxnAFwXi/TEUCtJlFxaOw5/Z4LC2Dy+6tvEy+EReGKUDA0hW2HkNQm3XNcYm8A4xwFAZNPqTkSKR0rXexyHgmui/lVNj4ypbe9r5mdWCLRt2IBZjZ1Vg8DYck87YWElrMN1JoLlkl6wo6q4fs0OZqibjG7Q0PFrIJQsmcof+HJCLJ+NR+8GPUyv5gwrr6rxed9zdWJQXevNsupUpbjnCdW2T6Kfkr2Rlv3HCmuHaPTbRph0XQSh0J0OAnRkylVjDGZW9CYh7xHgZRRu64GNE7+LwbEiPbTOUuROu/m5APZKL057Oe0WvCdl3oTwTD1cvlBW2o8UZ9L/u11rAyeX2SUgjBnd319cislRPM3zBMWjop1hwPEffg/NHzq0jZBAO6AxAvickx8IOlkU03i7SKnGgVpR4duBY62lJFWrI/wEnny51uon9ozNw9JctBJpbvMAMQD01UG5Z/vYRq8mxYnIWE0PPQ+w+u6Po3wUg3kxjbjFBhOKAdz8YUNchblGnFIvQ3aWPEUQHle+mG4KyIKTuomSXZBnqtGZnIUt76MYAXlI39Dhgrkok7xHECabVQi0eodJv2mZ4vJNpv64kPsjSJHX8KV7wk2R/vRZ5dvikEK30XWs3WxFN9nkMObEZYJeSrBUXzZHGSRH6ELsK7IhjDmMGWkwHPhtMDQEP9UZEN7gEfBB5b+C8Yajb2aUm7yiNUiAq3EJ0fHS7WC38J0dFWNLZI0gerHmzaxvPnB6WGnXiVILme6LV+1458zvXE4D+wO58oGZvS1tQWK6X9wk31zfuN/AtnIyndigFtkYS4BdaZmMTvSpQRYKJvqp+mBZRZ3u0yyoY92AfnYDr8J56Q66xd0M4GFuT0sm1zKJgYgopTZ4T2QWydziSv3G4T369DmvddEgV6lgTSBF/R5+60/hdhCpHPyRZEonoAAB/ATz0k7vi4OCsIPkmjV7Yt+TSSKBCzEXR/t4NmWhZbbg7db6cERT1NNvPEbz3MKrKPJUSV6nME3+Pm6VET35tVezX/3d4tq7T1H8PZwScsvDL6qk+UBnze7Fmlvwh5Yi4sO5QGtYlSnQI13/1u8/pyFENN0NxizJIQO4NWLwrQ/bst26b6ZTTE+subNgBR4qVKdfCYMp/xFAN3ON1Gz1EdEDq3KQdMj3Myl2AsjgRFxjIZCA+QJ9QWa0FJs60xrViFJOxueaLzg/bei0e1YUEeYHLUbtszVHoZIPZNOBeHzsqA5ePgu7xW9e/+9r4UaCU6YzC9b2f4LZmZhp8rzKN7DrSnjZ03OlSLMJRuyS6opmhv5mr84oQJaNGnk6sTBPGs9u0O8mk8J9VYPbn5vnB/YapZOWrM1fHUeRL/BQKhoxi+M/LwlkxiaJBPcieAnSPuikaMcvxEtNELjexoJmvRYJrdberg1PGiK+ucY5sp7gc3CT/Eg/Ln2AoYmcTqAkMVoxugLFUGI/UZWHaf2OwQYWWXtQjoR3PPQdEbAaQ7UafePDSogk5jYvmRPce21QbsdehrWTajaygJrBl+vBNdmG7hQoFymry4Yy/ppgmi4FqbnwvlCdGbxYBUo4aZDLw/NkiAbBRhT1w5+OAAgMBwpM1PxB2JJIthHW7S3DZz31GsbzCa107NtbiGyOoLzSjfSufiXf0FDx4laqm2ONHQyhg0pGg9A1ZOce3WNi2fCBW8ObDVUvcTXsTcNYhi27h8SrosxEbHTcks2NO3v33tyo9qdW3k8aHPb/OgBO02emrwjuSf5PnMLb+b8VTkCtQVExPGLgb/sxk7x6ltksIIbpYXPBY4sBxm3KiN1We0JYFgagFwhtOZym5CbXLmVoG+UsINlmTvCiEm0RdIVHZ4a19iYrRX0upgKR8WGqXp+bOT95Fap7c9dROA/7cLHZoIzf7yoSqNXaVCTwQdd0VLv5n9e73yAIMuIr8W0jmgBSNg35sGSKBBWBqc3zLtxcL9G33Fm8LIgLb3S63Q4zpJOOlViRxGBVD9M6YX76SQPFt7cPH4G2HgSQMQrk5RsZ0EB4sAURy7kR6/suwEP3dXtQL5MH2MfaKEho3OIbzvxgy9AEwmcglxcRwxifaqAEtE8x3H9RV4ksPA0NP6FvoPWHO8kL1soApiu9TTmd3cQqTg0nt/grv6X+jcJYk7cwolkv+kdaRhvWUPsUDtSrf6eJspn21ge7y+itUztICgdwiqgnQb7t5cuZwiQ5uo2UMHsaNtmwjttdC+fhuQ8ZZmPiQa4Rfdo9KqgJuFmg4gAJhzHeR0F+9qzMNyQWvfXrNLuk1OQJc0RfXEsOq0RH6mLVWQF9upVwS+EPsQIhSfZqs+qg2q4z7CeFVmT38rJkxNJOuEPMkgfr+l18BE0pYHjHQ+yBPbh8RqlZ6FEL+qh2hqcXBo5BkeDcITo09lMd4bpse1hWcZU3DQ2w5Qb0xSqTpO5zEyxGUtDtaw8xBE7ZpfBL2PVkDkv7Lu881VzoZ0t3Pisa2O78o+VPfkafu1t6/I5ZpP8dhwUkfLV6lgZBGSEZGYU8FKOnTVL7+Ad0N+RxFCtKWmNDN3LImr/klgp4SsAW96K4ugTshT7X/7y70Hmo93S2jhfNo+CaTCM9WtST6jIzTFXFzMhwXvhhNhPplPwraLO9p3/qTaUZuSLM0HhUtmaFTkGqxIoatts4Vi3SUwdRIi308Wh67N7nXKJm/XqgrT+P1kMAVmBOOl75fMEUuOF1/Jx4TJXhz/z+ITo6WKTHuivkFlxTqR5dEnXVPBYoI+cqkCfOLwLpxZALl17YAqHA3fssC07hP6HckIfz9MFfBmDAE6xSh7RPhkhlZIpOnRxi7ptu6QD/qnKCRF0D+SOfOtaR/ctZHXqIFJ01+f7v+rjyYaBd4Wv8j8+L4NOjblHjKavNdr3QNnekswz2Cl5oGSXSjye0wJrDt4dF5XasDFuNuoo63PAxfazab30ZVQlnr5+9tYlK2H1lktcJ3D+G5kN8RVIRvLhDPD/9vPN2BCmJh0Tl9YrDfeI3F7CvLBIkMvUM4TcJTgUtIpXhhkx7w8Z2YerdLQgXY1zDihAh82dogUo8YNHN66fUKKtcWTFIoahSdripcuctYkXwFlr70i7q9K+RfaP6/bRn4a0ebeLJcC7OdpGWM1gX5amGwNEQxzsGbwyoBnsEAfQRfZh5tVHQOBsdJQR3LltJLQMZGGDsaV/aVnsl8zho/xV0xT9ogcPbhp6v2o57SvJ25Ymhs8MTErA+2V91UKob9PFylbyoHAOboo31BSG3yiE6nFG4Xt/Wp4Dg+uweuHR6HNu61WNHBhignZ5Fq52YgXpwwwzxlVx3MLm49vgB5YU3Vy2/bCCwUTJ2DTyQaVGxzr+VprNXeFOkE0P+sgcxqU+w6co7Ip1DehwHnGH48NJnZrBPunDM2S/s8hwdSVm5kb5C/DcgNy7rVvrykFAsqT3J9G8OBVDIbxD8pl48JLgo7qtMC1JFGaxEqoGCouMuVnlIOLSsEvGzfG2zGZaXmObiTE8HHlAgrQUIMfwwVhPh2I0bd+y3GwyTmqpi4iRLv9evJHV5ibinjHFg5nRRWQ2JJfv7mb/vDeOHr6WnU70oNe9jgLMMk+aMFXpZwTJn7EhDgxDAKcZU82IKdjxeI78ZychOQZSrenLW5x8VacP1iis03KBCSwKXloWrPFGFtP+3GZPVgUntsAeTs3fGx8HxQMxSLGIabFZ8s+oMIqTTB2d0CdZ0FaAt3dzzJUWGIx6IIfuH0YAeQW+NA2H1fPoNjmJVXhlSgWlamUTqIP3wg6HAZ+hraN9HbDTwRqJciKgXXEAJ38xrX0eIH/jh+7xxYJlntWEVET97xwUzZA3fkAVszgMJ7wcDn6k94PkPdVPUBYRr7MUDigbCTDCmGrb+t7PVxnkEdze9xyQUU0yyThmWDl+y+TTBqk8XyyS6WuAtpB79ro0lX2cya1R9ZH9dlhd5xaMKBcn9l+z2upUMG3ZoQNQPCoS8VrEC3V/xq90d/Fr9SoxopcQBRd2UjpfhVb+KmxH9TqeNU1D65lj/AWKToCCrQ6Nzuz6QDckC9etTMK+eZIx89n0HxhZyOpxBuMQPlxR0f4doi5bDK5V/1v7rRfRiDlGAAKJdg4LpnIAw41vhN0sBzccO6805/tjiQTuZ3J9G0gbptdRPChtcB5t1HazJ/U26s3yDkfVkidIb2JQI80bpEceLVLVvcmFegiNvgleobG2JykqD1d8B/s3Mm4lwamzYaWVLuudIZoPLgyAnqYBeAwa1dmKgGDq8sSBPRdyFI8IsW4+9TV7BzIEaHeYQ/eXu578BX2Rm0Uwi0qTvTm6J9dtaQhu3R1E/NDPkb4EbQOtTn9JaMTozP7VhumQH05xrkVlRE0Inq/OVnevJtslkP8IRZoN838Jr7Lbdm50mKV0yj7u4PhzHiPkDvAVshIC2f9KIXae7+85JeRfSTYQ/0K5FtefMx7bPYTkWe+tyZ4g4gAhe7cyBJlyVPohgXaRMjKB6vcPVEvoDIr0A2yIkOx3J7gdvHu49PqQcTuvdDTnHvVXvcI5dtG0spucmWMPFZpMRHCZREaMJLUhjKCHXp5sK5Cs5ipmuZB2NMyrtfbObzObLDkBzV2kaNk69tJupISXAT/vqfDRIf/m7fRophCcFuoOypzNUp2y+IRRg2TCzlYUrcbeh6KvZ4QGWkCuIlvoSvaBKQFALkoY2zeoDmAqgkvpgWn7RZnGM2crB+JPdi0BBYYoMbR9vBv1hLXJ+ChYL3TqYwmJZwn0cL5tTU2feghtBxvlpWuSHrNgsVjIP3hfua6vox5gb6UnUV060Uja1jOvTAjiFbQGMAsW0DsPsK7SBUD0DyMCzwpikFeUZg0NHK0iY+8irGLy1IUTm/SMaREfipZCDkTEU2NY5xQa+g86cFV6+90hnxONTY1QajLzY8n1XSNoPnqsDwMlmxDqemAK0IBkksDdqPWTweYkMBgzFfLNxteeR1b+S53h0drKhubjuQlpIcKNYUI9wD3FCFCQVx2E79i1YIB6Uv/cpg8rQ/DOfvNqRhwl3tpsoRInuZWR3ZCagJiI2PDBacdMFomXqqn2CUTzsHxm9xOVV6CUglA4UJ8C2TNFAXapDWJNCJASZWp1HfR0SMHZ8HMfZFUgx1FIs8hBaEzjS1YAwtL6tivRU+qQtcnxkkn5tiL8KLr+zFStaBXfhh6JBbu8VGMz8gb9I+7Cvgi0KcuvKBiL5EoRUt1/cy6v3yX8jpHKe3UGHdiyQz6twDQ4xglNQQKbmodlbyA6s0p7b6BsLbsDHIhjdPI6Uxpe9MPTQLEC2f5075MogLXXHbWgiiLb2d/NDI0EXyEFYABUOCwUxYb9v0lk1T3oScZ+hsqgYsSvaGkcFvk1lpz3lb3z8chfzI9vVRTrrEDzvrgHobLYeso6DhjgcpCkdVGAiZASoL1GIp5UhcrvzYLoVvKSxZq57kX510oy96D4kv2yyTGIRElyKhnL2z2WJ087zoaMTuHsQ2JBtYlzmenAAAA="

st.html(f"""
<div style="
    position: relative;
    overflow: hidden;
    min-height: 292px;
    display: flex;
    align-items: center;
    background: linear-gradient(115deg, #10233f 0%, #173d63 58%, #126b68 100%);
    border-radius: 20px;
    margin-bottom: 30px;
    box-shadow: 0 12px 30px rgba(16,35,63,0.13);
">
    <img src="{hero_image}" alt="SmartMeal food demand analytics illustration"
         style="
            position: absolute;
            right: 0;
            top: 0;
            width: 54%;
            height: 100%;
            object-fit: cover;
            object-position: center;
            opacity: 0.98;
         ">
    <div style="
        position: absolute;
        inset: 0;
        background: linear-gradient(90deg,
            #10233f 0%,
            rgba(16,35,63,0.98) 38%,
            rgba(16,35,63,0.72) 53%,
            rgba(16,35,63,0.02) 76%);
    "></div>
    <div style="
        position: relative;
        z-index: 2;
        width: 62%;
        padding: 34px 40px;
        box-sizing: border-box;
    ">
        <div style="
            display: inline-block;
            background: rgba(255,255,255,0.13);
            border: 1px solid rgba(255,255,255,0.2);
            color: #d8f5ed;
            border-radius: 30px;
            padding: 7px 15px;
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 1px;
            margin-bottom: 17px;
        ">INTELLIGENT FOOD ANALYTICS</div>
        <h1 style="
            color: #ffffff;
            font-size: 36px;
            font-weight: 800;
            margin: 0;
            letter-spacing: -1px;
            line-height: 1.2;
        ">🍽️ SmartMeal Dashboard</h1>
        <p style="
            color: #e0edf7;
            font-size: 15px;
            line-height: 1.8;
            margin-top: 14px;
            margin-bottom: 0;
        ">
            Predict Smart. Prepare Right. Waste Less.<br>
            Transform food demand data into smarter preparation decisions.
        </p>
    </div>
</div>
""")


# =========================================================
# 8. KPI CARD FUNCTION
# =========================================================

def metric_card(label, value, icon, caption):

    return f"""
    <div style="
        background: #ffffff;
        border: 1px solid #e7edf5;
        border-radius: 16px;
        padding: 22px 20px;
        min-height: 140px;
        box-shadow: 0 5px 18px rgba(31,50,81,0.045);
        box-sizing: border-box;
    ">

        <div style="
            display: flex;
            justify-content: space-between;
            align-items: center;
        ">

            <span style="
                color: #718096;
                font-size: 11px;
                font-weight: 700;
                letter-spacing: 0.5px;
                text-transform: uppercase;
            ">
                {escape(str(label))}
            </span>

            <span style="font-size: 22px;">
                {escape(str(icon))}
            </span>

        </div>

        <div style="
            color: #172d49;
            font-size: 29px;
            font-weight: 800;
            margin-top: 17px;
            letter-spacing: -0.7px;
        ">
            {escape(str(value))}
        </div>

        <div style="
            color: #8492a6;
            font-size: 11px;
            margin-top: 7px;
        ">
            {escape(str(caption))}
        </div>

    </div>
    """


# =========================================================
# 9. DEMAND AND WASTE OVERVIEW
# =========================================================

st.markdown(
    '<div class="section-heading">Demand & Waste Overview</div>'
    '<div class="section-description">'
    'Monitor demand, preparation, surplus and unfulfilled meals.'
    '</div>',
    unsafe_allow_html=True
)

# First row
c1, c2, c3 = st.columns(3)

with c1:
    st.html(metric_card(
        "Actual Demand",
        f"{total_actual:,.0f}",
        "📊",
        "Meals actually ordered"
    ))

with c2:
    st.html(metric_card(
        "Predicted Demand",
        f"{total_predicted:,.0f}",
        "🤖",
        "Meals forecast by model"
    ))

with c3:
    st.html(metric_card(
        "Meals Prepared",
        f"{total_prepared:,.0f}",
        "🍱",
        "Total meals prepared"
    ))

# Second row
c4, c5, c6 = st.columns(3)

with c4:
    st.html(metric_card(
        "Recorded Leftovers",
        f"{total_leftovers:,.0f}",
        "♻️",
        "Recorded dataset leftovers"
    ))

with c5:
    st.html(metric_card(
        "Estimated Surplus",
        f"{total_estimated_surplus:,.0f}",
        "📦",
        "Prepared above predicted demand"
    ))

with c6:
    st.html(metric_card(
        "Unfulfilled Demand",
        f"{total_unfulfilled:,.0f}",
        "⚠️",
        "Actual demand above prepared meals"
    ))


# =========================================================
# 10. MODEL PERFORMANCE
# =========================================================

actual = filtered_df["actual_demand"].to_numpy()

predicted = filtered_df["predicted_demand"].to_numpy()

mae = np.mean(np.abs(actual - predicted))

rmse = np.sqrt(
    np.mean((actual - predicted) ** 2)
)

ss_res = np.sum((actual - predicted) ** 2)

ss_tot = np.sum((actual - np.mean(actual)) ** 2)

r2 = (
    1 - ss_res / ss_tot
    if ss_tot != 0
    else np.nan
)

st.markdown(
    '<div class="section-heading">Model Performance</div>'
    '<div class="section-description">'
    'Evaluation metrics calculated on the selected test records.'
    '</div>',
    unsafe_allow_html=True
)

p1, p2, p3 = st.columns(3)

with p1:
    st.html(metric_card(
        "Mean Absolute Error",
        f"{mae:.2f}",
        "🎯",
        "Average prediction error in meals"
    ))

with p2:
    st.html(metric_card(
        "Root Mean Squared Error",
        f"{rmse:.2f}",
        "📉",
        "Penalizes larger prediction errors"
    ))

with p3:
    st.html(metric_card(
        "R² Score",
        f"{r2:.4f}" if not np.isnan(r2) else "N/A",
        "🏆",
        "Variance explained by model"
    ))

st.markdown("""
<div style="background:#ffffff;border:1px solid #e7edf5;border-radius:13px;
padding:16px 20px;margin-top:12px;line-height:1.8;color:#526176;font-size:13px;">
<b style="color:#173d63;">How to read these metrics</b><br>
<b>MAE:</b> The average absolute difference between predicted and actual meal demand.
For example, an MAE of 8.36 means predictions are off by about 8.36 meals on average.
Lower is better.<br>
<b>RMSE:</b> Measures prediction error and gives extra weight to larger errors.
It is expressed in meals; lower is better.<br>
<b>R²:</b> Shows how much variation in demand is explained by the model.
A value closer to 1 indicates a better fit. A negative value means the model performs
worse than simply predicting the average demand.
</div>
""", unsafe_allow_html=True)


# =========================================================
# 11. MODEL INFORMATION
# =========================================================

st.html("""
<div style="
    background: #edf5f7;
    border: 1px solid #d6e8eb;
    border-radius: 13px;
    padding: 16px 20px;
    color: #31536a;
    font-size: 13px;
    line-height: 1.7;
    margin-top: 16px;
">
    <b>Model insight:</b>
    The full 2025 test set achieved RMSE 9.84,
    MAE 8.36 and R² 0.9078.
    Metrics above are recalculated for the selected filters.
    Results are based on synthetic demonstration data.
</div>
""")


# =========================================================
# 12. COMMON CHART STYLE
# =========================================================

chart_layout = dict(
    template="plotly_white",
    paper_bgcolor="white",
    plot_bgcolor="white",
    font=dict(
        family="Inter, Segoe UI, sans-serif",
        color="#526176",
        size=12
    ),
    margin=dict(
        l=35,
        r=25,
        t=55,
        b=35
    ),
    hoverlabel=dict(
        bgcolor="white",
        font_color="#172d49"
    ),
    title_font=dict(size=18, color="#172d49"),
    xaxis=dict(
        title_font=dict(size=13, color="#172d49"),
        tickfont=dict(size=11, color="#526176"),
        showgrid=True,
        gridcolor="#e8edf4",
        zerolinecolor="#cbd5e1"
    ),
    yaxis=dict(
        title_font=dict(size=13, color="#172d49"),
        tickfont=dict(size=11, color="#526176"),
        showgrid=True,
        gridcolor="#e8edf4",
        zerolinecolor="#cbd5e1"
    )
)


# =========================================================
# 13. ACTUAL VS PREDICTED DEMAND
# =========================================================

st.markdown(
    '<div class="section-heading">Demand Forecast Analysis</div>'
    '<div class="section-description">'
    'Compare actual customer demand with model predictions over time.'
    '</div>',
    unsafe_allow_html=True
)

daily = (
    filtered_df.groupby("date", as_index=False)
    .agg(
        actual_demand=("actual_demand", "sum"),
        predicted_demand=("predicted_demand", "sum")
    )
    .sort_values("date")
)

fig_demand = go.Figure()

fig_demand.add_trace(
    go.Scatter(
        x=daily["date"],
        y=daily["actual_demand"],
        mode="lines",
        name="Actual Demand",
        line=dict(
            color="#173d63",
            width=3
        ),
        fill="tozeroy",
        fillcolor="rgba(23,61,99,0.07)"
    )
)

fig_demand.add_trace(
    go.Scatter(
        x=daily["date"],
        y=daily["predicted_demand"],
        mode="lines",
        name="Predicted Demand",
        line=dict(
            color="#12a58b",
            width=2.5,
            dash="dash"
        )
    )
)

fig_demand.update_layout(
    title=dict(text="Actual vs Predicted Meal Demand", x=0.02, xanchor="left", font=dict(size=18, color="#172d49")),
    **chart_layout,
    height=420,
    xaxis_title="Date (Day / Month / Year)",
    yaxis_title="Meal Quantity (Number of Meals)",
    hovermode="x unified",
    legend=dict(
        orientation="h",
        y=1.12,
        x=0
    )
)

st.plotly_chart(
    fig_demand,
    use_container_width=True
)
st.caption("What this chart shows: The solid line represents meals customers actually ordered, while the dashed line represents the model's predicted demand. Lines that stay close together indicate more accurate forecasts; large gaps show dates where the prediction differed from actual demand.")


# =========================================================
# 14. CATEGORY-WISE DEMAND
# =========================================================

st.markdown(
    '<div class="section-heading">Menu Category Intelligence</div>'
    '<div class="section-description">'
    'Explore demand distribution across different food categories.'
    '</div>',
    unsafe_allow_html=True
)

category_data = (
    filtered_df.groupby("menu_category", as_index=False)
    .agg(
        actual_demand=("actual_demand", "sum"),
        predicted_demand=("predicted_demand", "sum")
    )
)

fig_category = go.Figure()

fig_category.add_trace(
    go.Bar(
        x=category_data["menu_category"],
        y=category_data["actual_demand"],
        name="Actual Demand",
        marker_color="#173d63"
    )
)

fig_category.add_trace(
    go.Bar(
        x=category_data["menu_category"],
        y=category_data["predicted_demand"],
        name="Predicted Demand",
        marker_color="#12a58b"
    )
)

fig_category.update_layout(
    title=dict(text="Category-wise Actual and Predicted Demand", x=0.02, xanchor="left", font=dict(size=18, color="#172d49")),
    **chart_layout,
    height=390,
    barmode="group",
    xaxis_title="Food Category",
    yaxis_title="Total Demand (Meals)",
    legend=dict(
        orientation="h",
        y=1.12
    )
)

st.plotly_chart(
    fig_category,
    use_container_width=True
)
st.caption("What this chart shows: Compares actual and predicted total demand for each menu category. It helps identify which food categories are more popular and whether the model is over- or under-estimating demand for a category.")


# =========================================================
# 15. RECORDED LEFTOVER ANALYSIS
# =========================================================

st.markdown(
    '<div class="section-heading">Recorded Food Leftover Analytics</div>'
    '<div class="section-description">'
    'Monitor leftover meals recorded in the dataset.'
    '</div>',
    unsafe_allow_html=True
)

leftover_data = (
    filtered_df.groupby("date", as_index=False)
    .agg(
        actual_leftovers=("actual_leftovers", "sum")
    )
    .sort_values("date")
)

fig_leftovers = px.area(
    leftover_data,
    x="date",
    y="actual_leftovers"
)

fig_leftovers.update_traces(
    line_color="#d97735",
    fillcolor="rgba(217,119,53,0.15)"
)

fig_leftovers.update_layout(
    title=dict(text="Recorded Leftovers by Date", x=0.02, xanchor="left", font=dict(size=18, color="#172d49")),
    **chart_layout,
    height=370,
    xaxis_title="Date (Day / Month / Year)",
    yaxis_title="Recorded Leftovers (Meals)",
    showlegend=False
)

st.plotly_chart(
    fig_leftovers,
    use_container_width=True
)
st.caption("What this chart shows: Displays the total recorded leftover meals for each date. Peaks indicate dates with more leftovers in the dataset and can help identify periods that may need closer preparation planning.")


# =========================================================
# 16. ESTIMATED SURPLUS TREND
# =========================================================

st.markdown(
    '<div class="section-heading">Estimated Food Surplus Trend</div>'
    '<div class="section-description">'
    'Identify meals prepared above the model-predicted demand.'
    '</div>',
    unsafe_allow_html=True
)

surplus_data = (
    filtered_df.groupby("date", as_index=False)
    .agg(
        estimated_surplus=("estimated_surplus", "sum")
    )
    .sort_values("date")
)

fig_surplus = px.area(
    surplus_data,
    x="date",
    y="estimated_surplus"
)

fig_surplus.update_traces(
    line_color="#d97735",
    fillcolor="rgba(217,119,53,0.15)"
)

fig_surplus.update_layout(
    title=dict(text="Estimated Meal Surplus by Date", x=0.02, xanchor="left", font=dict(size=18, color="#172d49")),
    **chart_layout,
    height=370,
    xaxis_title="Date (Day / Month / Year)",
    yaxis_title="Estimated Surplus (Meals)",
    showlegend=False
)

st.plotly_chart(
    fig_surplus,
    use_container_width=True
)
st.caption("What this chart shows: Estimates the number of meals prepared above the model's predicted demand for each date. This is a forward-looking planning estimate, not a measurement of food actually wasted.")

st.html("""
<div style="
    background: #fff8ec;
    border: 1px solid #f3dfba;
    border-radius: 12px;
    padding: 15px 18px;
    color: #805b27;
    font-size: 13px;
    line-height: 1.7;
    margin-top: 10px;
">
    <b>Important:</b>
    Estimated surplus is calculated as prepared meals
    minus predicted demand, with a minimum of zero.
    It is a planning indicator and not measured food waste.
    Recorded leftovers are displayed separately.
</div>
""")


# =========================================================
# 17. UNFULFILLED DEMAND ANALYSIS
# =========================================================

st.markdown(
    '<div class="section-heading">Unfulfilled Demand Analysis</div>'
    '<div class="section-description">'
    'Identify situations where prepared meals were fewer than actual orders.'
    '</div>',
    unsafe_allow_html=True
)

shortage_data = (
    filtered_df.groupby("date", as_index=False)
    .agg(
        unfulfilled_demand=("unfulfilled_demand", "sum")
    )
    .sort_values("date")
)

fig_shortage = px.bar(
    shortage_data,
    x="date",
    y="unfulfilled_demand"
)

fig_shortage.update_traces(
    marker_color="#c45b61"
)

fig_shortage.update_layout(
    title=dict(text="Unfulfilled Meal Demand by Date", x=0.02, xanchor="left", font=dict(size=18, color="#172d49")),
    **chart_layout,
    height=350,
    xaxis_title="Date (Day / Month / Year)",
    yaxis_title="Unfulfilled Demand (Meals)",
    showlegend=False
)

st.plotly_chart(
    fig_shortage,
    use_container_width=True
)
st.caption("What this chart shows: Counts the gap when actual demand is greater than meals prepared. Higher bars indicate dates when the canteen may not have prepared enough meals to satisfy all demand.")


# =========================================================
# 18. FEATURE IMPORTANCE
# =========================================================

st.markdown(
    '<div class="section-heading">Demand Influencing Factors</div>'
    '<div class="section-description">'
    'Understand which input features influenced the trained model most.'
    '</div>',
    unsafe_allow_html=True
)

importance_sorted = importance_df.sort_values(
    "importance",
    ascending=True
)

fig_importance = go.Figure(
    go.Bar(
        x=importance_sorted["importance"],
        y=importance_sorted["feature"],
        orientation="h",
        marker=dict(
            color=importance_sorted["importance"],
            colorscale=[
                [0, "#b8d9d4"],
                [1, "#126b68"]
            ]
        )
    )
)

fig_importance.update_layout(
    title=dict(text="Feature Importance in Demand Prediction", x=0.02, xanchor="left", font=dict(size=18, color="#172d49")),
    **chart_layout,
    height=550,
    xaxis_title="Feature Importance Score (Higher = More Influence)",
    yaxis_title="Model Input Features",
    showlegend=False
)

st.plotly_chart(
    fig_importance,
    use_container_width=True
)
st.caption("What this chart shows: Ranks the input features by their importance in the trained Random Forest model. Larger values indicate that a feature contributed more to the model's predictions. Feature importance describes model behaviour; it does not prove causation.")


# =========================================================
# 19. DAILY DEMAND VS MEALS PREPARED
# =========================================================

st.markdown(
    '<div class="section-heading">Daily Demand vs Meals Prepared</div>'
    '<div class="section-description">'
    'Compare the number of meals customers ordered with the number prepared each day.'
    '</div>',
    unsafe_allow_html=True
)

daily_preparation = (
    filtered_df.groupby("date", as_index=False)
    .agg(
        actual_demand=("actual_demand", "sum"),
        meals_prepared=("meals_prepared", "sum")
    )
    .sort_values("date")
)

fig_preparation = go.Figure()
fig_preparation.add_trace(go.Bar(
    x=daily_preparation["date"],
    y=daily_preparation["actual_demand"],
    name="Actual Demand",
    marker_color="#173d63"
))
fig_preparation.add_trace(go.Bar(
    x=daily_preparation["date"],
    y=daily_preparation["meals_prepared"],
    name="Meals Prepared",
    marker_color="#12a58b"
))
fig_preparation.update_layout(
    title=dict(text="Actual Demand Compared with Meals Prepared", x=0.02, xanchor="left", font=dict(size=18, color="#172d49")),
    **chart_layout,
    height=390,
    barmode="group",
    xaxis_title="Date (Day / Month / Year)",
    yaxis_title="Meal Quantity (Number of Meals)",
    legend=dict(orientation="h", y=1.12, x=0)
)
st.plotly_chart(fig_preparation, use_container_width=True)
st.caption("What this chart shows: Compares actual customer demand with the meals prepared each day. When the prepared-meal bar is higher, there may be a surplus; when it is lower, there may be unmet demand. Recorded leftovers are tracked separately.")


# =========================================================
# 20. MENU CATEGORY WORD CLOUD
# =========================================================

st.markdown(
    '<div class="section-heading">Menu Category Word Cloud</div>'
    '<div class="section-description">'
    'Visualize how frequently each menu category appears in the selected records.'
    '</div>',
    unsafe_allow_html=True
)

category_counts = (
    filtered_df["menu_category"]
    .dropna()
    .astype(str)
    .value_counts()
    .to_dict()
)

# These are example menu-item names added to make the word cloud visually
# richer. The dataset contains category-level records, not item-level sales.
# Their weights are illustrative and must not be interpreted as actual sales.
illustrative_menu_items = {
    "South Indian": [
        "Idli", "Dosa", "Masala Dosa", "Vada", "Uttapam",
        "Pongal", "Upma", "Sambar Rice"
    ],
    "North Indian": [
        "Roti", "Paneer", "Chole", "Dal Rice", "Paratha",
        "Biryani", "Rajma", "Jeera Rice"
    ],
    "Chinese": [
        "Noodles", "Fried Rice", "Manchurian", "Momos",
        "Spring Roll", "Schezwan Rice", "Chilli Paneer"
    ],
    "Snacks": [
        "Samosa", "Sandwich", "Puff", "French Fries",
        "Pakora", "Burger", "Cutlet", "Tea"
    ]
}

if category_counts:
    try:
        from wordcloud import WordCloud
        import matplotlib.pyplot as plt

        word_frequencies = {}

        # Actual category frequency from the filtered dataset.
        for category, count in category_counts.items():
            word_frequencies[category] = max(int(count), 1)

        # Add representative food names for visual variety.
        # These are examples, not measured item-level frequencies.
        for category, items in illustrative_menu_items.items():
            if category in category_counts:
                example_weight = max(3, int(category_counts[category] * 0.22))
                for item in items:
                    word_frequencies[item] = example_weight

        word_cloud = WordCloud(
            width=1500,
            height=650,
            background_color="white",
            colormap="viridis",
            prefer_horizontal=0.88,
            collocations=False,
            max_words=80,
            relative_scaling=0.45,
            min_font_size=12,
            max_font_size=95,
            margin=8,
            random_state=42
        ).generate_from_frequencies(word_frequencies)

        fig_wordcloud, ax = plt.subplots(figsize=(16, 7), dpi=120)
        ax.imshow(word_cloud, interpolation="bilinear")
        ax.set_title(
            "SmartMeal Menu Categories & Food Items",
            fontsize=18,
            fontweight="bold",
            color="#172d49",
            pad=18
        )
        ax.axis("off")
        fig_wordcloud.patch.set_facecolor("white")
        ax.set_facecolor("white")
        plt.tight_layout(pad=1.2)
        st.pyplot(fig_wordcloud, use_container_width=True)
        plt.close(fig_wordcloud)

        st.caption(
            "What this word cloud shows: Category names are weighted using "
            "their frequency in the selected dataset. Food names such as Idli, "
            "Dosa, Noodles and Samosa are illustrative menu examples added for "
            "visual variety; the dataset does not contain item-level sales, so "
            "their displayed sizes do not represent actual item popularity."
        )
    except ImportError:
        st.warning(
            "Word Cloud needs the optional 'wordcloud' package. "
            "Install it using: pip install wordcloud matplotlib"
        )
else:
    st.info("No menu-category values are available for the selected filters.")


# =========================================================
# 21. PREDICTION DETAILS TABLE
# =========================================================

st.markdown(
    '<div class="section-heading">Prediction & Waste Records</div>'
    '<div class="section-description">'
    'Detailed actual, predicted, prepared and surplus meal information.'
    '</div>',
    unsafe_allow_html=True
)

table_columns = [
    "date",
    "menu_category",
    "day_type",
    "actual_demand",
    "predicted_demand",
    "meals_prepared",
    "actual_leftovers",
    "estimated_surplus",
    "unfulfilled_demand"
]

display_df = filtered_df[table_columns].copy()

display_df["date"] = (
    display_df["date"].dt.strftime("%Y-%m-%d")
)

display_df["predicted_demand"] = (
    display_df["predicted_demand"].round(2)
)

display_df["estimated_surplus"] = (
    display_df["estimated_surplus"].round(2)
)

display_df = display_df.rename(
    columns={
        "date": "Date",
        "menu_category": "Menu Category",
        "day_type": "Day Type",
        "actual_demand": "Actual Demand",
        "predicted_demand": "Predicted Demand",
        "meals_prepared": "Meals Prepared",
        "actual_leftovers": "Recorded Leftovers",
        "estimated_surplus": "Estimated Surplus",
        "unfulfilled_demand": "Unfulfilled Demand"
    }
)

st.dataframe(
    display_df.sort_values(
        "Date",
        ascending=False
    ),
    use_container_width=True,
    hide_index=True
)


# =========================================================
# 22. DOWNLOAD PREDICTION REPORT
# =========================================================

csv_data = filtered_df.to_csv(
    index=False
).encode("utf-8")

st.download_button(
    label="⬇ Download SmartMeal Analytics Report",
    data=csv_data,
    file_name="SmartMeal_Food_Waste_Report.csv",
    mime="text/csv"
)


# =========================================================
# 23. ABOUT SMARTMEAL
# =========================================================

with st.expander("About the SmartMeal Project"):

    st.markdown("""
    ## SmartMeal

    **Food Demand Prediction and Waste Reduction Using PySpark**

    SmartMeal is a machine-learning-based food demand
    forecasting system designed to help food-service
    providers estimate meal requirements.

    ### Technology Stack

    - Python
    - PySpark
    - Spark MLlib
    - Random Forest Regression
    - Pandas
    - Streamlit
    - Plotly

    ### Dataset

    The project uses 4,000 synthetic food-demand records
    generated using Python because actual canteen
    transaction records were unavailable.

    ### Prediction Target

    `meals_ordered`

    ### Model Evaluation

    - RMSE
    - MAE
    - R² Score

    ### Project Objective

    Predict meal demand, analyze recorded leftovers,
    identify possible surplus preparation and support
    better food preparation decisions.
    """)


# =========================================================
# 24. FOOTER
# =========================================================

st.html("""
<div style="
    text-align: center;
    color: #8a98aa;
    font-size: 12px;
    padding: 28px 10px 8px;
    border-top: 1px solid #e4eaf1;
    margin-top: 40px;
">

    <b style="color:#173d63;">SMARTMEAL</b>

    <br>

    Predict Smart. Prepare Right. Waste Less.

    <br>

    Built with Python • PySpark • Machine Learning • Streamlit

</div>
""")

