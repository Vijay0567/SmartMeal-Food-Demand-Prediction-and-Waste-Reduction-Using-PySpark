
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, to_date
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.regression import RandomForestRegressor
from pyspark.ml.evaluation import RegressionEvaluator

import os
import builtins

# ==========================================
# SMARTMEAL - RANDOM FOREST MODEL TRAINING
# ==========================================

# 1. Create Spark Session
spark = (
    SparkSession.builder
    .appName("SmartMeal_RandomForest")
    .master("local[*]")
    .getOrCreate()
)

spark.sparkContext.setLogLevel("ERROR")

print("\n========== SMARTMEAL MODEL TRAINING ==========")

# ==========================================
# 2. LOAD FEATURE ENGINEERED DATASET
# ==========================================

df = spark.read.csv(
    "featured_food_demand.csv",
    header=True,
    inferSchema=True
)

df = df.withColumn(
    "date",
    to_date(col("date"), "yyyy-MM-dd")
)

print("\n===== DATASET INFORMATION =====")

total_records = df.count()

print("Total Records:", total_records)

# ==========================================
# 3. SELECT INPUT FEATURES
# ==========================================

feature_columns = [
    "year",
    "month",
    "day",
    "day_of_week",
    "temperature",
    "is_holiday",
    "promotion",
    "previous_leftovers",
    "menu_south_indian",
    "menu_north_indian",
    "menu_chinese",
    "menu_snacks",
    "menu_unknown",
    "day_weekday",
    "day_weekend",
    "day_unknown"
]

target_column = "meals_ordered"

print("\n===== MACHINE LEARNING FEATURES =====")

print("Number of Input Features:", len(feature_columns))
print("Target Variable:", target_column)

# ==========================================
# 4. CHRONOLOGICAL TRAIN-TEST SPLIT
# ==========================================

print("\n===== TRAINING AND TESTING SPLIT =====")

# Training data: 2023 and 2024
train_data = df.filter(
    col("year") <= 2024
)

# Testing data: 2025
test_data = df.filter(
    col("year") == 2025
)

train_count = train_data.count()
test_count = test_data.count()

print("Training Records (2023-2024):", train_count)
print("Testing Records (2025):", test_count)

if train_count == 0 or test_count == 0:
    raise ValueError(
        "Training or testing dataset is empty. Check the date range."
    )

# ==========================================
# 5. FEATURE ASSEMBLY
# ==========================================

print("\n===== FEATURE ASSEMBLY =====")

assembler = VectorAssembler(
    inputCols=feature_columns,
    outputCol="features",
    handleInvalid="error"
)

train_data = assembler.transform(train_data)

test_data = assembler.transform(test_data)

print("Feature Vector Created Successfully!")

# ==========================================
# 6. RANDOM FOREST REGRESSION MODEL
# ==========================================

print("\n===== RANDOM FOREST MODEL =====")

rf = RandomForestRegressor(
    featuresCol="features",
    labelCol=target_column,
    predictionCol="prediction",
    numTrees=100,
    maxDepth=8,
    seed=42
)

# ==========================================
# 7. TRAIN THE MODEL
# ==========================================

print("\nTraining Random Forest Model...")

model = rf.fit(train_data)

print("Model Training Completed Successfully!")

# ==========================================
# 8. GENERATE PREDICTIONS
# ==========================================

print("\n===== MODEL PREDICTIONS =====")

predictions = model.transform(test_data)

predictions.select(
    "date",
    "menu_category",
    col("meals_ordered").alias("actual_demand"),
    col("prediction").alias("predicted_demand")
).show(20, truncate=False)

# ==========================================
# 9. MODEL EVALUATION
# ==========================================

print("\n===== MODEL EVALUATION =====")

evaluator = RegressionEvaluator(
    labelCol=target_column,
    predictionCol="prediction"
)

# Calculate RMSE
rmse = evaluator.evaluate(
    predictions,
    {evaluator.metricName: "rmse"}
)

# Calculate MAE
mae = evaluator.evaluate(
    predictions,
    {evaluator.metricName: "mae"}
)

# Calculate R2 Score
r2 = evaluator.evaluate(
    predictions,
    {evaluator.metricName: "r2"}
)

print("\n===== MODEL PERFORMANCE RESULTS =====")

print("RMSE:", builtins.round(rmse, 2))
print("MAE :", builtins.round(mae, 2))
print("R2  :", builtins.round(r2, 4))

# ==========================================
# 10. FEATURE IMPORTANCE
# ==========================================

print("\n===== FEATURE IMPORTANCE =====")

importance_values = model.featureImportances.toArray()

feature_importance = sorted(
    zip(feature_columns, importance_values),
    key=lambda x: x[1],
    reverse=True
)

for feature, importance in feature_importance:

    print(
        f"{feature}: {importance:.4f}"
    )

# ==========================================
# 11. SAVE PREDICTION RESULTS
# ==========================================

print("\n===== SAVING PREDICTIONS =====")

prediction_output = predictions.select(
    "date",
    "menu_category",
    "day_type",
    col("meals_ordered").alias("actual_demand"),
    col("prediction").alias("predicted_demand"),
    "meals_prepared",
    "actual_leftovers"
)

# Convert to Pandas for CSV export
prediction_pd = prediction_output.toPandas()

output_file = "model_predictions.csv"

prediction_pd.to_csv(
    output_file,
    index=False
)

print("\nPREDICTIONS SAVED SUCCESSFULLY!")

print("Saved File:", os.path.abspath(output_file))
print("Total Predictions:", len(prediction_pd))

# ==========================================
# 12. SAVE FEATURE IMPORTANCE
# ==========================================

importance_pd = __import__("pandas").DataFrame(
    feature_importance,
    columns=["feature", "importance"]
)

importance_pd.to_csv(
    "feature_importance.csv",
    index=False
)

print("Feature importance saved successfully!")

# ==========================================
# 13. FINAL MODEL SUMMARY
# ==========================================

print("\n========== SMARTMEAL MODEL SUMMARY ==========")

print("Algorithm: Random Forest Regression")
print("Training Records:", train_count)
print("Testing Records:", test_count)
print("Input Features:", len(feature_columns))
print("Target Variable:", target_column)

print("\nFinal Evaluation:")

print("RMSE:", builtins.round(rmse, 2))
print("MAE :", builtins.round(mae, 2))
print("R2  :", builtins.round(r2, 4))

print("\nSMARTMEAL MODEL TRAINING COMPLETED SUCCESSFULLY!")

# ==========================================
# 14. STOP SPARK SESSION
# ==========================================

spark.stop()

print("\nSMARTMEAL PROCESS FINISHED!")
