
import pandas as pd
import random
import numpy as np
from datetime import date, timedelta

# ==========================================
# SMARTMEAL - FOOD DEMAND DATASET GENERATOR
# ==========================================

random.seed(42)
np.random.seed(42)

categories = {
    "South Indian": 180,
    "North Indian": 155,
    "Chinese": 130,
    "Snacks": 100
}

start_date = date(2023, 1, 1)
total_days = 1000

holidays = {
    "2023-01-26", "2023-08-15", "2023-10-02",
    "2024-01-26", "2024-08-15", "2024-10-02",
    "2025-01-26", "2025-08-15"
}

records = []
previous_leftovers = {category: 12 for category in categories}

for day in range(total_days):

    current_date = start_date + timedelta(days=day)
    date_string = current_date.strftime("%Y-%m-%d")

    day_type = (
        "Weekend"
        if current_date.weekday() >= 5
        else "Weekday"
    )

    is_holiday = int(
        date_string in holidays
    )

    temperature = round(
        random.uniform(18, 40), 1
    )

    for category, base_demand in categories.items():

        promotion = random.choice([0, 0, 0, 1])

        demand = base_demand

        # Weekend demand adjustment
        if day_type == "Weekend":
            demand += 20

        # Holiday demand adjustment
        if is_holiday:
            demand += 25

        # Promotion adjustment
        if promotion:
            demand += 15

        # Temperature influence
        if temperature > 35:
            if category == "Snacks":
                demand += 10
            else:
                demand -= 5

        elif temperature < 22:
            demand += 5

        # Previous leftover influence
        demand -= previous_leftovers[category] * 0.15

        # Random demand variation
        demand += random.randint(-15, 15)

        meals_ordered = max(
            20, int(round(demand))
        )

        # Prepared meals
        meals_prepared = max(
            0,
            meals_ordered + random.randint(-5, 20)
        )

        actual_leftovers = max(
            0,
            meals_prepared - meals_ordered
        )

        records.append({
            "date": date_string,
            "menu_category": category,
            "day_type": day_type,
            "temperature": temperature,
            "is_holiday": is_holiday,
            "promotion": promotion,
            "previous_leftovers": previous_leftovers[category],
            "meals_ordered": meals_ordered,
            "meals_prepared": meals_prepared,
            "actual_leftovers": actual_leftovers
        })

        previous_leftovers[category] = actual_leftovers

# Create DataFrame
df = pd.DataFrame(records)

# Introduce missing values for data-cleaning practice
for column, count in {
    "menu_category": 20,
    "day_type": 20,
    "temperature": 60,
    "previous_leftovers": 40
}.items():
    indexes = random.sample(
        range(len(df)), count
    )
    df.loc[indexes, column] = np.nan

# Save dataset
df.to_csv(
    "food_demand.csv",
    index=False
)

print("SMARTMEAL DATASET CREATED SUCCESSFULLY!")
print("Total records:", len(df))
print("Total columns:", len(df.columns))
print("\nDataset columns:")
print(df.columns.tolist())

print("\nFirst 10 records:")
print(df.head(10).to_string(index=False))

print("\nMissing values:")
print(df.isnull().sum())

print("\nCSV file saved as food_demand.csv")
