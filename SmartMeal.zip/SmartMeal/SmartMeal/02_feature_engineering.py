
from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col,
    year,
    month,
    dayofmonth,
    dayofweek,
    when,
    to_date
)
import os

# ==========================================
# SMARTMEAL - FEATURE ENGINEERING
# ==========================================

# 1. Create Spark Session
spark = (
    SparkSession.builder
    .appName("SmartMeal_Feature_Engineering")
    .master("local[*]")
    .getOrCreate()
)

spark.sparkContext.setLogLevel("ERROR")

print("\n========== SMARTMEAL FEATURE ENGINEERING ==========")

# 2. Load Cleaned Dataset
df = spark.read.csv(
    "cleaned_food_demand.csv",
    header=True,
    inferSchema=True
)

print("\n===== CLEANED DATASET =====")

df.show(5, truncate=False)

print("Total Records:", df.count())

# 3. Convert Date Column
df = df.withColumn(
    "date",
    to_date(col("date"), "yyyy-MM-dd")
)

# ==========================================
# 4. DATE FEATURE EXTRACTION
# ==========================================

print("\n===== DATE FEATURE EXTRACTION =====")

df = df.withColumn("year", year(col("date")))

df = df.withColumn("month", month(col("date")))

df = df.withColumn("day", dayofmonth(col("date")))

# Spark dayofweek: Sunday = 1, Saturday = 7
df = df.withColumn(
    "day_of_week",
    dayofweek(col("date"))
)

print("Year, month, day and day_of_week extracted.")

# ==========================================
# 5. ENCODE MENU CATEGORY
# ==========================================

print("\n===== MENU CATEGORY ENCODING =====")

menu_categories = [
    "South Indian",
    "North Indian",
    "Chinese",
    "Snacks",
    "Unknown"
]

for category in menu_categories:

    feature_name = (
        "menu_" + category.lower().replace(" ", "_")
    )

    df = df.withColumn(
        feature_name,
        when(col("menu_category") == category, 1).otherwise(0)
    )

print("Menu categories converted into numerical features.")

# ==========================================
# 6. ENCODE DAY TYPE
# ==========================================

print("\n===== DAY TYPE ENCODING =====")

df = df.withColumn(
    "day_weekday",
    when(col("day_type") == "Weekday", 1).otherwise(0)
)

df = df.withColumn(
    "day_weekend",
    when(col("day_type") == "Weekend", 1).otherwise(0)
)

df = df.withColumn(
    "day_unknown",
    when(col("day_type") == "Unknown", 1).otherwise(0)
)

print("Day type converted into numerical features.")

# ==========================================
# 7. SELECT MACHINE LEARNING FEATURES
# ==========================================

feature_columns = [
    "year",
    "month",
    "day",
    "day_of_week",
    "temperature",
    "is_holiday",
    "promotion",
    "previous_leftovers",
    "menu_south_indian",
    "menu_north_indian",
    "menu_chinese",
    "menu_snacks",
    "menu_unknown",
    "day_weekday",
    "day_weekend",
    "day_unknown"
]

target_column = "meals_ordered"

print("\n===== MACHINE LEARNING FEATURES =====")

print("Input Features:")

for feature in feature_columns:
    print("-", feature)

print("\nTarget Variable:", target_column)

# ==========================================
# 8. DISPLAY FEATURE ENGINEERED DATASET
# ==========================================

print("\n===== FEATURE ENGINEERED DATASET =====")

df.select(
    "date",
    "menu_category",
    "day_type",
    *feature_columns,
    target_column
).show(10, truncate=False)

# ==========================================
# 9. CHECK FEATURE DATA
# ==========================================

print("\n===== FEATURE DATA VALIDATION =====")

print("Total Records:", df.count())
print("Total Input Features:", len(feature_columns))

for feature in feature_columns:
    missing = df.filter(col(feature).isNull()).count()
    print(feature, "missing values:", missing)

# ==========================================
# 10. SAVE FEATURE ENGINEERED DATASET
# ==========================================

print("\n===== SAVING FEATURE DATASET =====")

# Convert Spark DataFrame to Pandas for CSV export
featured_pd = df.toPandas()

output_file = "featured_food_demand.csv"

featured_pd.to_csv(
    output_file,
    index=False
)

print("\nFEATURE ENGINEERING COMPLETED SUCCESSFULLY!")

print("Saved File:", os.path.abspath(output_file))
print("Total Saved Records:", len(featured_pd))
print("Total Input Features:", len(feature_columns))
print("Target Variable:", target_column)

# 11. Stop Spark Session
spark.stop()

print("\nSMARTMEAL FEATURE ENGINEERING FINISHED!")
